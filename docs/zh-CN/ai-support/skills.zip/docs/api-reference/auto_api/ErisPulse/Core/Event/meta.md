# `ErisPulse.Core.Event.meta` 模块

---

## 模块概述


ErisPulse 元事件处理模块

提供基于装饰器的元事件处理功能

> **提示**
> 1. 支持连接、断开连接等生命周期事件
> 2. 适用于系统状态监控和初始化操作

---

## 类列表


### `class MetaHandler`

元事件处理器

提供元事件处理功能，如连接、断开连接等


#### 方法列表


##### `on_meta(priority: int = 0) -> Callable`

通用元事件装饰器

- **priority**: 处理器优先级

**返回值**: 装饰器函数

---


##### `unregister(handler: Callable) -> bool`

取消注册的事件处理器

- **handler**: 要取消注册的处理器

**返回值**: 是否成功取消注册

---


##### `remove_meta_handler(handler: Callable) -> bool`

取消注册通用元事件处理器

- **handler**: 要取消注册的处理器

**返回值**: 是否成功取消注册

---


##### `on_connect(priority: int = 0) -> Callable`

连接事件装饰器

- **priority**: 处理器优先级

**返回值**: 装饰器函数

---


##### `remove_connect_handler(handler: Callable) -> bool`

取消注册连接事件处理器

- **handler**: 要取消注册的处理器

**返回值**: 是否成功取消注册

---


##### `on_disconnect(priority: int = 0) -> Callable`

断开连接事件装饰器

- **priority**: 处理器优先级

**返回值**: 装饰器函数

---


##### `remove_disconnect_handler(handler: Callable) -> bool`

取消注册断开连接事件处理器

- **handler**: 要取消注册的处理器

**返回值**: 是否成功取消注册

---


##### `on_heartbeat(priority: int = 0) -> Callable`

心跳事件装饰器

- **priority**: 处理器优先级

**返回值**: 装饰器函数

---


##### `remove_heartbeat_handler(handler: Callable) -> bool`

取消注册心跳事件处理器

- **handler**: 要取消注册的处理器

**返回值**: 是否成功取消注册

---


##### `_clear_meta_handlers()`

**内部方法**
清除所有已注册的元事件处理器

**返回值**: 被清除的处理器数量

---

