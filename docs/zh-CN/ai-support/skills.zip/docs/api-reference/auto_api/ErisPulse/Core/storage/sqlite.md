# `ErisPulse.Core.storage.sqlite` 模块

---

## 模块概述


ErisPulse SQLite 存储后端（aiosqlite 异步原生实现）

默认存储后端。数据库文件位于项目目录 ``config/config.db``；
启用 ``use_global_db`` 时使用包内全局数据库 ``data/config.db``。

> **提示**
> 1. 非事务操作复用每事件循环的单个共享连接（autocommit 模式）
> 2. 事务使用专用连接（BEGIN/COMMIT/ROLLBACK），与共享连接互不干扰
> 3. WAL 日志模式 + busy_timeout，支持多事件循环（如同步桥接循环）并发访问

---

## 类列表


### `class SQLiteDialect(SQLDialect)`

SQLite 方言实现


#### 方法列表


##### `autoincrement_column(base_type: str) -> str`

**内部方法** SQLite 原生支持 AUTOINCREMENT 后缀

---


##### `is_missing_table_error(exc: BaseException) -> bool`

**内部方法** sqlite3.OperationalError: no such table

---


##### `table_columns_sql(table_name: str) -> tuple[str, list[str]]`

**内部方法** PRAGMA 列举表现有列名（表名经标识符校验，直接内插）

---


### `class SQLiteStorage(_SingletonMixin, SQLStorageBase)`

SQLite 存储管理器（aiosqlite 异步原生实现）

单例模式实现，提供键值存储的增删改查、通用 SQL 链式查询和事务管理。

支持两种数据库模式：
1. 项目数据库（默认）：位于项目目录下的 config/config.db
2. 全局数据库：位于包内的 data/config.db（``use_global_db`` 开启且文件存在时）

> **提示**
> 1. 使用 get/set（或 aget/aset）方法操作键值存储项
> 2. 使用 Table() 链式调用操作自定义表
> 3. 使用 transaction/atransaction 上下文管理事务


#### 方法列表


##### `_check_use_global_db_changed() -> str | None`

**内部方法** use_global_db 配置变更检查

---


##### `_resolve_busy_timeout(storage_config: dict[str, Any]) -> int`（staticmethod）

**内部方法**
解析 busy_timeout 配置（``ErisPulse.storage.sqlite.busy_timeout``，毫秒）

- **storage_config**: ``ErisPulse.storage`` 配置节

**返回值**: 校验后的毫秒数（非法值回落默认并告警）

---


##### `_check_busy_timeout_changed() -> str | None`

**内部方法** busy_timeout 配置变更检查（新连接按新值应用，已打开连接需重启刷新）

---


##### `_ensure_directories() -> None`

**内部方法** 确保必要的目录存在

---


##### `_init_db() -> None`

**内部方法**
初始化数据库（创建默认 config 键值表）

**异常**: `sqlite3.OperationalError` - 数据库文件无法创建或打开时

---


##### `async _apply_pragmas(conn: aiosqlite.Connection) -> None`

**内部方法** 应用标准 PRAGMA（WAL/synchronous/busy_timeout，后者来自配置）

---


##### `async _create_loop_resource() -> aiosqlite.Connection`

**内部方法** 当前事件循环的共享连接（autocommit 模式）

---


##### `async _destroy_loop_resource(resource: aiosqlite.Connection) -> None`

**内部方法** 关闭共享连接

---


##### `async _acquire_resource_conn(resource: aiosqlite.Connection) -> Any`

**内部方法** 共享连接直接复用（游标级并发安全）

---


##### `async _release_resource_conn(resource: aiosqlite.Connection, conn: Any) -> None`

**内部方法** 共享连接无需归还

---


##### `async _open_txn_conn() -> aiosqlite.Connection`

**内部方法** 事务使用专用连接（与共享连接互不干扰）

---


##### `async _close_txn_conn(conn: aiosqlite.Connection) -> None`

**内部方法** 关闭事务专用连接

---


##### `_track_connection(conn: aiosqlite.Connection) -> None`

**内部方法** 登记存活连接（弱引用），供退出阶段同步停止其工作线程

---


##### `_stop_sync_resources() -> None`

**内部方法** 退出阶段不经事件循环，直接停止全部存活连接的工作线程

---


##### `async _begin_txn(conn: Any) -> None`

**内部方法** BEGIN IMMEDIATE TRANSACTION

IMMEDIATE 在事务开始时即取写锁（busy_timeout 正常生效），避免
deferred 事务「先读后写」升级写锁时的 SQLITE_BUSY_SNAPSHOT——
该 busy 错误不重试、直接抛 locked，WAL + busy_timeout 均无法缓解
（高频读写混合下表现为间歇性 database is locked）。

---


##### `async _commit_txn(conn: Any, handle: Any = None) -> None`

**内部方法** COMMIT

---


##### `async _rollback_txn(conn: Any, handle: Any = None) -> None`

**内部方法** ROLLBACK

---


##### `async _exec_query_on(kind: str, sql: str, params: Any, conn: Any) -> Any`

**内部方法**
SQLite 执行漏斗

- **kind**: "select" / "one" / "count" / "dml" / "dml_multi"

**返回值**: select/one 返回 (行, 列名列表或None)；其余返回受影响行数

---

