# ErisPulse 文档包（zh-CN）

本压缩包由 CI 从 `docs/zh-CN/` 自动打包：收录全部文档原文（不合并、不改写），另附本 README 作为总索引。

## 使用

1. 解压后把整个目录放进工作区（IDE / 智能体均可），或按需把单个文档投喂给 AI
2. 按下面的索引挑文档：先看「什么时候读」，只加载需要的那几篇，不必全文灌入

## 索引

### 根目录文档

| 文档 | 什么时候读 |
|---|---|
| `README.md` | [模块开发入门](developer-guide/modules/getting-started.md)。 |
| `architecture.md` | 想搞懂框架在背后做了什么——一条消息如何流转、模块按什么顺序初始化、热重载时发生了什么，或排查"框架为什么这样表现"时读。只想写处理器的话，看 [事件处理入门](getting-started/event-handling.md) 就够。 |
| `bug-tracker.md` | 本文档记录 ErisPulse SDK 的已知 Bug 及其修复情况，按修复版本时间顺序排列。 |
| `quick-start.md` | **1. 安装**（Python >= 3.10）： |

### advanced/

| 文档 | 什么时候读 |
|---|---|
| `advanced/README.md` | - [作用域（scope）](scope.md) - 三维作用域控制：模块可用性 / 事件准入 / 出站动作限制（含方法级细粒度规则与绑定继承 merge）。 |
| `advanced/client.md` | 需要出站 HTTP / WebSocket 请求时。 |
| `advanced/connections.md` | 需要 WebSocket/SSE 连接池、广播分组、跨模块推送或查看连接时。 |
| `advanced/conversation.md` | 需要多轮对话状态机与检查点恢复时。 |
| `advanced/errors.md` | ErisPulse 所有自定义异常都继承自 `ErisPulseError`，底层库异常（aiohttp、aiomysql 等） |
| `advanced/i18n.md` | 需要多语言文案、翻译注册或语言检测时。 |
| `advanced/interaction.md` | 需要 wait_reply、多轮对话、定时提醒、会话互斥或链路追踪时。 |
| `advanced/lazy-loading.md` | 使用懒加载模块或 activate_on 事件驱动激活时。 |
| `advanced/lifecycle.md` | 需要订阅框架生命周期事件（启动 / 加载 / 状态变化）时。 |
| `advanced/message-builder.md` | 构建复杂 / 多段消息时。 |
| `advanced/module-communication.md` | 需要跨模块调用（RPC）、服务契约、定向事件或冷启动回放时。 |
| `advanced/ownership.md` | 排查资源泄漏、理解卸载清理链路或声明归属资源时。 |
| `advanced/router.md` | 需要 HTTP / WebSocket / SSE 路由（含连接池广播）时。 |
| `advanced/scope.md` | 需要控制模块可用性、事件准入或出站动作限制时。 |
| `advanced/shadow.md` | 需要灰度发布——新版本并行试运行、行为对比与转正回滚时。 |
| `advanced/sql-builder.md` | 需要链式 SQL 查询或自定义存储后端时。 |
| `advanced/startup.md` | 需要手动驱动启动链路、定制启动顺序或排查启动失败时。 |
| `advanced/storage-backends.md` | 切换 sqlite / mysql / postgres 或自定义存储后端时。 |
| `advanced/transcript.md` | 需要消息历史、对话恢复，或调整收件箱保留策略时。 |

### api-reference/

| 文档 | 什么时候读 |
|---|---|
| `api-reference/README.md` | 当你在写模块或适配器时需要查某个核心模块（Storage/Config/Logger/Router 等）、事件系统或适配器管理 API 的用法示例——按下面文档列表跳到对应篇目。 |
| `api-reference/adapter-system.md` | 当你需要管理适配器（获取实例、启停、查 Bot 在线状态）、用 Send DSL 发消息、注册中间件，或为适配器接入 Bot 状态上报（meta 事件）时查阅本文。 |
| `api-reference/auto_api/ErisPulse/CLI/__init__.md` | CLI 模块 |
| `api-reference/auto_api/ErisPulse/CLI/base.md` | CLI 命令基类 |
| `api-reference/auto_api/ErisPulse/CLI/cli.md` | 主 CLI 类 |
| `api-reference/auto_api/ErisPulse/CLI/commands/__init__.md` | 命令模块 |
| `api-reference/auto_api/ErisPulse/CLI/commands/config.md` | Config 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/create.md` | Create 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/doctor.md` | Doctor 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/init.md` | Init 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/install.md` | Install 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/language.md` | Language 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/list.md` | List 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/list_remote.md` | List-Remote 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/run.md` | Run 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/runtime.md` | Stop / Restart 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/self_update.md` | Self-Update 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/types.md` | Types 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/uninstall.md` | Uninstall 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/upgrade.md` | Upgrade 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/version.md` | Version 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/console.md` | CLI 控制台模块 |
| `api-reference/auto_api/ErisPulse/CLI/constants.md` | CLI 本地常量 |
| `api-reference/auto_api/ErisPulse/CLI/hints.md` | ErisPulse CLI 友好提示引擎 |
| `api-reference/auto_api/ErisPulse/CLI/i18n/__init__.md` | ErisPulse CLI 国际化模块 |
| `api-reference/auto_api/ErisPulse/CLI/i18n/locales/__init__.md` | CLI 内置翻译数据加载器 |
| `api-reference/auto_api/ErisPulse/CLI/i18n/locales/en.md` | CLI English translations (en) |
| `api-reference/auto_api/ErisPulse/CLI/i18n/locales/ja.md` | CLI 日本語翻訳 (ja) |
| `api-reference/auto_api/ErisPulse/CLI/i18n/locales/ru.md` | CLI Русский перевод (ru) |
| `api-reference/auto_api/ErisPulse/CLI/i18n/locales/zh_cn.md` | CLI 简体中文翻译 (zh-CN) |
| `api-reference/auto_api/ErisPulse/CLI/i18n/locales/zh_tw.md` | CLI 繁體中文翻譯 (zh-TW) |
| `api-reference/auto_api/ErisPulse/CLI/registry.md` | CLI 命令注册器 |
| `api-reference/auto_api/ErisPulse/CLI/utils/__init__.md` | ErisPulse SDK 工具模块 |
| `api-reference/auto_api/ErisPulse/CLI/utils/config_wizard.md` | ErisPulse CLI 配置向导共享工具 |
| `api-reference/auto_api/ErisPulse/CLI/utils/display.md` | ErisPulse CLI 显示工具 |
| `api-reference/auto_api/ErisPulse/CLI/utils/interactive.md` | CLI 交互式提示统一封装 |
| `api-reference/auto_api/ErisPulse/CLI/utils/package_manager.md` | ErisPulse SDK 包管理器 |
| `api-reference/auto_api/ErisPulse/CLI/utils/runtime_state.md` | 运行实例状态文件（pidfile）工具 |
| `api-reference/auto_api/ErisPulse/CLI/utils/scaffold_text.md` | 脚手架模板多语言文案 |
| `api-reference/auto_api/ErisPulse/Core/Bases/__init__.md` | ErisPulse 基础模块 |
| `api-reference/auto_api/ErisPulse/Core/Bases/adapter.md` | ErisPulse 适配器基础模块 |
| `api-reference/auto_api/ErisPulse/Core/Bases/adapter_patterns.md` | ErisPulse 适配器通信模式基类 |
| `api-reference/auto_api/ErisPulse/Core/Bases/api_dsl.md` | ErisPulse 标准 API 动作 DSL 模块 |
| `api-reference/auto_api/ErisPulse/Core/Bases/client.md` | ErisPulse HTTP 客户端抽象基类 |
| `api-reference/auto_api/ErisPulse/Core/Bases/config_schema.md` | ErisPulse 通用配置 Schema 模块 |
| `api-reference/auto_api/ErisPulse/Core/Bases/converter.md` | OneBot12 事件转换器基类 |
| `api-reference/auto_api/ErisPulse/Core/Bases/errors.md` | ErisPulse 异常体系 |
| `api-reference/auto_api/ErisPulse/Core/Bases/i18n_schema.md` | ErisPulse i18n 键声明 Schema 模块 |
| `api-reference/auto_api/ErisPulse/Core/Bases/kv_builder.md` | ErisPulse KV 查询构建器 |
| `api-reference/auto_api/ErisPulse/Core/Bases/manager.md` | ErisPulse 管理器基类 |
| `api-reference/auto_api/ErisPulse/Core/Bases/model.md` | ErisPulse 数据模型层（ORM）—— 声明式模型与 Active Record CRUD |
| `api-reference/auto_api/ErisPulse/Core/Bases/module.md` | ErisPulse 模块基础模块 |
| `api-reference/auto_api/ErisPulse/Core/Bases/router.md` | ErisPulse 路由抽象基类 |
| `api-reference/auto_api/ErisPulse/Core/Bases/send_builder.md` | SendDSL 批量构建系统 |
| `api-reference/auto_api/ErisPulse/Core/Bases/send_rules.md` | SendDSL 发送规则系统 |
| `api-reference/auto_api/ErisPulse/Core/Bases/sql_base.md` | ErisPulse SQL 存储共享基类 |
| `api-reference/auto_api/ErisPulse/Core/Bases/storage.md` | ErisPulse 存储基类 |
| `api-reference/auto_api/ErisPulse/Core/Bases/websocket.md` | ErisPulse WebSocket 共享基类 |
| `api-reference/auto_api/ErisPulse/Core/Event/__init__.md` | ErisPulse 事件处理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/base.md` | ErisPulse 事件处理基础模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/command.md` | ErisPulse 命令处理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/command_args.md` | ErisPulse 命令参数与选项解析模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/command_flow.md` | 命令多轮流控语法糖（``.got()`` 链） |
| `api-reference/auto_api/ErisPulse/Core/Event/conversation.md` | ErisPulse 多轮对话上下文模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/governance.md` | ErisPulse 命令治理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/interaction.md` | ErisPulse 交互会话管理 |
| `api-reference/auto_api/ErisPulse/Core/Event/message.md` | ErisPulse 消息处理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/message_builder.md` | ErisPulse 消息构建器 |
| `api-reference/auto_api/ErisPulse/Core/Event/meta.md` | ErisPulse 元事件处理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/notice.md` | ErisPulse 通知处理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/overrides.md` | ErisPulse 事件覆写系统（overrides） |
| `api-reference/auto_api/ErisPulse/Core/Event/request.md` | ErisPulse 请求处理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/session_type.md` | ErisPulse 会话类型管理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/throttle.md` | 事件处理器节流（throttle=）与防抖（debounce=，EPRFC-2026-001 方向八） |
| `api-reference/auto_api/ErisPulse/Core/Event/trace.md` | 分发决策链追踪（EPRFC-2026-001 方向五：模块排查的场景三） |
| `api-reference/auto_api/ErisPulse/Core/Event/wrapper.md` | ErisPulse 事件包装类 |
| `api-reference/auto_api/ErisPulse/Core/__init__.md` | ErisPulse 核心模块 |
| `api-reference/auto_api/ErisPulse/Core/adapter.md` | ErisPulse 适配器系统 |
| `api-reference/auto_api/ErisPulse/Core/assets/__init__.md` | ErisPulse 前端资源 |
| `api-reference/auto_api/ErisPulse/Core/client.md` | ErisPulse HTTP/WS 客户端 |
| `api-reference/auto_api/ErisPulse/Core/config.md` | ErisPulse 配置中心 |
| `api-reference/auto_api/ErisPulse/Core/connections.md` | ErisPulse 连接注册表（连接池） |
| `api-reference/auto_api/ErisPulse/Core/constants.md` | ErisPulse 内部常量定义 |
| `api-reference/auto_api/ErisPulse/Core/di.md` | ErisPulse 依赖注入模块 |
| `api-reference/auto_api/ErisPulse/Core/i18n/__init__.md` | ErisPulse 国际化模块 |
| `api-reference/auto_api/ErisPulse/Core/i18n/constants.md` | ErisPulse i18n 常量定义 |
| `api-reference/auto_api/ErisPulse/Core/i18n/locales/__init__.md` | ErisPulse 内置翻译数据包 |
| `api-reference/auto_api/ErisPulse/Core/i18n/locales/en.md` | English translation data (en) |
| `api-reference/auto_api/ErisPulse/Core/i18n/locales/ja.md` | 日本語翻訳データ (ja) |
| `api-reference/auto_api/ErisPulse/Core/i18n/locales/ru.md` | Русский перевод (ru) |
| `api-reference/auto_api/ErisPulse/Core/i18n/locales/zh_cn.md` | 简体中文翻译数据 (zh-CN) |
| `api-reference/auto_api/ErisPulse/Core/i18n/locales/zh_tw.md` | 繁體中文翻譯資料 (zh-TW) |
| `api-reference/auto_api/ErisPulse/Core/lifecycle.md` | ErisPulse 生命周期管理模块 |
| `api-reference/auto_api/ErisPulse/Core/logger.md` | ErisPulse 日志系统 |
| `api-reference/auto_api/ErisPulse/Core/master.md` | 框架主人管理系统 |
| `api-reference/auto_api/ErisPulse/Core/module.md` | ErisPulse 模块系统 |
| `api-reference/auto_api/ErisPulse/Core/ownership.md` | ErisPulse 归属权统一门面 |
| `api-reference/auto_api/ErisPulse/Core/router.md` | ErisPulse 路由系统 |
| `api-reference/auto_api/ErisPulse/Core/scope.md` | ErisPulse 作用域（scope） |
| `api-reference/auto_api/ErisPulse/Core/shadow.md` | ErisPulse 影子模块（方向十一：Shadow Modules & Canary Promote） |
| `api-reference/auto_api/ErisPulse/Core/storage/__init__.md` | ErisPulse 存储管理模块 |
| `api-reference/auto_api/ErisPulse/Core/storage/mysql.md` | ErisPulse MySQL 存储后端（aiomysql 异步原生实现） |
| `api-reference/auto_api/ErisPulse/Core/storage/postgres.md` | ErisPulse PostgreSQL 存储后端（asyncpg 异步原生实现） |
| `api-reference/auto_api/ErisPulse/Core/storage/sqlite.md` | ErisPulse SQLite 存储后端（aiosqlite 异步原生实现） |
| `api-reference/auto_api/ErisPulse/Core/text_match.md` | ErisPulse 统一文本/条目匹配工具 |
| `api-reference/auto_api/ErisPulse/Core/transcript.md` | ErisPulse 会话收件箱（transcript） |
| `api-reference/auto_api/ErisPulse/__init__.md` | ErisPulse SDK 主模块 |
| `api-reference/auto_api/ErisPulse/__main__.md` | ErisPulse SDK 命令行工具 |
| `api-reference/auto_api/ErisPulse/finders/__init__.md` | ErisPulse 发现器模块 |
| `api-reference/auto_api/ErisPulse/finders/adapter.md` | ErisPulse 适配器发现器 |
| `api-reference/auto_api/ErisPulse/finders/bases/finder.md` | ErisPulse 基础发现器 |
| `api-reference/auto_api/ErisPulse/finders/module.md` | ErisPulse 模块发现器 |
| `api-reference/auto_api/ErisPulse/loaders/__init__.md` | ErisPulse 加载器模块 |
| `api-reference/auto_api/ErisPulse/loaders/_reload_utils.md` | 热重载共用工具：字节码缓存清理与卸载前语法预检 |
| `api-reference/auto_api/ErisPulse/loaders/adapter.md` | ErisPulse 适配器加载器 |
| `api-reference/auto_api/ErisPulse/loaders/bases/loader.md` | ErisPulse 基础加载器 |
| `api-reference/auto_api/ErisPulse/loaders/module.md` | ErisPulse 模块加载器 |
| `api-reference/auto_api/ErisPulse/loaders/plugin_folder.md` | ErisPulse 本地插件文件夹加载器 |
| `api-reference/auto_api/ErisPulse/loaders/strategy.md` | ErisPulse 模块加载策略 |
| `api-reference/auto_api/ErisPulse/loaders/strict.md` | ErisPulse 严格模式 |
| `api-reference/auto_api/ErisPulse/runtime/__init__.md` | ErisPulse 运行时配置和管理模块 |
| `api-reference/auto_api/ErisPulse/runtime/config_schema.md` | ErisPulse 通用配置 Schema 模块（向后兼容 shim） |
| `api-reference/auto_api/ErisPulse/runtime/context.md` | ErisPulse 运行时上下文 |
| `api-reference/auto_api/ErisPulse/runtime/diagnostics.md` | ErisPulse 异常诊断模块 |
| `api-reference/auto_api/ErisPulse/runtime/example_config.md` | config.full.example 完整配置参考生成器（runtime / CLI 共用） |
| `api-reference/auto_api/ErisPulse/runtime/exceptions.md` | ErisPulse 全局异常处理系统 |
| `api-reference/auto_api/ErisPulse/runtime/file_watcher.md` | 文件变更监控 |
| `api-reference/auto_api/ErisPulse/runtime/frame_config.md` | ErisPulse 框架配置管理模块 |
| `api-reference/auto_api/ErisPulse/runtime/hints.md` | ErisPulse 友好错误提示引擎 |
| `api-reference/auto_api/ErisPulse/runtime/kernel.md` | 统一编排内核（组合根） |
| `api-reference/auto_api/ErisPulse/runtime/memory.md` | 进程内存追踪工具 |
| `api-reference/auto_api/ErisPulse/runtime/owner_cleanup.md` | 归属清理钩子（owner cleanup hooks） |
| `api-reference/auto_api/ErisPulse/runtime/plugin_reload.md` | ErisPulse 本地插件热重载监控 |
| `api-reference/auto_api/ErisPulse/runtime/proactive_gc.md` | ErisPulse 主动 GC 周期任务 |
| `api-reference/auto_api/ErisPulse/runtime/process_state.md` | 跨进程运行状态契约（SDK 侧） |
| `api-reference/auto_api/ErisPulse/runtime/reload_ops.md` | 热重载操作协调器 |
| `api-reference/auto_api/ErisPulse/runtime/resource_track.md` | 合作式资源登记（tracked resources） |
| `api-reference/auto_api/ErisPulse/runtime/sdk_initializer.md` | ErisPulse SDK 初始化 / 反初始化协调器 |
| `api-reference/auto_api/ErisPulse/runtime/tasks.md` | 后台任务管理工具 |
| `api-reference/auto_api/ErisPulse/runtime/troubleshoot.md` | 模块排查诊断（EPRFC-2026-001 方向五·场景一 / 二） |
| `api-reference/auto_api/ErisPulse/runtime/version.md` | SDK 版本解析与比较 |
| `api-reference/auto_api/ErisPulse/sdk.md` | ErisPulse SDK 主类 |
| `api-reference/auto_api/README.md` | 本文档包含 ErisPulse SDK 的所有 API 参考文档。 |
| `api-reference/core-modules.md` | 当你需要用存储、配置、日志、模块管理、路由、HTTP 客户端等核心能力，记不清具体方法签名时快速查阅本文。 |
| `api-reference/event-system.md` | 当你需要注册命令、监听消息/通知/请求事件，或使用 `event.reply()` / `wait_reply()` / `confirm()` 等事件交互方法时查阅本文。 |

### contributing/

| 文档 | 什么时候读 |
|---|---|
| `contributing/README.md` | 想为 ErisPulse 做点贡献、但还不确定能做什么或从哪开始时。只使用机器人、不参与开发则跳过。 |
| `contributing/first-contribution.md` | 准备提交你的第一个 Pull Request 时——从 fork 到合并的每一步都有可直接复制的命令。已有 PR 经验、只想查仓库规范，直接看 [CONTRIBUTING.md](../../../CONTRIBUTING.md)。 |

### developer-guide/

| 文档 | 什么时候读 |
|---|---|
| `developer-guide/README.md` | 准备为 ErisPulse 开发扩展——给机器人加功能（模块）或接入新平台（适配器）——时。只想使用机器人则跳过，直接看[快速开始](../quick-start.md)。 |
| `developer-guide/adapters/best-practices.md` | 适配器骨架跑通后建议阅读（工程化最佳实践）。 |
| `developer-guide/adapters/converter.md` | 适配器开发路径内必读（事件转换器）。 |
| `developer-guide/adapters/core-concepts.md` | 适配器开发路径内必读（BaseAdapter / SendDSL / 生命周期等核心机制的完整说明）。只想起步可先读 [适配器开发入门](getting-started.md)，遇到"为什么"层面的疑问再回到本篇查阅。 |
| `developer-guide/adapters/getting-started.md` | 适配器开发路径的入口篇（必读）。从零写一个适配器、了解适配器的职责边界与项目结构都在这里；读完后再按需进入 [事件转换器](converter.md) 与 [SendDSL 详解](send-dsl.md)。 |
| `developer-guide/adapters/send-dsl.md` | 适配器开发路径内必读（发送 DSL）。 |
| `developer-guide/configuration.md` | ErisPulse 的配置体系是**声明式**的：开发者用 dataclass 字段 + 元数据描述配置项，框架的 `get_config_schema()` 将其转译为 JSON Schema，供任何消费方（Dashboard、第三方面板、CLI 向导等）渲染。本文是该元数据的**规范定义**——widget 语义、值形态、条件显隐、兼容性义务都以此为准；各消费方负责具体实现，语义必须与本文一致。 |
| `developer-guide/modules/best-practices.md` | 写完第一个模块后建议阅读（工程化最佳实践）。 |
| `developer-guide/modules/core-concepts.md` | 这篇讲清模块从加载到卸载的完整生命周期、声明式配置与存储的用法——哪些事框架自动替你做、你只需要写什么，看完就有数。 |
| `developer-guide/modules/event-wrapper.md` | 处理器里的 `event` 参数之所以能直接 `.get_text()` / `.reply()` / `.wait_reply()`，靠的就是 Event 包装类。本篇是它的完整方法清单——写事件处理器时按需查阅，方法签名与行为都以这里为准。 |
| `developer-guide/modules/getting-started.md` | 跟着这篇走完，你会得到一个能响应 `/hello` 命令的可运行模块，并了解模块的项目结构、注册方式与加载 / 卸载钩子——后续所有模块文档都建立在这套骨架上。 |
| `developer-guide/orm.md` | 需要数据模型、自动建表或关系映射时。 |
| `developer-guide/publishing.md` | 将作品发布到 PyPI / 模块商店时。 |
| `developer-guide/testing.md` | 为自己的模块编写自动化测试时。 |

### ecosystem/

| 文档 | 什么时候读 |
|---|---|
| `ecosystem/README.md` | ErisPulse 框架本身只提供核心能力（事件系统、模块系统、配置、路由、日志等），**不内置** GUI、图片渲染、可视化等"重型"功能。这些能力由社区维护的 **第三方模块** 提供，按需安装即可。 |
| `ecosystem/apimcp.md` | 当你想让 Claude Desktop 等支持 MCP 的 AI 客户端直接操控你的机器人——发消息、看消息、调模块、管适配器、观测事件流——时读这篇。 |
| `ecosystem/app.md` | 当你想在手机或电脑上用图形界面创建、运行、管理机器人实例——不碰终端、不单独装 Python 环境时读这篇。 |
| `ecosystem/cron.md` | 当你的模块需要定时/延时触发逻辑（定时提醒、周期监控、Cron 表达式调度），且希望任务在框架重启后不丢失时读这篇。 |
| `ecosystem/dashboard.md` | 当你想用网页可视化管理机器人（启停模块、编辑配置、看日志、监控事件流），或想为自己的模块注册一个 Dashboard 管理页面时读这篇。 |
| `ecosystem/qvqchat.md` | 当你想给机器人加 AI 智能体能力（工具循环、流式对话、MCP、长期记忆），或想把自己模块的服务暴露给智能体调用时读这篇。 |
| `ecosystem/takumi.md` | 当你需要把 HTML / 节点树 / Jinja 模板渲染成图片发到聊天平台（统计卡片、排行榜、图文长文）时读这篇。 |

### getting-started/

| 文档 | 什么时候读 |
|---|---|
| `getting-started/README.md` | 机器人已经用 [5 分钟快速开始](../quick-start.md) 跑起来了，想系统理解框架的核心概念、把常用能力学全。还没跑起来先去完成快速开始；只想按需查某个问题则直接跳到对应单篇。 |
| `getting-started/basic-concepts.md` | 一条消息从用户发出到机器人回复，中间经过了哪些组件？适配器和模块各自负责什么？读完这篇，写处理器时遇到的设计问题你都能自己回答，而不是只能照抄示例。 |
| `getting-started/common-tasks.md` | 想给机器人加某个具体功能时按节查阅——持久化、定时任务、消息过滤、权限控制、批量发送，每一节都是可直接复制的完整示例。想系统学事件处理写法先看 [事件处理入门](event-handling.md)。 |
| `getting-started/event-handling.md` | 想让机器人响应消息、命令、通知、请求，或要实现等待回复 / 多轮对话、排查"命令为什么没触发"时读。只想了解框架设计，看 [基础概念](basic-concepts.md) 即可。 |
| `getting-started/first-bot.md` | 机器人已经能跑，想写出第一个 `/hello` 命令处理器、搞懂 `sdk.run` 与命令装饰器各自在做什么。如果还没装好 ErisPulse、初始化项目，先完成 [5 分钟快速开始](../quick-start.md) 的「安装」「初始化项目」「运行项目」三步。 |
| `getting-started/ide-completion.md` | IDE 补全不出适配器的平台特有方法（如云湖的 `Board`）或模块的自定义方法时，跑一条 `epsdk types` 命令生成类型存根即可解决。 |

### platform-guide/

| 文档 | 什么时候读 |
|---|---|
| `platform-guide/README.md` | 此部分由各适配器开发者维护，用于说明该适配器与 OneBot12 标准的差异和扩展功能。请参考以下各平台的详细文档： |
| `platform-guide/bilibili.md` | BilibiliAdapter 是基于 bilibili-api-python 的 B 站私信适配器，支持 Cookie / 扫码双登录与事件驱动的私信收发。 |
| `platform-guide/discord.md` | DiscordAdapter 是基于 Discord Gateway (WebSocket) 和 REST API v10 协议构建的适配器，整合了 Discord Bot 的核心功能，提供统一的事件处理和消息操作接口。 |
| `platform-guide/email.md` | EmailAdapter 是基于 SMTP/IMAP 协议的邮件适配器，支持邮件发送、接收和处理。 |
| `platform-guide/ideaura.md` | IdeauraAdapter 是基于花枫咖啡馆（RockyChat）平台 API 构建的适配器，整合了所有平台功能模块，提供统一的事件处理和消息操作接口。 |
| `platform-guide/kook.md` | KookAdapter 是基于Kook（开黑啦）Bot WebSocket 协议构建的适配器，整合了Kook所有功能模块，提供统一的事件处理和消息操作接口。 |
| `platform-guide/maintain-notes.md` | 此文档由各适配器开发者维护，用于说明该适配器与 OneBot12 标准的差异和扩展功能。 |
| `platform-guide/matrix.md` | MatrixAdapter 是基于 [Matrix协议](https://spec.matrix.org/) 构建的适配器，整合了Matrix协议的所有核心功能模块，提供统一的事件处理和消息操作接口。 |
| `platform-guide/minecraft.md` | MinecraftAdapter 是基于 RCON 协议的 Minecraft Java 版服务器适配器，支持命令执行、消息发送与日志事件监听。 |
| `platform-guide/onebot11.md` | OneBot11Adapter 是基于 OneBot V11 协议构建的适配器。 |
| `platform-guide/onebot12.md` | OneBot12Adapter 是基于 OneBot V12 协议构建的适配器，作为 ErisPulse 框架的基线协议适配器。 |
| `platform-guide/qqbot.md` | QQBotAdapter 是基于QQ官方机器人（QQ OpenAPI）协议构建的适配器，整合群聊、私聊、频道等全场景功能，提供 OneBot12 标准事件、标准Api动作与请求操作接口。 |
| `platform-guide/sandbox.md` | SandboxAdapter 是 ErisPulse 内置的沙盒适配器，用于本地开发与模块调试——无需真实平台即可模拟消息收发。 |
| `platform-guide/snowluma.md` | SnowLumaAdapter 是基于 SnowLuma 后端（NTQQ hook）构建的适配器，使用 OneBot v11 协议通信。 |
| `platform-guide/telegram.md` | TelegramAdapter 是基于 Telegram Bot API 构建的适配器，支持多种消息类型和事件处理。 |
| `platform-guide/terminal.md` | TerminalAdapter 是命令行终端适配器——终端即聊天会话，用于本地快速调试模块逻辑。 |
| `platform-guide/webhook.md` | 本文档详细说明 Webhook 适配器的双向桥接协议、字段映射与实现特性。 |
| `platform-guide/wechatmp.md` | | 方法 | 说明 | 微信 API | |
| `platform-guide/wecom.md` | WeComAdapter 是基于企业微信自建应用 API 构建的适配器，通过回调接收消息、应用消息接口主动发送，并提供通讯录与消息卡片能力。 |
| `platform-guide/yunhu.md` | YunhuAdapter 是基于云湖协议构建的适配器，整合了所有云湖功能模块，提供统一的事件处理和消息操作接口。 |
| `platform-guide/yunhu_user.md` | YunhuUserAdapter 是基于云湖用户账户协议构建的适配器，通过用户邮箱账户登录，使用 WebSocket 接收事件，提供统一的事件处理和消息操作接口。 |

### showcase/

| 文档 | 什么时候读 |
|---|---|
| `showcase/README.md` | 当你在几个机器人框架 / AI 机器人平台之间做选择，想知道 ErisPulse 适合谁、不适合谁时读这篇。已经在用 ErisPulse 则跳过。 |
| `showcase/comparison-agent-platforms.md` | 当你想要的是"群里的 AI 助手"，正在 AstrBot / LangBot 这类一体化平台和 ErisPulse 之间选型时读这篇。要写非 AI 业务代码则看 [对比：NoneBot2](comparison-nonebot.md)。 |
| `showcase/comparison-nonebot.md` | 当你会在 Python 机器人框架里写代码，正在 NoneBot2 和 ErisPulse 之间选型时读这篇。不写代码则跳过。 |
| `showcase/migrate-from-astrbot.md` | 当你已有一个 AstrBot 机器人，想把它迁到 ErisPulse 时读这篇。全新搭建请直接看[快速开始](../quick-start.md)。 |

### standards/

| 文档 | 什么时候读 |
|---|---|
| `standards/README.md` | 当你在开发或修改适配器，需要确认事件转换、API 响应、发送方法等是否符合 ErisPulse 跨平台标准时，从本目录找对应规范对照。不确定从哪篇开始时，先读下方总纲。 |
| `standards/api-action-spec.md` | 当你在适配器中实现 Api DSL 标准动作（get_user_info / delete_message 等），或在模块中跨平台调用这些标准动作、需要确认参数与 data 字段时对照本文。 |
| `standards/api-response.md` | 当你在适配器中实现 `call_api` / Send / Request 的返回值，需要确认响应结构与返回码是否符合 ErisPulse 标准，或排查某个 `retcode` 的含义时对照本文。 |
| `standards/event-conversion.md` | 当你在适配器中把平台原生事件转换为 OneBot12 标准事件——确认必须字段、消息段结构、扩展字段命名（`{platform}_` 前缀）、会话类型推断时对照本文。 |
| `standards/request-action-spec.md` | 当你的适配器需要处理好友请求/群邀请（转换请求事件、实现 `accept`/`reject`），或模块中要用 `event.approve()` / `event.reject()` 审批请求时对照本文。 |
| `standards/send-method-spec.md` | 当你在适配器中实现 Send 类——方法命名、媒体参数（URL/路径/bytes）的形态支持、`Raw_ob12` 反向转换、合并转发能力时对照本文。 |
| `standards/session-types.md` | 当你在适配器中把平台原生会话映射到标准类型（private/group/channel/guild/thread），或在模块中不确定 `Send.To()` 该传什么目标类型、想搞清 `event.reply()` 的自动转换时对照本文。 |
| `standards/standardization-guide.md` | 当你开发新适配器，或要为某个平台新增能力、需要决定"进标准还是走 `{platform}_` 扩展"、命名怎么起、平台差异怎么处理时先读本文。只是查某一领域的具体规范，可直接跳到 §2 标准地图对应的文档。 |

### styleguide/

| 文档 | 什么时候读 |
|---|---|
| `styleguide/README.md` | 本目录包含 ErisPulse 项目的工程纪律与写作规范。 |
| `styleguide/docs-writing.md` | ……不需要则跳过"**；核心必读类用 `> [!NOTE]` 标注其在阅读路径中的位置。 |
| `styleguide/docstring.md` | 在创建EP核心方法时必须添加方法注释，注释格式如下： |
| `styleguide/engineering.md` | 本页是 ErisPulse 源码的健壮性纪律。每条规则给出"为什么"与本仓库的真实案例；贡献代码前请过一遍本页，CI 之外的部分靠评审执行。 |
| `styleguide/glossary.md` | 写文档 / 改文档时拿不准一个概念该叫什么，或发现两篇文档对同一概念说法不一致时。 |

### user-guide/

| 文档 | 什么时候读 |
|---|---|
| `user-guide/README.md` | 需要安装环境、配置 `config.toml`、用 `epsdk` 管理组件，或把机器人部署上线时按篇查阅。 |
| `user-guide/cli-reference.md` | 忘记某个 `epsdk` 命令的参数、想把组件管理写进脚本，或要控制 run / stop / restart 行为时查阅。日常只用 `init` / `install` / `run` 的话，记住一条就够：`epsdk <命令> --help` 随时可查参数说明，不需要通读本文。 |
| `user-guide/configuration.md` | - 连接参数变更后需重启框架生效；连接池创建瞬时失败会自动指数退避重试 |
| `user-guide/deployment.md` | 机器人要长期挂着跑时——Docker 部署、systemd / Supervisor 进程守护、反向代理与 SSL、备份与升级都在这里。本地开发调试阶段。 |
| `user-guide/installation.md` | 需要挑一种安装方式（pip / uv / Docker / ErisPulse-App 客户端），或安装失败要排查时读。只想最快跑起来，[5 分钟快速开始](../quick-start.md) 已覆盖最简流程，。 |

> 由 `python -m scripts.tools gen skills` 生成，请勿手改。
