# ErisPulse Docs Pack (ru)

Auto-packed by CI from `docs/ru/`: all documents as-is (no merging, no rewriting), plus this README as the index.

## Usage

1. Unzip and put the folder into your workspace (IDE / agent), or feed individual documents to the AI as needed
2. Pick documents via the index below: check "when to read" and load only what you need

## Index

### Root documents

| Document | When to read |
|---|---|
| `README.md` | ErisPulse — это фреймворк асинхронного модульного робота, основанный на событиях — бизнес-код пишется один раз, а через адаптеры разворачивается на QQ, Telegram, Kook, Yunhu и других платформах. Система плагинов, горячая перезагрузка и полноценный инструментарий разработчика предоставляются из коробки. |
| `architecture.md` | **Когда читать эту статью**: если вы хотите понять, что происходит за кулисами фреймворка — как проходит сообщение, в каком порядке инициализируются модули, что происходит при горячем перезагрузке, или если вы хотите разобраться, почему фреймворк ведёт себя так, как он ведёт. Если вы хотите просто писать обработчики, достаточно прочитать [Введение в обработку событий](getting-started/event-handling.md); если нет необходимости, можете пропустить эту статью. |
| `bug-tracker.md` | Документация отслеживает известные ошибки ErisPulse SDK и их исправления, отсортированные по времени исправления. |
| `quick-start.md` | **1. Установка** (Python >= 3.10): |

### advanced/

| Document | When to read |
|---|---|
| `advanced/README.md` | В этом разделе собраны продвинутые темы фреймворка ErisPulse — контроль доступа, грейд-деплой, многошаговые взаимодействия, хранилища и другие глубокие возможности. Каждая статья решает конкретную задачу. |
| `advanced/client.md` | **Когда нужно читать эту статью**: при необходимости исходящих HTTP / WebSocket-запросов. Если не нужно, пропустите, это не повлияет на использование других функций. |
| `advanced/connections.md` | **Когда стоит читать этот документ**: когда требуется пул соединений WebSocket/SSE, групповая рассылка, межмодульная отправка или просмотр соединений. Если это не нужно — пропустите, на использование других функций это не повлияет. |
| `advanced/conversation.md` | когда нужны конечный автомат многоходового диалога и восстановление из контрольных точек. Если это не нужно — пропустите, на использование остальных функций это не влияет.。 |
| `advanced/errors.md` | Все пользовательские исключения ErisPulse наследуются от `ErisPulseError`. Исключения底层 библиотек (например, aiohttp, aiomysql и т.д.) будут перехватываться внутри фреймворка и преобразовываться в соответствующие исключения ErisPulse — код бизнес-логики **не должен зависеть от типов исключений底层 библиотек**. |
| `advanced/i18n.md` | **Когда нужно это читать**: при необходимости многоязычного контента, регистрации переводов или определения языка. Если не нужно, пропустите, это не повлияет на использование других функций. |
| `advanced/interaction.md` | **Когда это нужно читать**: при необходимости `wait_reply`, многоконтактного диалога, периодических напоминаний, взаимоисключающих сессий или трассировки цепочки. Если не нужно — пропустите, это не повлияет на использование других функций. |
| `advanced/lazy-loading.md` | **Когда нужно читать эту статью**: при использовании ленивой загрузки модулей или активации по событию activate_on. Если не нужно, можно пропустить, это не повлияет на использование других функций. |
| `advanced/lifecycle.md` | **Когда нужно читать эту статью**: когда необходимо подписаться на события жизненного цикла фреймворка (запуск / загрузка / изменение состояния). Если не нужно, пропустите, это не повлияет на использование других функций. |
| `advanced/message-builder.md` | **Когда нужно читать эту статью**: при построении сложных или многочастных сообщений. Если не нужно, можно пропустить, это не повлияет на использование других функций. |
| `advanced/module-communication.md` | **Когда читать эту статью**: при необходимости вызова между модулями (RPC), определении контракта сервиса, целевой рассылке событий или восстановлении при холодном запуске. Если это не требуется — пропустите, это не повлияет на использование других функций. |
| `advanced/ownership.md` | **Когда читать эту статью**: при диагностике утечек ресурсов, понимании цепочки очистки при отключении или объявлении принадлежности ресурсов. Если не нужно, можно пропустить, это не повлияет на использование других функций. |
| `advanced/performance.md` | **Когда нужно читать эту статью**: если вас интересуют цифры пропускной способности и задержки событий, оценка производительности перед развертыванием, или если вы хотите сравнить производительность до и после обновления версии. Если вам это не нужно, можете пропустить эту статью, это не повлияет на использование других функций. |
| `advanced/router.md` | **Когда стоит читать этот документ**: когда требуются маршруты HTTP / WebSocket / SSE (включая широковещательные рассылки через пул соединений). Если нет — можно пропустить, это не влияет на использование остальных функций. |
| `advanced/runtime.md` | **Когда нужно читать эту статью**: если вы хотите получить обзор всех |
| `advanced/scope.md` | когда нужно управлять доступностью модулей, допуском событий или ограничениями исходящих действий. Если это не требуется — пропустите, на использование остальных функций это не повлияет.。 |
| `advanced/shadow.md` | **Когда читать эту статью**: при необходимости постепенного развертывания — одновременная пробная работа новой версии, сравнение поведения и принятие решения о переходе или откате. Если вам это не нужно, можете пропустить эту статью — это не повлияет на использование других функций. |
| `advanced/sql-builder.md` | **Когда нужно читать эту статью:** при необходимости цепочечного SQL-запроса или при использовании пользовательского хранилища. Если не нужно, пропустите, это не повлияет на использование других функций. |
| `advanced/startup.md` | **Когда нужно читать эту статью:** если вам нужно вручную управлять цепочкой запуска, настраивать последовательность запуска или устранять неполадки при запуске. Если не нужно, можете пропустить, это не повлияет на использование других функций. |
| `advanced/storage-backends.md` | **Когда стоит читать этот документ**: при переключении между sqlite / mysql / postgres или при использовании пользовательского бэкенда хранилища. Если это не требуется — пропустите, на использование остальных функций это не влияет. |
| `advanced/transcript.md` | **Когда стоит читать этот документ**: когда нужны история сообщений, восстановление диалога или настройка политики хранения входящих. Если в этом нет необходимости — пропустите; на использование остальных функций это не влияет. |

### api-reference/

| Document | When to read |
|---|---|
| `api-reference/README.md` | когда вы пишете модуль или адаптер и вам нужно посмотреть примеры использования какого-либо основного модуля (Storage/Config/Logger/Router и т.д.), системы событий или API управления адаптерами — перейдите к соответствующему разделу из списка документов ниже. Если это не нужно — пропустите.。 |
| `api-reference/adapter-system.md` | **Когда нужно читать эту статью**: если вам нужно управлять адаптерами (получение экземпляров, запуск/остановка, проверка онлайн-статуса бота), использовать DSL-DSL для отправки сообщений, регистрировать промежуточные обработчики (middleware), или интегрировать отправку статуса бота (события meta) в адаптер, обратитесь к этой статье. Если это не требуется, пропустите. |
| `api-reference/auto_api/ErisPulse/CLI/__init__.md` | CLI 模块 |
| `api-reference/auto_api/ErisPulse/CLI/base.md` | CLI 命令基类 |
| `api-reference/auto_api/ErisPulse/CLI/cli.md` | 主 CLI 类 |
| `api-reference/auto_api/ErisPulse/CLI/commands/__init__.md` | 命令模块 |
| `api-reference/auto_api/ErisPulse/CLI/commands/config.md` | Config 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/create.md` | Create 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/doctor.md` | Doctor 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/init.md` | Init 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/install.md` | Install 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/language.md` | Language 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/list.md` | List 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/list_remote.md` | List-Remote 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/run.md` | Run 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/runtime.md` | Stop / Restart 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/self_update.md` | Self-Update 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/types.md` | Types 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/uninstall.md` | Uninstall 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/upgrade.md` | Upgrade 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/version.md` | Version 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/console.md` | CLI 控制台模块 |
| `api-reference/auto_api/ErisPulse/CLI/constants.md` | CLI 本地常量 |
| `api-reference/auto_api/ErisPulse/CLI/hints.md` | ErisPulse CLI 友好提示引擎 |
| `api-reference/auto_api/ErisPulse/CLI/i18n/__init__.md` | ErisPulse CLI 国际化模块 |
| `api-reference/auto_api/ErisPulse/CLI/i18n/locales/__init__.md` | CLI 内置翻译数据加载器 |
| `api-reference/auto_api/ErisPulse/CLI/i18n/locales/en.md` | CLI English translations (en) |
| `api-reference/auto_api/ErisPulse/CLI/i18n/locales/ja.md` | CLI 日本語翻訳 (ja) |
| `api-reference/auto_api/ErisPulse/CLI/i18n/locales/ru.md` | CLI Русский перевод (ru) |
| `api-reference/auto_api/ErisPulse/CLI/i18n/locales/zh_cn.md` | CLI 简体中文翻译 (zh-CN) |
| `api-reference/auto_api/ErisPulse/CLI/i18n/locales/zh_tw.md` | CLI 繁體中文翻譯 (zh-TW) |
| `api-reference/auto_api/ErisPulse/CLI/registry.md` | CLI 命令注册器 |
| `api-reference/auto_api/ErisPulse/CLI/utils/__init__.md` | ErisPulse SDK 工具模块 |
| `api-reference/auto_api/ErisPulse/CLI/utils/config_wizard.md` | ErisPulse CLI 配置向导共享工具 |
| `api-reference/auto_api/ErisPulse/CLI/utils/display.md` | ErisPulse CLI 显示工具 |
| `api-reference/auto_api/ErisPulse/CLI/utils/interactive.md` | CLI 交互式提示统一封装 |
| `api-reference/auto_api/ErisPulse/CLI/utils/package_manager.md` | ErisPulse SDK 包管理器 |
| `api-reference/auto_api/ErisPulse/CLI/utils/runtime_state.md` | 运行实例状态文件（pidfile）工具 |
| `api-reference/auto_api/ErisPulse/CLI/utils/scaffold_text.md` | 脚手架模板多语言文案 |
| `api-reference/auto_api/ErisPulse/Core/Bases/__init__.md` | ErisPulse 基础模块 |
| `api-reference/auto_api/ErisPulse/Core/Bases/adapter.md` | ErisPulse 适配器基础模块 |
| `api-reference/auto_api/ErisPulse/Core/Bases/adapter_patterns.md` | ErisPulse 适配器通信模式基类 |
| `api-reference/auto_api/ErisPulse/Core/Bases/api_dsl.md` | ErisPulse 标准 API 动作 DSL 模块 |
| `api-reference/auto_api/ErisPulse/Core/Bases/client.md` | ErisPulse HTTP 客户端抽象基类 |
| `api-reference/auto_api/ErisPulse/Core/Bases/config_schema.md` | ErisPulse 通用配置 Schema 模块 |
| `api-reference/auto_api/ErisPulse/Core/Bases/converter.md` | OneBot12 事件转换器基类 |
| `api-reference/auto_api/ErisPulse/Core/Bases/errors.md` | ErisPulse 异常体系 |
| `api-reference/auto_api/ErisPulse/Core/Bases/i18n_schema.md` | ErisPulse i18n 键声明 Schema 模块 |
| `api-reference/auto_api/ErisPulse/Core/Bases/kv_builder.md` | ErisPulse KV 查询构建器 |
| `api-reference/auto_api/ErisPulse/Core/Bases/manager.md` | ErisPulse 管理器基类 |
| `api-reference/auto_api/ErisPulse/Core/Bases/model.md` | ErisPulse 数据模型层（ORM）—— 声明式模型与 Active Record CRUD |
| `api-reference/auto_api/ErisPulse/Core/Bases/module.md` | ErisPulse 模块基础模块 |
| `api-reference/auto_api/ErisPulse/Core/Bases/router.md` | ErisPulse 路由抽象基类 |
| `api-reference/auto_api/ErisPulse/Core/Bases/send_builder.md` | SendDSL 批量构建系统 |
| `api-reference/auto_api/ErisPulse/Core/Bases/send_rules.md` | SendDSL 发送规则系统 |
| `api-reference/auto_api/ErisPulse/Core/Bases/sql_base.md` | ErisPulse SQL 存储共享基类 |
| `api-reference/auto_api/ErisPulse/Core/Bases/storage.md` | ErisPulse 存储基类 |
| `api-reference/auto_api/ErisPulse/Core/Bases/websocket.md` | ErisPulse WebSocket 共享基类 |
| `api-reference/auto_api/ErisPulse/Core/Event/__init__.md` | ErisPulse 事件处理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/base.md` | ErisPulse 事件处理基础模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/command.md` | ErisPulse 命令处理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/command_args.md` | ErisPulse 命令参数与选项解析模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/command_flow.md` | 命令多轮流控语法糖（``.got()`` 链） |
| `api-reference/auto_api/ErisPulse/Core/Event/conversation.md` | ErisPulse 多轮对话上下文模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/governance.md` | ErisPulse 命令治理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/interaction.md` | ErisPulse 交互会话管理 |
| `api-reference/auto_api/ErisPulse/Core/Event/message.md` | ErisPulse 消息处理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/message_builder.md` | ErisPulse 消息构建器 |
| `api-reference/auto_api/ErisPulse/Core/Event/meta.md` | ErisPulse 元事件处理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/notice.md` | ErisPulse 通知处理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/overrides.md` | ErisPulse 事件覆写系统（overrides） |
| `api-reference/auto_api/ErisPulse/Core/Event/request.md` | ErisPulse 请求处理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/session_type.md` | ErisPulse 会话类型管理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/throttle.md` | 事件处理器节流（throttle=）与防抖（debounce=，EPRFC-2026-001 方向八） |
| `api-reference/auto_api/ErisPulse/Core/Event/trace.md` | 分发决策链追踪（EPRFC-2026-001 方向五：模块排查的场景三） |
| `api-reference/auto_api/ErisPulse/Core/Event/wrapper.md` | ErisPulse 事件包装类 |
| `api-reference/auto_api/ErisPulse/Core/__init__.md` | ErisPulse 核心模块 |
| `api-reference/auto_api/ErisPulse/Core/adapter.md` | ErisPulse 适配器系统 |
| `api-reference/auto_api/ErisPulse/Core/assets/__init__.md` | ErisPulse 前端资源 |
| `api-reference/auto_api/ErisPulse/Core/client.md` | ErisPulse HTTP/WS 客户端 |
| `api-reference/auto_api/ErisPulse/Core/config.md` | ErisPulse 配置中心 |
| `api-reference/auto_api/ErisPulse/Core/connections.md` | ErisPulse 连接注册表（连接池） |
| `api-reference/auto_api/ErisPulse/Core/constants.md` | ErisPulse 内部常量定义 |
| `api-reference/auto_api/ErisPulse/Core/di.md` | ErisPulse 依赖注入模块 |
| `api-reference/auto_api/ErisPulse/Core/i18n/__init__.md` | ErisPulse 国际化模块 |
| `api-reference/auto_api/ErisPulse/Core/i18n/constants.md` | ErisPulse i18n 常量定义 |
| `api-reference/auto_api/ErisPulse/Core/i18n/locales/__init__.md` | ErisPulse 内置翻译数据包 |
| `api-reference/auto_api/ErisPulse/Core/i18n/locales/en.md` | English translation data (en) |
| `api-reference/auto_api/ErisPulse/Core/i18n/locales/ja.md` | 日本語翻訳データ (ja) |
| `api-reference/auto_api/ErisPulse/Core/i18n/locales/ru.md` | Русский перевод (ru) |
| `api-reference/auto_api/ErisPulse/Core/i18n/locales/zh_cn.md` | 简体中文翻译数据 (zh-CN) |
| `api-reference/auto_api/ErisPulse/Core/i18n/locales/zh_tw.md` | 繁體中文翻譯資料 (zh-TW) |
| `api-reference/auto_api/ErisPulse/Core/lifecycle.md` | ErisPulse 生命周期管理模块 |
| `api-reference/auto_api/ErisPulse/Core/logger.md` | ErisPulse 日志系统 |
| `api-reference/auto_api/ErisPulse/Core/master.md` | 框架主人管理系统 |
| `api-reference/auto_api/ErisPulse/Core/module.md` | ErisPulse 模块系统 |
| `api-reference/auto_api/ErisPulse/Core/ownership.md` | ErisPulse 归属权统一门面 |
| `api-reference/auto_api/ErisPulse/Core/router.md` | ErisPulse 路由系统 |
| `api-reference/auto_api/ErisPulse/Core/scope.md` | ErisPulse 作用域（scope） |
| `api-reference/auto_api/ErisPulse/Core/shadow.md` | ErisPulse 影子模块（方向十一：Shadow Modules & Canary Promote） |
| `api-reference/auto_api/ErisPulse/Core/storage/__init__.md` | ErisPulse 存储管理模块 |
| `api-reference/auto_api/ErisPulse/Core/storage/mysql.md` | ErisPulse MySQL 存储后端（aiomysql 异步原生实现） |
| `api-reference/auto_api/ErisPulse/Core/storage/postgres.md` | ErisPulse PostgreSQL 存储后端（asyncpg 异步原生实现） |
| `api-reference/auto_api/ErisPulse/Core/storage/sqlite.md` | ErisPulse SQLite 存储后端（aiosqlite 异步原生实现） |
| `api-reference/auto_api/ErisPulse/Core/text_match.md` | ErisPulse 统一文本/条目匹配工具 |
| `api-reference/auto_api/ErisPulse/Core/transcript.md` | ErisPulse 会话收件箱（transcript） |
| `api-reference/auto_api/ErisPulse/__init__.md` | ErisPulse SDK 主模块 |
| `api-reference/auto_api/ErisPulse/__main__.md` | ErisPulse SDK 命令行工具 |
| `api-reference/auto_api/ErisPulse/finders/__init__.md` | ErisPulse 发现器模块 |
| `api-reference/auto_api/ErisPulse/finders/adapter.md` | ErisPulse 适配器发现器 |
| `api-reference/auto_api/ErisPulse/finders/bases/finder.md` | ErisPulse 基础发现器 |
| `api-reference/auto_api/ErisPulse/finders/module.md` | ErisPulse 模块发现器 |
| `api-reference/auto_api/ErisPulse/loaders/__init__.md` | ErisPulse 加载器模块 |
| `api-reference/auto_api/ErisPulse/loaders/_reload_utils.md` | 热重载共用工具：字节码缓存清理与卸载前语法预检 |
| `api-reference/auto_api/ErisPulse/loaders/adapter.md` | ErisPulse 适配器加载器 |
| `api-reference/auto_api/ErisPulse/loaders/bases/loader.md` | ErisPulse 基础加载器 |
| `api-reference/auto_api/ErisPulse/loaders/module.md` | ErisPulse 模块加载器 |
| `api-reference/auto_api/ErisPulse/loaders/plugin_folder.md` | ErisPulse 本地插件文件夹加载器 |
| `api-reference/auto_api/ErisPulse/loaders/strategy.md` | ErisPulse 模块加载策略 |
| `api-reference/auto_api/ErisPulse/loaders/strict.md` | ErisPulse 严格模式 |
| `api-reference/auto_api/ErisPulse/runtime/__init__.md` | ErisPulse 运行时配置和管理模块 |
| `api-reference/auto_api/ErisPulse/runtime/config_schema.md` | ErisPulse 通用配置 Schema 模块（向后兼容 shim） |
| `api-reference/auto_api/ErisPulse/runtime/context.md` | ErisPulse 运行时上下文 |
| `api-reference/auto_api/ErisPulse/runtime/dev_watch.md` | 开发模式细粒度热重载监控 |
| `api-reference/auto_api/ErisPulse/runtime/diagnostics.md` | ErisPulse 异常诊断模块 |
| `api-reference/auto_api/ErisPulse/runtime/example_config.md` | config.full.example 完整配置参考生成器（runtime / CLI 共用） |
| `api-reference/auto_api/ErisPulse/runtime/exceptions.md` | ErisPulse 全局异常处理系统 |
| `api-reference/auto_api/ErisPulse/runtime/file_watcher.md` | 文件变更监控 |
| `api-reference/auto_api/ErisPulse/runtime/frame_config.md` | ErisPulse 框架配置管理模块 |
| `api-reference/auto_api/ErisPulse/runtime/hints.md` | ErisPulse 友好错误提示引擎 |
| `api-reference/auto_api/ErisPulse/runtime/kernel.md` | 统一编排内核（组合根） |
| `api-reference/auto_api/ErisPulse/runtime/memory.md` | 进程内存追踪工具 |
| `api-reference/auto_api/ErisPulse/runtime/metrics.md` | 进程内指标计数器（轻量注册表） |
| `api-reference/auto_api/ErisPulse/runtime/owner_cleanup.md` | 归属清理钩子（owner cleanup hooks） |
| `api-reference/auto_api/ErisPulse/runtime/plugin_reload.md` | ErisPulse 本地插件热重载监控 |
| `api-reference/auto_api/ErisPulse/runtime/proactive_gc.md` | ErisPulse 主动 GC 周期任务 |
| `api-reference/auto_api/ErisPulse/runtime/process_state.md` | 跨进程运行状态契约（SDK 侧） |
| `api-reference/auto_api/ErisPulse/runtime/reload_ops.md` | 热重载操作协调器 |
| `api-reference/auto_api/ErisPulse/runtime/reload_target.md` | 热重载目标判定 |
| `api-reference/auto_api/ErisPulse/runtime/resource_track.md` | 合作式资源登记（tracked resources） |
| `api-reference/auto_api/ErisPulse/runtime/sdk_initializer.md` | ErisPulse SDK 初始化 / 反初始化协调器 |
| `api-reference/auto_api/ErisPulse/runtime/tasks.md` | 后台任务管理工具 |
| `api-reference/auto_api/ErisPulse/runtime/troubleshoot.md` | 模块排查诊断（EPRFC-2026-001 方向五·场景一 / 二） |
| `api-reference/auto_api/ErisPulse/runtime/version.md` | SDK 版本解析与比较 |
| `api-reference/auto_api/ErisPulse/sdk.md` | ErisPulse SDK 主类 |
| `api-reference/auto_api/README.md` | 本文档包含 ErisPulse SDK 的所有 API 参考文档。 |
| `api-reference/core-modules.md` | **Когда следует читать эту статью**: когда вам нужно использовать основные возможности, такие как хранилище, конфигурация, логирование, управление модулями, маршрутизация, HTTP-клиент и т.д., и вы не помните точные сигнатуры методов, обратитесь к этой статье для быстрого ознакомления. Если не нужно, пропустите. |
| `api-reference/event-system.md` | **Когда нужно читать эту статью**: когда вам нужно зарегистрировать команду, слушать события сообщений/уведомлений/запросов или использовать методы взаимодействия с событиями, такие как `event.reply()` / `wait_reply()` / `confirm()` и т.д. Если это не нужно, пропустите. |

### contributing/

| Document | When to read |
|---|---|
| `contributing/README.md` | **Когда стоит это прочитать**: если вы хотите внести свой вклад в ErisPulse, но ещё не уверены, что именно можно сделать или с чего начать. Если вы только пользуетесь ботом и не участвуете в разработке, можете пропустить этот документ. |
| `contributing/first-contribution.md` | **Когда нужно читать эту статью**: когда готовитесь отправить свой первый Pull Request — каждая стадия от fork до слияния снабжена командами, которые можно просто скопировать. Если у вас уже есть опыт PR и вам нужно просто проверить правила репозитория, перейдите к [CONTRIBUTING.md](../../../CONTRIBUTING.md). |

### developer-guide/

| Document | When to read |
|---|---|
| `developer-guide/README.md` | когда вы готовитесь разрабатывать расширения для ErisPulse — добавлять боту новые функции (модули) или подключать новые платформы (адаптеры). Если вы просто хотите пользоваться ботом, пропустите этот документ и переходите сразу к [Быстрому старту](../quick-start.md).。 |
| `developer-guide/adapters/best-practices.md` | **Когда читать эту статью**: после запуска шаблона адаптера рекомендуется прочитать (оптимальные практики инженерии). Если не нужно, пропустите, это не повлияет на использование других функций. |
| `developer-guide/adapters/converter.md` | **Когда читать эту статью**: обязательно при разработке адаптера (конвертер событий). Не нужно — пропустите, это не повлияет на использование других функций. |
| `developer-guide/adapters/core-concepts.md` | **Когда читать эту статью**: Обязательно при разработке адаптера (полное описание основных механизмов: `BaseAdapter`, `SendDSL`, жизненного цикла и т.д.). Для быстрого старта можно сначала прочитать [Введение в разработку адаптера](getting-started.md), а при возникновении вопросов "почему так" — обратиться к этой статье. |
| `developer-guide/adapters/getting-started.md` | **Когда читать эту статью**: вводная статья по пути разработки адаптеров (обязательно к прочтению). От нуля написать адаптер, понять границы ответственности адаптера и структуру проекта — всё это здесь; прочитав, переходите к [конвертерам событий](converter.md) и [подробному разбору SendDSL](send-dsl.md) по мере необходимости. |
| `developer-guide/adapters/send-dsl.md` | 适配器开发路径内必读（发送 DSL）。 |
| `developer-guide/configuration.md` | Система конфигурации ErisPulse является **декларативной**: разработчики описывают параметры конфигурации с помощью полей dataclass и метаданных, а фреймворк `get_config_schema()` преобразует их в JSON Schema, который может быть использован любым потребителем (панель управления, сторонняя панель, CLI-модуль и т.д.) для отображения. В этой статье приведено **нормативное определение** этих метаданных — семантика виджетов, форма значений, условия отображения и обязательства по совместимости определяются исключительно здесь; конкретная реализация за потребителями, но семантика должна соответствовать этой статье. |
| `developer-guide/modules/best-practices.md` | **Когда стоит читать этот документ**: рекомендуется прочитать после написания первого модуля (инженерные лучшие практики). Если это не нужно — пропустите, на использование остального функционала это не влияет. |
| `developer-guide/modules/core-concepts.md` | В этой статье подробно объясняется полный жизненный цикл модуля от загрузки до выгрузки, методы объявления конфигурации и хранения данных — что делает за вас фреймворк, а что вам нужно написать самостоятельно. Прочитав статью, вы получите полное представление. |
| `developer-guide/modules/event-wrapper.md` | Параметр `event` в обработчиках, который позволяет напрямую вызывать `.get_text()` / `.reply()` / `.wait_reply()`, работает благодаря классу-обёртке Event. В данной статье представлен полный список методов — используйте его при написании обработчиков событий, методы и их поведение должны соответствовать описанию ниже. |
| `developer-guide/modules/getting-started.md` | Следуя этой статье, вы получите запускаемый модуль, который будет отвечать на команду `/hello`, и узнаете структуру проекта модуля, способ регистрации и обработчики загрузки/выгрузки — все последующие документы по модулям строятся на этой основе. |
| `developer-guide/orm.md` | **Когда читать эту статью**: Когда вам нужны модели данных, автоматическое создание таблиц или сопоставление отношений. Если не нужно, пропустите, это не повлияет на использование других функций. |
| `developer-guide/publishing.md` | при публикации вашей работы на PyPI / в магазин модулей. Если это не требуется, пропустите — это не повлияет на использование других функций.。 |
| `developer-guide/testing.md` | **Когда стоит читать этот документ**: при написании автоматических тестов для собственного модуля. Если это не нужно, пропустите — на использование остальных функций это не влияет. |

### ecosystem/

| Document | When to read |
|---|---|
| `ecosystem/README.md` | Сама платформа ErisPulse предоставляет только основные возможности (система событий, система модулей, конфигурация, маршрутизация, логирование и т.д.), **не включая в себя** такие "тяжелые" функции, как GUI, рендеринг изображений, визуализация и т.д. Эти возможности предоставляются **третьими сторонами** и поддерживаются сообществом, и устанавливаются по мере необходимости. |
| `ecosystem/apimcp.md` | **何时需要阅读本文**：当你希望使用支持 MCP 的人工智能客户端（如 Claude Desktop）直接控制你的机器人——发送和接收消息、调用模块、管理适配器、监控事件流——时阅读本文。否则可以跳过。 |
| `ecosystem/app.md` | **Когда стоит читать эту статью**: когда вы хотите создавать, запускать и управлять экземплярами роботов с помощью графического интерфейса на телефоне или компьютере — без использования терминала и без отдельной установки среды Python. Если вам это не нужно, можете пропустить. |
| `ecosystem/cron.md` | **Когда стоит читать этот документ**: когда вашему модулю требуется логика запуска по расписанию или с задержкой (напоминания по расписанию, периодический мониторинг, планирование по Cron-выражениям), и вы хотите, чтобы задачи не терялись после перезапуска фреймворка. Если это не ваш случай — пропустите. |
| `ecosystem/dashboard.md` | **Когда это нужно читать:** Когда вы хотите использовать веб-интерфейс для визуального управления роботом (включение/выключение модулей, редактирование конфигурации, просмотр логов, мониторинг потоков событий), или хотите зарегистрировать страницу управления для своего модуля. Если не нужно — пропустите. |
| `ecosystem/qvqchat.md` | **Когда стоит читать этот документ**: когда вы хотите добавить боту возможности ИИ-агента (цикл инструментов, потоковый диалог, MCP, долговременная память) или открыть службы своего модуля для вызова агентом. Если это не нужно — пропустите. |
| `ecosystem/takumi.md` | когда вам нужно отрендерить HTML / дерево узлов / Jinja-шаблон в изображение для отправки в чат-платформу (карточки статистики, таблицы лидеров, длинные статьи с текстом и графикой). Если это не требуется — пропустите.。 |

### getting-started/

| Document | When to read |
|---|---|
| `getting-started/README.md` | **Когда стоит прочитать эту статью**: ваш робот уже запущен с помощью [Быстрого старта за 5 минут](../quick-start.md), и вы хотите системно понять ключевые концепции фреймворка и в полной мере освоить его часто используемые возможности. Если робот ещё не запущен — сначала пройдите быстрый старт; если же нужно просто найти ответ на конкретный вопрос — переходите сразу к соответствующей отдельной статье. |
| `getting-started/basic-concepts.md` | Какие компоненты проходит сообщение от отправки пользователем до ответа бота? За что отвечают адаптеры и за что модули? Прочитав эту статью, вы сможете самостоятельно отвечать на вопросы по дизайну, возникающие при написании обработчиков, вместо того чтобы просто копировать примеры. |
| `getting-started/common-tasks.md` | когда нужно добавить боту какую-то конкретную функцию, обращайтесь к нужному разделу — персистентность, задачи по расписанию, фильтрация сообщений, контроль прав, пакетная отправка; каждый раздел — законченный пример, который можно сразу скопировать. Для системного изучения обработки событий сначала прочитайте [Введение в обработку событий](event-handling.md); если это не нужно — пропустите.。 |
| `getting-started/event-handling.md` | **Когда стоит прочитать эту статью**: когда вы хотите, чтобы бот реагировал на сообщения, команды, уведомления, запросы, или когда нужно реализовать ожидание ответа / многоконтурный диалог, или при диагностике "почему команда не срабатывает". Если вам нужно просто понять архитектуру фреймворка, посмотрите [Основные понятия](basic-concepts.md); если не нужно, пропустите эту статью. |
| `getting-started/first-bot.md` | **Когда стоит читать эту статью**: бот уже запускается, и вы хотите написать первый обработчик команды `/hello`, а также разобраться, что именно делают `sdk.run` и декораторы команд. Если вы ещё не установили ErisPulse и не инициализировали проект, сначала выполните три шага из [быстрого старта за 5 минут](../quick-start.md): «Установка», «Инициализация проекта» и «Запуск проекта»; если всё готово — пропустите. |
| `getting-started/ide-completion.md` | **Когда следует читать эту статью**: если IDE не предлагает дополнение для методов платформы, специфичных для адаптера (например, `Board` в Yunhu), или для пользовательских методов модуля, выполните команду `epsdk types`, чтобы сгенерировать файл типовых заглушек; если не нужно, пропустите. |

### platform-guide/

| Document | When to read |
|---|---|
| `platform-guide/README.md` | Этот раздел поддерживается разработчиками каждого адаптера и описывает отличия данного адаптера от стандарта OneBot12 и его расширенные функции. Подробную документацию по каждой платформе см. ниже: |
| `platform-guide/bilibili.md` | BilibiliAdapter — это адаптер личных сообщений Bilibili, основанный на bilibili-api-python. Поддерживает двойную авторизацию по Cookie и сканированию QR-кода, а также обмен личными сообщениями на основе событий. |
| `platform-guide/discord.md` | DiscordAdapter — это адаптер, построенный на протоколах Discord Gateway (WebSocket) и REST API v10, объединяющий основные функции Discord Bot и предоставляющий унифицированные интерфейсы для обработки событий и операций с сообщениями. |
| `platform-guide/email.md` | EmailAdapter — это почтовый адаптер, основанный на протоколах SMTP/IMAP, поддерживающий отправку, получение и обработку электронной почты. |
| `platform-guide/ideaura.md` | IdeauraAdapter — адаптер, построенный на основе API платформы «Кафе Хуафэн» (RockyChat), объединяющий все функциональные модули платформы и предоставляющий единый интерфейс обработки событий и операций с сообщениями. |
| `platform-guide/kook.md` | KookAdapter — это адаптер, построенный на основе WebSocket-протокола бота Kook (开黑啦), объединяющий все функциональные модули Kook и предоставляющий единый интерфейс для обработки событий и операций с сообщениями. |
| `platform-guide/maintain-notes.md` | Данный документ поддерживается разработчиками адаптеров и предназначен для описания отличий и расширений, связанных с адаптером и стандартом OneBot12. |
| `platform-guide/matrix.md` | MatrixAdapter — это адаптер, построенный на основе протокола [Matrix](https://spec.matrix.org/), объединяющий все основные модули протокола Matrix и предоставляющий единый интерфейс для обработки событий и операций с сообщениями. |
| `platform-guide/minecraft.md` | MinecraftAdapter — это адаптер для сервера Minecraft Java Edition, основанный на протоколе RCON, поддерживающий выполнение команд, отправку сообщений и слушание событий журналов. |
| `platform-guide/onebot11.md` | OneBot11Adapter — это адаптер, построенный на основе протокола OneBot V11. |
| `platform-guide/onebot12.md` | OneBot12Adapter — это адаптер, построенный на основе протокола OneBot V12, выступающий в качестве базового протокольного адаптера для фреймворка ErisPulse. |
| `platform-guide/oopz.md` | | Параметр | Значение | |
| `platform-guide/qqbot.md` | QQBotAdapter — это адаптер, построенный на основе официального протокола QQ для роботов (QQ OpenAPI), объединяющий функции для чатов в группах, личных сообщениях и каналах, предоставляющий стандартные события OneBot12, стандартные API-действия и интерфейсы для запросов. |
| `platform-guide/sandbox.md` | SandboxAdapter — это встроенный адаптер песочницы ErisPulse, предназначенный для локальной разработки и отладки модулей — позволяет симулировать отправку и получение сообщений без реальной платформы. |
| `platform-guide/snowluma.md` | SnowLumaAdapter — это адаптер, построенный на базе бэкенда SnowLuma (NTQQ hook), использующий протокол OneBot v11. Он устанавливается как необязательное расширение для `ErisPulse-OneBot11Adapter[snowluma]` (команда установки: `pip install "ErisPulse-OneBot11Adapter[snowluma]"`). |
| `platform-guide/telegram.md` | TelegramAdapter — это адаптер, построенный на базе Telegram Bot API, поддерживающий различные типы сообщений и обработку событий. |
| `platform-guide/terminal.md` | TerminalAdapter — это адаптер командной строки, где терминал представляет собой чат-сессию, предназначенную для быстрой локальной отладки модулей логики. |
| `platform-guide/webhook.md` | WebhookAdapter — это двунаправленный мостовой адаптер уровня протокола, не привязанный к какой-либо конкретной платформе: на входе он преобразует JSON, отправляемый внешними системами методом POST, в события OneBot12, а на выходе преобразует вызовы Send модулей в POST-запросы к внешним системам. |
| `platform-guide/wechatmp.md` | Структура ответов и коды ошибок следуют [спецификации ответов API](../standards/api-response.md). |
| `platform-guide/wecom.md` | WeComAdapter — это адаптер, построенный на основе API самостоятельно созданных приложений WeCom. Он принимает сообщения через callback, выполняет активную отправку через интерфейс сообщений приложения, а также предоставляет возможности работы с корпоративным справочником и карточками сообщений. |
| `platform-guide/yunhu.md` | YunhuAdapter — это адаптер, построенный на протоколе Yunhu, объединяющий все функциональные модули Yunhu и предоставляющий единый интерфейс обработки событий и операций сообщений. |
| `platform-guide/yunhu_user.md` | YunhuUserAdapter — это адаптер, построенный на основе протокола пользовательских аккаунтов Yunhu. Он выполняет вход через почтовый аккаунт пользователя, получает события через WebSocket и предоставляет унифицированный интерфейс обработки событий и операций с сообщениями. |

### showcase/

| Document | When to read |
|---|---|
| `showcase/README.md` | **Когда стоит прочитать**: если вы выбираете между различными фреймворками для роботов / платформами ИИ-роботов и хотите понять, подходит ли вам ErisPulse, а подходит ли он не всем, прочитайте это. Если вы уже используете ErisPulse, пропустите. |
| `showcase/comparison-agent-platforms.md` | **Когда стоит читать эту статью**: если вам нужен «AI-ассистент в групповом чате» и вы выбираете между интегрированной платформой вроде AstrBot / LangBot и ErisPulse. Если же вы хотите писать не связанную с AI бизнес-логику, смотрите [Сравнение: NoneBot2](comparison-nonebot.md). |
| `showcase/comparison-nonebot.md` | **Когда нужно читать эту статью**: Когда вы пишете код в Python-фреймворке для ботов и выбираете между NoneBot2 и ErisPulse. Если не пишете код, пропустите. |
| `showcase/migrate-from-astrbot.md` | если у вас уже есть бот на AstrBot и вы хотите перенести его на ErisPulse. Для создания бота с нуля сразу смотрите раздел [Быстрый старт](../quick-start.md).。 |

### standards/

| Document | When to read |
|---|---|
| `standards/README.md` | когда вы разрабатываете или модифицируете адаптер и вам нужно проверить, соответствуют ли преобразование событий, ответы API, методы отправки и т. д. кроссплатформенному стандарту ErisPulse, обращайтесь к соответствующим спецификациям в этом каталоге для сверки. Если не знаете, с чего начать, сначала прочитайте общий обзор ниже.。 |
| `standards/api-action-spec.md` | **Когда это нужно читать:** Когда вы реализуете стандартные действия API DSL (get_user_info / delete_message и т.д.) в адаптере или вызываете эти стандартные действия между модулями, и вам нужно сверить параметры и поля данных с этой статьей. Если это не требуется, пропустите. |
| `standards/api-response.md` | когда вы реализуете в адаптере возвращаемые значения `call_api` / Send / Request, требуется убедиться, что структура ответа и коды возврата соответствуют стандарту ErisPulse, или разобраться в значении конкретного `retcode` — сверяйтесь с этим документом. Если это не нужно — пропустите.。 |
| `standards/event-conversion.md` | **Когда следует читать этот документ**: когда вы конвертируете нативные события платформы в стандартные события OneBot12 внутри адаптера — сверяйтесь с этим документом при проверке обязательных полей, структуры сегментов сообщений, правил именования расширений (префикс `{platform}_`) и определения типа сессии. Если это не требуется — пропустите. |
| `standards/request-action-spec.md` | **Когда нужно читать эту статью**: когда вашему адаптеру нужно обрабатывать запросы от друзей/приглашения в группы (преобразование событий запросов, реализация `accept`/`reject`, сохранение контекста запросов с гетерогенными эндпоинтами), или когда модули используют `event.approve()` / `event.reject()` для одобрения запросов. Если не нужно, то можно пропустить. |
| `standards/send-method-spec.md` | **Когда стоит читать этот документ**: когда вы реализуете класс Send в адаптере — сверяйтесь с этим документом при именовании методов, поддержке форм медиапараметров (URL/путь/bytes), обратном преобразовании `Raw_ob12`, возможностях объединённой пересылки. Если не нужно — пропустите. |
| `standards/session-types.md` | **Когда нужно читать эту статью**: когда вы адаптируете платформу, сопоставляя нативные сессии с платформы с типами (private/group/channel/guild/thread), или в модуле, если не уверены, какой тип цели нужно передавать в `Send.To()`, или хотите понять, как происходит автоматическое преобразование `event.reply()`. Если не нужно, можете пропустить. |
| `standards/standardization-guide.md` | **Когда читать это**: при разработке нового адаптера, добавлении новой функции для платформы, решении, следует ли добавлять в стандарт или использовать `{platform}_` расширение, как назвать функцию, как обработать различия между платформами — сначала прочитайте эту статью. Если вы просто ищете конкретные спецификации для определенной области, можно сразу перейти к разделу §2, соответствующему стандартной карте. |

### styleguide/

| Document | When to read |
|---|---|
| `styleguide/README.md` | Данный каталог содержит инженерные дисциплины и руководства по написанию кода для проекта ErisPulse. |
| `styleguide/docs-writing.md` | В этой статье описаны правила оформления документации ErisPulse и написания публичного контента (README/страницы релизов). Целевая аудитория — участники, вносящие вклад в документацию, и лица, отвечающие за обновление README. |
| `styleguide/docstring.md` | При создании основных методов EP необходимо добавлять комментарии к методам в следующем формате: |
| `styleguide/engineering.md` | В этом документе описаны правила надежности исходного кода ErisPulse. Каждое правило содержит пояснение "почему" и реальные примеры из данного репозитория; перед внесением кода на вкладку, пожалуйста, пройдитесь по этой странице, поскольку часть проверок, помимо CI, выполняется на этапе ревью. |
| `styleguide/glossary.md` | когда при написании или редактировании документации вы не уверены, как назвать тот или иной концепт, или обнаружили, что в двух документах одно и то же понятие описано по-разному. Если это не ваш случай — пропустите.。 |

### user-guide/

| Document | When to read |
|---|---|
| `user-guide/README.md` | если вам нужно установить окружение, настроить `config.toml`, управлять компонентами с помощью `epsdk` или развернуть бота в рабочей среде — обращайтесь к этому руководству по мере необходимости; если нет — можете пропустить.。 |
| `user-guide/cli-reference.md` | **Когда нужно читать эту страницу**: забыли параметры команды `epsdk`, хотите добавить управление компонентами в скрипт, или хотите контролировать поведение `run` / `stop` / `restart`. Для повседневного использования `init` / `install` / `run` достаточно знать одну команду: `epsdk <команда> --help` — всегда можно посмотреть описание параметров, не читая всю статью. |
| `user-guide/configuration.md` | - После изменения параметров подключения необходимо перезапустить фреймворк; при мгновенном сбое создания пула автоматически будет повторная попытка с экспоненциальной задержкой |
| `user-guide/deployment.md` | когда бот должен долго и непрерывно работать — здесь собраны развёртывание через Docker, защита процессов с помощью systemd / Supervisor, обратный прокси и SSL, резервное копирование и обновление. Если вы на этапе локальной разработки и отладки, документ можно пропустить.。 |
| `user-guide/installation.md` | **Когда нужно читать эту статью**: если вам нужно выбрать способ установки (pip / uv / Docker / клиентское приложение ErisPulse-App) или если установка не удалась и требуется устранение неполадок. Если вы хотите просто быстро запустить, [5-минутный старт](../quick-start.md) уже охватывает самый простой процесс, и эту статью можно пропустить. |

> Generated by `python -m scripts.tools gen skills`; do not edit by hand.
