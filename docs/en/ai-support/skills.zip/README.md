# ErisPulse Docs Pack (en)

Auto-packed by CI from `docs/en/`: all documents as-is (no merging, no rewriting), plus this README as the index.

## Usage

1. Unzip and put the folder into your workspace (IDE / agent), or feed individual documents to the AI as needed
2. Pick documents via the index below: check "when to read" and load only what you need

## Index

### Root documents

| Document | When to read |
|---|---|
| `README.md` | ErisPulse is an event-driven, modular asynchronous bot framework — write your business code once, then deploy to QQ, Telegram, Kook, Yunhu, and many other platforms via adapters. The plugin system, hot reloading, and a complete developer toolchain work out of the box. |
| `architecture.md` | When you want to understand what the framework is doing behind the scenes—how a message flows, the order in which modules are initialized, what happens during hot reload, or when troubleshooting "why the framework behaves this way." If you only want to write handlers, see [Getting Started with Event Handling](getting-started/event-handling.md); otherwise, skip this.。 |
| `bug-tracker.md` | This document records known bugs of the ErisPulse SDK and their repair status, arranged in chronological order by the time of repair version. |
| `quick-start.md` | **1. Install** (Python >= 3.10): |

### advanced/

| Document | When to read |
|---|---|
| `advanced/README.md` | This directory contains advanced topics of the ErisPulse framework—deep capabilities such as permission control, canary release, multi-round interaction, and storage backends—each addressing a specific category of problems. |
| `advanced/client.md` | When you need outbound HTTP / WebSocket requests. Skip if not needed, as it does not affect other features.。 |
| `advanced/connections.md` | When you need WebSocket/SSE connection pools, group subscriptions, cross-module push, or need to inspect connections. Skip otherwise, as it does not affect other features.。 |
| `advanced/conversation.md` | When you need a multi-turn dialogue state machine and checkpoint recovery. If not needed, you can skip this section, which won't affect the use of other features.。 |
| `advanced/errors.md` | All custom exceptions in ErisPulse inherit from `ErisPulseError`; underlying library exceptions (aiohttp, aiomysql, etc.) |
| `advanced/i18n.md` | When you need multi-language content, translation registration, or language detection. Skip if not needed, as it does not affect the use of other features.。 |
| `advanced/interaction.md` | **When you need to read this**: When you need `wait_reply`, multi-turn conversations, timed reminders, conversation mutual exclusion, or session tracing. If not needed, you can skip it without affecting the use of other features. |
| `advanced/lazy-loading.md` | When using lazy-loaded modules or `activate_on` event-driven activation. Skip it if not needed; it does not affect the use of any other features.。 |
| `advanced/lifecycle.md` | When you need to subscribe to framework lifecycle events (startup / loading / state change). Skip if not needed, as it won't affect the use of other features.。 |
| `advanced/message-builder.md` | When constructing complex/multi-segment messages. Skip if not needed, as it won't affect the use of other features.。 |
| `advanced/module-communication.md` | When you need cross-module calls (RPC), service contracts, directed events, or cold-start replay. Skip if not needed, as it won't affect the usage of other features.。 |
| `advanced/ownership.md` | When debugging resource leaks, understanding the unload cleanup chain, or declaring owned resources. Skip it if not needed — doing so does not affect the use of other features.。 |
| `advanced/router.md` | When you need HTTP / WebSocket / SSE routing (including connection pool broadcasting). Skip if not needed, as it does not affect other features.。 |
| `advanced/scope.md` | When you need to control module availability, event admission, or outbound action restrictions. Skip if not needed, it does not affect the use of other features.。 |
| `advanced/shadow.md` | When you need gradual release—running a new version in parallel, comparing behaviors, and promoting or rolling back. Skip if not needed; it won't affect other features.。 |
| `advanced/sql-builder.md` | When you need chain-style SQL queries or custom storage backends. If not needed, you can skip it without affecting the use of other features.。 |
| `advanced/startup.md` | When you need to manually drive the startup chain, customize the startup order, or troubleshoot startup failures. Skip if not needed; it does not affect the use of other features.。 |
| `advanced/storage-backends.md` | When switching between sqlite/mysql/postgres or a custom storage backend. Skip if not needed, as it does not affect the usage of other features.。 |
| `advanced/transcript.md` | When you need message history, conversation resume, or to adjust inbox retention policies. Skip it otherwise; it won't affect the use of other features.。 |

### api-reference/

| Document | When to read |
|---|---|
| `api-reference/README.md` | When you are writing modules or adapters and need to look up usage examples for a core module (Storage/Config/Logger/Router, etc.), event system, or adapter management API — jump to the corresponding section in the list below. Skip if not needed.。 |
| `api-reference/adapter-system.md` | Refer to this document when you need to manage adapters (getting instances, starting/stopping them, checking Bot online status), send messages using the Send DSL, register middleware, or integrate Bot status reporting (meta events) into an adapter. Skip it otherwise.。 |
| `api-reference/auto_api/ErisPulse/CLI/__init__.md` | CLI 模块 |
| `api-reference/auto_api/ErisPulse/CLI/base.md` | CLI 命令基类 |
| `api-reference/auto_api/ErisPulse/CLI/cli.md` | 主 CLI 类 |
| `api-reference/auto_api/ErisPulse/CLI/commands/__init__.md` | 命令模块 |
| `api-reference/auto_api/ErisPulse/CLI/commands/config.md` | Config 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/create.md` | Create 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/doctor.md` | Doctor 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/init.md` | Init 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/install.md` | Install 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/language.md` | Language 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/list.md` | List 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/list_remote.md` | List-Remote 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/run.md` | Run 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/runtime.md` | Stop / Restart 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/self_update.md` | Self-Update 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/types.md` | Types 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/uninstall.md` | Uninstall 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/upgrade.md` | Upgrade 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/version.md` | Version 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/console.md` | CLI 控制台模块 |
| `api-reference/auto_api/ErisPulse/CLI/constants.md` | CLI 本地常量 |
| `api-reference/auto_api/ErisPulse/CLI/hints.md` | ErisPulse CLI 友好提示引擎 |
| `api-reference/auto_api/ErisPulse/CLI/i18n/__init__.md` | ErisPulse CLI 国际化模块 |
| `api-reference/auto_api/ErisPulse/CLI/i18n/locales/__init__.md` | CLI 内置翻译数据加载器 |
| `api-reference/auto_api/ErisPulse/CLI/i18n/locales/en.md` | CLI English translations (en) |
| `api-reference/auto_api/ErisPulse/CLI/i18n/locales/ja.md` | CLI 日本語翻訳 (ja) |
| `api-reference/auto_api/ErisPulse/CLI/i18n/locales/ru.md` | CLI Русский перевод (ru) |
| `api-reference/auto_api/ErisPulse/CLI/i18n/locales/zh_cn.md` | CLI 简体中文翻译 (zh-CN) |
| `api-reference/auto_api/ErisPulse/CLI/i18n/locales/zh_tw.md` | CLI 繁體中文翻譯 (zh-TW) |
| `api-reference/auto_api/ErisPulse/CLI/registry.md` | CLI 命令注册器 |
| `api-reference/auto_api/ErisPulse/CLI/utils/__init__.md` | ErisPulse SDK 工具模块 |
| `api-reference/auto_api/ErisPulse/CLI/utils/config_wizard.md` | ErisPulse CLI 配置向导共享工具 |
| `api-reference/auto_api/ErisPulse/CLI/utils/display.md` | ErisPulse CLI 显示工具 |
| `api-reference/auto_api/ErisPulse/CLI/utils/interactive.md` | CLI 交互式提示统一封装 |
| `api-reference/auto_api/ErisPulse/CLI/utils/package_manager.md` | ErisPulse SDK 包管理器 |
| `api-reference/auto_api/ErisPulse/CLI/utils/runtime_state.md` | 运行实例状态文件（pidfile）工具 |
| `api-reference/auto_api/ErisPulse/CLI/utils/scaffold_text.md` | 脚手架模板多语言文案 |
| `api-reference/auto_api/ErisPulse/Core/Bases/__init__.md` | ErisPulse 基础模块 |
| `api-reference/auto_api/ErisPulse/Core/Bases/adapter.md` | ErisPulse 适配器基础模块 |
| `api-reference/auto_api/ErisPulse/Core/Bases/adapter_patterns.md` | ErisPulse 适配器通信模式基类 |
| `api-reference/auto_api/ErisPulse/Core/Bases/api_dsl.md` | ErisPulse 标准 API 动作 DSL 模块 |
| `api-reference/auto_api/ErisPulse/Core/Bases/client.md` | ErisPulse HTTP 客户端抽象基类 |
| `api-reference/auto_api/ErisPulse/Core/Bases/config_schema.md` | ErisPulse 通用配置 Schema 模块 |
| `api-reference/auto_api/ErisPulse/Core/Bases/converter.md` | OneBot12 事件转换器基类 |
| `api-reference/auto_api/ErisPulse/Core/Bases/errors.md` | ErisPulse 异常体系 |
| `api-reference/auto_api/ErisPulse/Core/Bases/i18n_schema.md` | ErisPulse i18n 键声明 Schema 模块 |
| `api-reference/auto_api/ErisPulse/Core/Bases/kv_builder.md` | ErisPulse KV 查询构建器 |
| `api-reference/auto_api/ErisPulse/Core/Bases/manager.md` | ErisPulse 管理器基类 |
| `api-reference/auto_api/ErisPulse/Core/Bases/model.md` | ErisPulse 数据模型层（ORM）—— 声明式模型与 Active Record CRUD |
| `api-reference/auto_api/ErisPulse/Core/Bases/module.md` | ErisPulse 模块基础模块 |
| `api-reference/auto_api/ErisPulse/Core/Bases/router.md` | ErisPulse 路由抽象基类 |
| `api-reference/auto_api/ErisPulse/Core/Bases/send_builder.md` | SendDSL 批量构建系统 |
| `api-reference/auto_api/ErisPulse/Core/Bases/send_rules.md` | SendDSL 发送规则系统 |
| `api-reference/auto_api/ErisPulse/Core/Bases/sql_base.md` | ErisPulse SQL 存储共享基类 |
| `api-reference/auto_api/ErisPulse/Core/Bases/storage.md` | ErisPulse 存储基类 |
| `api-reference/auto_api/ErisPulse/Core/Bases/websocket.md` | ErisPulse WebSocket 共享基类 |
| `api-reference/auto_api/ErisPulse/Core/Event/__init__.md` | ErisPulse 事件处理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/base.md` | ErisPulse 事件处理基础模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/command.md` | ErisPulse 命令处理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/command_args.md` | ErisPulse 命令参数与选项解析模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/command_flow.md` | 命令多轮流控语法糖（``.got()`` 链） |
| `api-reference/auto_api/ErisPulse/Core/Event/conversation.md` | ErisPulse 多轮对话上下文模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/governance.md` | ErisPulse 命令治理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/interaction.md` | ErisPulse 交互会话管理 |
| `api-reference/auto_api/ErisPulse/Core/Event/message.md` | ErisPulse 消息处理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/message_builder.md` | ErisPulse 消息构建器 |
| `api-reference/auto_api/ErisPulse/Core/Event/meta.md` | ErisPulse 元事件处理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/notice.md` | ErisPulse 通知处理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/overrides.md` | ErisPulse 事件覆写系统（overrides） |
| `api-reference/auto_api/ErisPulse/Core/Event/request.md` | ErisPulse 请求处理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/session_type.md` | ErisPulse 会话类型管理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/throttle.md` | 事件处理器节流（throttle=）与防抖（debounce=，EPRFC-2026-001 方向八） |
| `api-reference/auto_api/ErisPulse/Core/Event/trace.md` | 分发决策链追踪（EPRFC-2026-001 方向五：模块排查的场景三） |
| `api-reference/auto_api/ErisPulse/Core/Event/wrapper.md` | ErisPulse 事件包装类 |
| `api-reference/auto_api/ErisPulse/Core/__init__.md` | ErisPulse 核心模块 |
| `api-reference/auto_api/ErisPulse/Core/adapter.md` | ErisPulse 适配器系统 |
| `api-reference/auto_api/ErisPulse/Core/assets/__init__.md` | ErisPulse 前端资源 |
| `api-reference/auto_api/ErisPulse/Core/client.md` | ErisPulse HTTP/WS 客户端 |
| `api-reference/auto_api/ErisPulse/Core/config.md` | ErisPulse 配置中心 |
| `api-reference/auto_api/ErisPulse/Core/connections.md` | ErisPulse 连接注册表（连接池） |
| `api-reference/auto_api/ErisPulse/Core/constants.md` | ErisPulse 内部常量定义 |
| `api-reference/auto_api/ErisPulse/Core/di.md` | ErisPulse 依赖注入模块 |
| `api-reference/auto_api/ErisPulse/Core/i18n/__init__.md` | ErisPulse 国际化模块 |
| `api-reference/auto_api/ErisPulse/Core/i18n/constants.md` | ErisPulse i18n 常量定义 |
| `api-reference/auto_api/ErisPulse/Core/i18n/locales/__init__.md` | ErisPulse 内置翻译数据包 |
| `api-reference/auto_api/ErisPulse/Core/i18n/locales/en.md` | English translation data (en) |
| `api-reference/auto_api/ErisPulse/Core/i18n/locales/ja.md` | 日本語翻訳データ (ja) |
| `api-reference/auto_api/ErisPulse/Core/i18n/locales/ru.md` | Русский перевод (ru) |
| `api-reference/auto_api/ErisPulse/Core/i18n/locales/zh_cn.md` | 简体中文翻译数据 (zh-CN) |
| `api-reference/auto_api/ErisPulse/Core/i18n/locales/zh_tw.md` | 繁體中文翻譯資料 (zh-TW) |
| `api-reference/auto_api/ErisPulse/Core/lifecycle.md` | ErisPulse 生命周期管理模块 |
| `api-reference/auto_api/ErisPulse/Core/logger.md` | ErisPulse 日志系统 |
| `api-reference/auto_api/ErisPulse/Core/master.md` | 框架主人管理系统 |
| `api-reference/auto_api/ErisPulse/Core/module.md` | ErisPulse 模块系统 |
| `api-reference/auto_api/ErisPulse/Core/ownership.md` | ErisPulse 归属权统一门面 |
| `api-reference/auto_api/ErisPulse/Core/router.md` | ErisPulse 路由系统 |
| `api-reference/auto_api/ErisPulse/Core/scope.md` | ErisPulse 作用域（scope） |
| `api-reference/auto_api/ErisPulse/Core/shadow.md` | ErisPulse 影子模块（方向十一：Shadow Modules & Canary Promote） |
| `api-reference/auto_api/ErisPulse/Core/storage/__init__.md` | ErisPulse 存储管理模块 |
| `api-reference/auto_api/ErisPulse/Core/storage/mysql.md` | ErisPulse MySQL 存储后端（aiomysql 异步原生实现） |
| `api-reference/auto_api/ErisPulse/Core/storage/postgres.md` | ErisPulse PostgreSQL 存储后端（asyncpg 异步原生实现） |
| `api-reference/auto_api/ErisPulse/Core/storage/sqlite.md` | ErisPulse SQLite 存储后端（aiosqlite 异步原生实现） |
| `api-reference/auto_api/ErisPulse/Core/text_match.md` | ErisPulse 统一文本/条目匹配工具 |
| `api-reference/auto_api/ErisPulse/Core/transcript.md` | ErisPulse 会话收件箱（transcript） |
| `api-reference/auto_api/ErisPulse/__init__.md` | ErisPulse SDK 主模块 |
| `api-reference/auto_api/ErisPulse/__main__.md` | ErisPulse SDK 命令行工具 |
| `api-reference/auto_api/ErisPulse/finders/__init__.md` | ErisPulse 发现器模块 |
| `api-reference/auto_api/ErisPulse/finders/adapter.md` | ErisPulse 适配器发现器 |
| `api-reference/auto_api/ErisPulse/finders/bases/finder.md` | ErisPulse 基础发现器 |
| `api-reference/auto_api/ErisPulse/finders/module.md` | ErisPulse 模块发现器 |
| `api-reference/auto_api/ErisPulse/loaders/__init__.md` | ErisPulse 加载器模块 |
| `api-reference/auto_api/ErisPulse/loaders/_reload_utils.md` | 热重载共用工具：字节码缓存清理与卸载前语法预检 |
| `api-reference/auto_api/ErisPulse/loaders/adapter.md` | ErisPulse 适配器加载器 |
| `api-reference/auto_api/ErisPulse/loaders/bases/loader.md` | ErisPulse 基础加载器 |
| `api-reference/auto_api/ErisPulse/loaders/module.md` | ErisPulse 模块加载器 |
| `api-reference/auto_api/ErisPulse/loaders/plugin_folder.md` | ErisPulse 本地插件文件夹加载器 |
| `api-reference/auto_api/ErisPulse/loaders/strategy.md` | ErisPulse 模块加载策略 |
| `api-reference/auto_api/ErisPulse/loaders/strict.md` | ErisPulse 严格模式 |
| `api-reference/auto_api/ErisPulse/runtime/__init__.md` | ErisPulse 运行时配置和管理模块 |
| `api-reference/auto_api/ErisPulse/runtime/config_schema.md` | ErisPulse 通用配置 Schema 模块（向后兼容 shim） |
| `api-reference/auto_api/ErisPulse/runtime/context.md` | ErisPulse 运行时上下文 |
| `api-reference/auto_api/ErisPulse/runtime/diagnostics.md` | ErisPulse 异常诊断模块 |
| `api-reference/auto_api/ErisPulse/runtime/example_config.md` | config.full.example 完整配置参考生成器（runtime / CLI 共用） |
| `api-reference/auto_api/ErisPulse/runtime/exceptions.md` | ErisPulse 全局异常处理系统 |
| `api-reference/auto_api/ErisPulse/runtime/file_watcher.md` | 文件变更监控 |
| `api-reference/auto_api/ErisPulse/runtime/frame_config.md` | ErisPulse 框架配置管理模块 |
| `api-reference/auto_api/ErisPulse/runtime/hints.md` | ErisPulse 友好错误提示引擎 |
| `api-reference/auto_api/ErisPulse/runtime/kernel.md` | 统一编排内核（组合根） |
| `api-reference/auto_api/ErisPulse/runtime/memory.md` | 进程内存追踪工具 |
| `api-reference/auto_api/ErisPulse/runtime/owner_cleanup.md` | 归属清理钩子（owner cleanup hooks） |
| `api-reference/auto_api/ErisPulse/runtime/plugin_reload.md` | ErisPulse 本地插件热重载监控 |
| `api-reference/auto_api/ErisPulse/runtime/proactive_gc.md` | ErisPulse 主动 GC 周期任务 |
| `api-reference/auto_api/ErisPulse/runtime/process_state.md` | 跨进程运行状态契约（SDK 侧） |
| `api-reference/auto_api/ErisPulse/runtime/reload_ops.md` | 热重载操作协调器 |
| `api-reference/auto_api/ErisPulse/runtime/resource_track.md` | 合作式资源登记（tracked resources） |
| `api-reference/auto_api/ErisPulse/runtime/sdk_initializer.md` | ErisPulse SDK 初始化 / 反初始化协调器 |
| `api-reference/auto_api/ErisPulse/runtime/tasks.md` | 后台任务管理工具 |
| `api-reference/auto_api/ErisPulse/runtime/troubleshoot.md` | 模块排查诊断（EPRFC-2026-001 方向五·场景一 / 二） |
| `api-reference/auto_api/ErisPulse/runtime/version.md` | SDK 版本解析与比较 |
| `api-reference/auto_api/ErisPulse/sdk.md` | ErisPulse SDK 主类 |
| `api-reference/auto_api/README.md` | 本文档包含 ErisPulse SDK 的所有 API 参考文档。 |
| `api-reference/core-modules.md` | When you need core capabilities such as storage, configuration, logging, module management, routing, or the HTTP client and can't recall the exact method signatures, use this document as a quick reference. Otherwise, skip it.。 |
| `api-reference/event-system.md` | Refer to this document when you need to register commands, listen to message/notice/request events, or use event interaction methods such as `event.reply()` / `wait_reply()` / `confirm()`. Skip it otherwise.。 |

### contributing/

| Document | When to read |
|---|---|
| `contributing/README.md` | If you want to contribute to ErisPulse but are unsure what to do or where to start. Skip this if you are only using the bot and not involved in development.。 |
| `contributing/first-contribution.md` | When you're about to submit your first Pull Request—every step from fork to merge comes with commands you can copy and paste directly. If you already have PR experience and just want to check the repository guidelines, head straight to [CONTRIBUTING.md](../../../CONTRIBUTING.md).。 |

### developer-guide/

| Document | When to read |
|---|---|
| `developer-guide/README.md` | When you're ready to develop extensions for ErisPulse—adding features (modules) to the bot or integrating with new platforms (adapters). If you just want to use the bot, skip this and go directly to the [Quick Start](../quick-start.md).。 |
| `developer-guide/adapters/best-practices.md` | Recommended reading after your adapter skeleton is up and running (engineering best practices). Feel free to skip it if not needed—it won't affect the use of other features.。 |
| `developer-guide/adapters/converter.md` | Required reading within the adapter development path (event converter). Skip it if not needed — it won't affect the use of other features.。 |
| `developer-guide/adapters/core-concepts.md` | Mandatory for adapter development path (complete explanation of BaseAdapter / SendDSL / lifecycle mechanisms). For quick start, read [Getting Started with Adapter Development](getting-started.md) first, and return here for "why" questions.。 |
| `developer-guide/adapters/getting-started.md` | This is the entry-point article (required reading) of the adapter development path. Everything about writing an adapter from scratch and understanding the adapter's responsibility boundaries and project structure is covered here; after finishing, move on to the [Event Converter](converter.md) and [SendDSL in Detail](send-dsl.md) as needed.。 |
| `developer-guide/adapters/send-dsl.md` | This is a must-read for adapter development paths (Send DSL). If not needed, you can skip it without affecting the use of other features.。 |
| `developer-guide/configuration.md` | ErisPulse's configuration system is **declarative**: developers describe configuration items using dataclass fields + metadata, and the framework's `get_config_schema()` translates them into JSON Schema for any consumer (Dashboard, third-party panels, CLI wizards, etc.) to render. This document serves as the **normative definition** of this metadata—widget semantics, value forms, conditional visibility, and compatibility obligations are all governed by it; each consumer is responsible for its own implementation, and its semantics must remain consistent with this document. |
| `developer-guide/modules/best-practices.md` | Recommended reading after you complete your first module (engineering best practices). Feel free to skip it if you don't need it — doing so won't affect your use of any other features.。 |
| `developer-guide/modules/core-concepts.md` | This document explains the complete lifecycle of a module from loading to unloading, along with how to use declarative configuration and storage — what the framework automatically does for you and what you only need to write, so you'll know exactly where you stand after reading. |
| `developer-guide/modules/event-wrapper.md` | The reason the `event` parameter in handlers can directly call `.get_text()` / `.reply()` / `.wait_reply()` is the Event wrapper class. This document is its complete method reference — consult it as needed when writing event handlers; the method signatures and behaviors here are authoritative. |
| `developer-guide/modules/getting-started.md` | By following this guide, you will create a runnable module that responds to the `/hello` command, and gain an understanding of the module's project structure, registration method, and load/unload hooks — all subsequent module documentation is built upon this foundation. |
| `developer-guide/orm.md` | When you need data models, automatic table creation, or relationship mapping. If not needed, skip this section; it does not affect the use of other features.。 |
| `developer-guide/publishing.md` | When publishing your work to PyPI / the Module Store. Skip it otherwise; it does not affect the use of other features.。 |
| `developer-guide/testing.md` | When writing automated tests for your own modules. If not needed, feel free to skip — this won't affect the use of any other features.。 |

### ecosystem/

| Document | When to read |
|---|---|
| `ecosystem/README.md` | The ErisPulse framework itself only provides core capabilities (event system, module system, configuration, routing, logging, etc.), and **does not include** "heavyweight" features such as GUI, image rendering, and visualization. These capabilities are provided by community-maintained **third-party modules**, which can be installed on demand. |
| `ecosystem/apimcp.md` | Read this when you want MCP-capable AI clients such as Claude Desktop to directly operate your bot—sending messages, viewing messages, invoking modules, managing adapters, and observing event streams. Skip it otherwise.。 |
| `ecosystem/app.md` | Read this when you want to create, run, and manage bot instances with a graphical interface on your phone or computer—without touching a terminal or installing a separate Python environment. Skip it if you don't need that.。 |
| `ecosystem/cron.md` | Read this when your module needs to trigger logic at a scheduled or delayed time (such as reminders, periodic monitoring, or scheduling with Cron expressions), and you want the tasks to persist after a framework restart. Skip this if you don't need it.。 |
| `ecosystem/dashboard.md` | Read this when you want to manage your bot through a web-based visual interface (start/stop modules, edit configurations, view logs, monitor event streams), or when you want to register a Dashboard management page for your own module. Skip it if you don't need these.。 |
| `ecosystem/qvqchat.md` | Read this when you want to add AI agent capabilities (tool loops, streaming chat, MCP, long-term memory) to your robot, or when you want to expose your module's services for agent calls. Skip if not needed.。 |
| `ecosystem/takumi.md` | Read this when you need to render HTML / node trees / Jinja templates into images for sending to chat platforms (e.g., statistics cards, leaderboards,图文长文). Skip if not needed.。 |

### getting-started/

| Document | When to read |
|---|---|
| `getting-started/README.md` | The robot has already been started using [5-Minute Quick Start](../quick-start.md), and you want to systematically understand the framework's core concepts and learn all the commonly used capabilities. If you haven't started yet, complete the quick start first; if you just want to look up a specific issue, go directly to the corresponding article.。 |
| `getting-started/basic-concepts.md` | What components does a message pass through from the moment a user sends it to the moment the bot replies? What are adapters and modules each responsible for? After reading this article, you will be able to answer on your own the design questions you encounter when writing handlers, instead of merely copying examples. |
| `getting-started/common-tasks.md` | When you want to add a specific feature to your bot, refer to each section—persistence, scheduled tasks, message filtering, permission control, batch sending. Each section is a complete example you can copy directly. If you want to learn event handling patterns systematically, start with [Introduction to Event Handling](event-handling.md); otherwise, skip it.。 |
| `getting-started/event-handling.md` | Read this if you want your bot to respond to messages, commands, notifications, or requests, or if you need to implement reply waiting / multi-turn conversations, or troubleshoot "why isn't my command triggering". If you only want to understand the framework design, [Basic Concepts](basic-concepts.md) is all you need; otherwise, feel free to skip this.。 |
| `getting-started/first-bot.md` | Your bot is already running, and you want to write your first `/hello` command handler and understand what `sdk.run` and command decorators do. If you haven't installed ErisPulse, initialized a project, or run the project yet, complete the "Install", "Initialize Project", and "Run Project" steps in [5-Minute Quick Start](../quick-start.md) first; otherwise, skip this section.。 |
| `getting-started/ide-completion.md` | If IDE completion doesn't surface an adapter's platform-specific methods (such as Yunhu's `Board`) or a module's custom methods, simply run the `epsdk types` command to generate type stubs; otherwise, skip this.。 |

### platform-guide/

| Document | When to read |
|---|---|
| `platform-guide/README.md` | This section is maintained by each adapter's developer, and is used to explain the adapter's differences from and extensions to the OneBot12 standard. Please refer to the detailed documentation for each platform below: |
| `platform-guide/bilibili.md` | BilibiliAdapter is a Bilibili direct message (DM) adapter based on bilibili-api-python, supporting dual login via Cookie / QR code and event-driven DM sending and receiving. |
| `platform-guide/discord.md` | DiscordAdapter is an adapter built on the Discord Gateway (WebSocket) and REST API v10 protocol, integrating the core functionalities of Discord Bots and providing unified event handling and message operation interfaces. |
| `platform-guide/email.md` | EmailAdapter is an email adapter based on the SMTP/IMAP protocol, supporting email sending, receiving, and processing. |
| `platform-guide/ideaura.md` | IdeauraAdapter is an adapter built on the RockyChat platform API, integrating all platform functionality modules and providing a unified interface for event handling and message operations. |
| `platform-guide/kook.md` | KookAdapter is an adapter built on the Kook (Kaihei La) Bot WebSocket protocol, integrating all Kook functional modules and providing unified event handling and message operation interfaces. |
| `platform-guide/maintain-notes.md` | This document is maintained by each adapter developer to document the differences and extended features of the adapter in relation to the OneBot12 standard. |
| `platform-guide/matrix.md` | MatrixAdapter is an adapter built on the [Matrix protocol](https://spec.matrix.org/), integrating all core functional modules of the Matrix protocol and providing unified event handling and message operation interfaces. |
| `platform-guide/minecraft.md` | MinecraftAdapter is a Minecraft Java Edition server adapter based on the RCON protocol, supporting command execution, message sending, and log event listening. |
| `platform-guide/onebot11.md` | OneBot11Adapter is an adapter built based on the OneBot V11 protocol. |
| `platform-guide/onebot12.md` | OneBot12Adapter is an adapter built based on the OneBot V12 protocol, serving as the baseline protocol adapter for the ErisPulse framework. |
| `platform-guide/qqbot.md` | QQBotAdapter is an adapter built based on the official QQ Bot (QQ OpenAPI) protocol, integrating full-scene functionalities such as group chats, private chats, and channels. It provides OneBot12 standard events, standard API actions, and request operation interfaces. |
| `platform-guide/sandbox.md` | SandboxAdapter is the built-in sandbox adapter of ErisPulse, used for local development and module debugging—simulating message sending and receiving without requiring a real platform. |
| `platform-guide/snowluma.md` | SnowLumaAdapter is an adapter built on the SnowLuma backend (NTQQ hook), communicating via the OneBot v11 protocol. |
| `platform-guide/telegram.md` | TelegramAdapter is an adapter built on top of the Telegram Bot API, supporting multiple message types and event handling. |
| `platform-guide/terminal.md` | TerminalAdapter is a command-line terminal adapter—where the terminal serves as a chat session, enabling rapid local debugging of module logic. |
| `platform-guide/webhook.md` | This document provides a detailed explanation of the bidirectional bridge protocol, field mapping, and implementation features of the Webhook adapter. |
| `platform-guide/wechatmp.md` | | Method | Description | WeChat API | |
| `platform-guide/wecom.md` | WeComAdapter is an adapter built based on the Enterprise WeChat self-built application API, which receives messages through callbacks, actively sends messages via the application message interface, and provides contact list and message card capabilities. |
| `platform-guide/yunhu.md` | YunhuAdapter is an adapter built on the Yunhu protocol, integrating all Yunhu functional modules and providing a unified interface for event handling and message operations. |
| `platform-guide/yunhu_user.md` | YunhuUserAdapter is an adapter built based on the Yunhu User Account Protocol. It allows login via user email accounts, uses WebSocket to receive events, and provides a unified interface for event handling and message operations. |

### showcase/

| Document | When to read |
|---|---|
| `showcase/README.md` | Read this when you're choosing between several bot frameworks / AI bot platforms and want to know who ErisPulse is—and isn't—suited for. If you're already using ErisPulse, skip this.。 |
| `showcase/comparison-agent-platforms.md` | When you're looking for an "AI assistant in a group chat" and are choosing between integrated platforms like AstrBot / LangBot and ErisPulse, read this. For writing non-AI business code, see [Comparison: NoneBot2](comparison-nonebot.md).。 |
| `showcase/comparison-nonebot.md` | Read this when you'll be writing code in Python bot frameworks and are choosing between NoneBot2 and ErisPulse. Skip it if you won't be coding.。 |
| `showcase/migrate-from-astrbot.md` | Read this when you already have an AstrBot robot and want to migrate it to ErisPulse. For new setups, see [Quick Start](../quick-start.md) directly.。 |

### standards/

| Document | When to read |
|---|---|
| `standards/README.md` | When you are developing or modifying an adapter and need to confirm whether event transformations, API responses, send methods, etc. comply with ErisPulse's cross-platform standards, refer to the corresponding specifications in this section. If you're unsure where to start, read the overview below first.。 |
| `standards/api-action-spec.md` | When implementing Api DSL standard actions in an adapter (get_user_info / delete_message, etc.), or calling these standard actions cross-platform in a module and needing to confirm parameters and data fields. Skip it if you don't need it.。 |
| `standards/api-response.md` | When you are implementing the return values of `call_api` / Send / Request in an adapter and need to confirm that the response structure and return codes conform to the ErisPulse standard, or when troubleshooting the meaning of a particular `retcode`, refer to this document. Skip if not needed.。 |
| `standards/event-conversion.md` | When you are converting platform-native events to OneBot12 standard events in an adapter—use this document as a reference for verifying required fields, message segment structure, extension field naming (the `{platform}_` prefix), and session type inference. Otherwise, skip it.。 |
| `standards/request-action-spec.md` | When your adapter needs to handle friend requests/group invitations (converting request events, implementing `accept`/`reject`), or when your module needs to use `event.approve()` / `event.reject()` to approve requests, refer to this document. Otherwise, skip it.。 |
| `standards/send-method-spec.md` | When implementing the `Send` class in your adapter—refer to this document for method naming, media parameter (URL/path/bytes) support, `Raw_ob12` reverse conversion, and merge forwarding capabilities. Skip if not needed.。 |
| `standards/session-types.md` | When mapping platform-native session types to standard types (private/group/channel/guild/thread) in an adapter, or when unsure what target type to pass to `Send.To()` in a module, or to understand the automatic conversion of `event.reply()` — refer to this document. Skip it otherwise.。 |
| `standards/standardization-guide.md` | When you are developing a new adapter, or adding new capabilities to a platform and need to decide whether to integrate into the standard or use a `{platform}_` extension, how to name things, or how to handle platform differences, read this first. If you are just looking up specific standards for a particular domain, you can directly jump to §2, the document corresponding to the standard map.。 |

### styleguide/

| Document | When to read |
|---|---|
| `styleguide/README.md` | This directory contains engineering discipline and writing standards for the ErisPulse project. |
| `styleguide/docs-writing.md` | This page specifies the writing style and external (README/release page) writing guidelines for ErisPulse. The target audience is documentation contributors and those maintaining the README. |
| `styleguide/docstring.md` | When creating core EP methods, method comments must be added. The comment format is as follows: |
| `styleguide/engineering.md` | This page defines the robustness discipline for the ErisPulse source code. Each rule explains the "why" along with real cases from this repository; please read through this page before contributing code—the parts outside CI are enforced through code review. |
| `styleguide/glossary.md` | when writing or revising documentation and you are unsure what to call a concept, or when you find two documents describing the same concept inconsistently. Skip it otherwise.。 |

### user-guide/

| Document | When to read |
|---|---|
| `user-guide/README.md` | When you need to install the environment, configure `config.toml`, manage components using `epsdk`, or deploy the robot online, refer to this guide; otherwise, you can skip it.。 |
| `user-guide/cli-reference.md` | Consult it when you forget the arguments of an `epsdk` command, want to script component management, or need to control run / stop / restart behavior. If your daily usage is limited to `init` / `install` / `run`, remembering one thing is enough: `epsdk <command> --help` shows argument descriptions anytime—no need to read this document end to end.。 |
| `user-guide/configuration.md` | - Connection parameters need to be restarted after changes; transient connection pool creation failures will automatically retry with exponential backoff |
| `user-guide/deployment.md` | When the bot needs to run long-term—Docker deployment, systemd / Supervisor process supervision, reverse proxy and SSL, backup and upgrade are all covered here. Skip during local development and debugging.。 |
| `user-guide/installation.md` | Read this when you need to choose an installation method (pip / uv / Docker / ErisPulse-App client) or troubleshoot a failed installation. If you just want to get up and running as quickly as possible, the [5-Minute Quick Start](../quick-start.md) already covers the simplest process — skip this page if that's all you need.。 |

> Generated by `python -m scripts.tools gen skills`; do not edit by hand.
