# 開發者指南

> [!TIP]
> **什麼時候需要讀這篇**：準備為 ErisPulse 開發擴充——給機器人加功能（模組）或接入新平台（配接器）——時。只想使用機器人則跳過，直接看[快速開始](../quick-start.md)。

從這裡找到你的開發路徑：**模組開發**讓你用命令、訊息處理器擴充機器人功能；**配接器開發**讓機器人連上新的訊息平台。兩條路徑都涵蓋從建立專案到測試、發布的完整流程。

## 內容列表

### 模組開發

1. [模組開發入門](modules/getting-started.md) - 建立第一個模組
2. [模組核心概念](modules/core-concepts.md) - 模組的核心概念和架構
3. [Event 包裝類別詳解](modules/event-wrapper.md) - Event 物件的完整說明
4. [模組最佳實踐](modules/best-practices.md) - 開發高品質模組的建議
5. [資料模型層（ORM）](orm.md) - 模組開發進階：宣告式模型、自動建表與增刪改查

### 配接器開發

1. [配接器開發入門](adapters/getting-started.md) - 建立第一個配接器
2. [配接器核心概念](adapters/core-concepts.md) - 配接器的核心概念（含 start() 兩種寫法與 PollingAdapter / WebhookAdapter 連接模式基底類別）
3. [SendDSL 詳解](adapters/send-dsl.md) - Send 訊息傳送 DSL 的完整說明
4. [事件轉換器](adapters/converter.md) - 實作事件轉換器
5. [配接器最佳實踐](adapters/best-practices.md) - 開發高品質配接器的建議

### 測試與疑難排解

1. [模組測試（ErisPulse-Testing）](testing.md) - TestBot、事件工廠與斷言面

### 通用規範

1. [設定與 UI 中繼資料](configuration.md) - 宣告式設定：widget / 條件顯隱 / 值形態 / 相容性契約（配接器與模組通用）

### 發布指南

- [發布與模組商店指南](publishing.md) - 將你的作品發布到 PyPI 和 ErisPulse 模組商店

## 開發準備

在開始開發之前，請確保你：

1. 閱讀了[基礎概念](../getting-started/basic-concepts.md)
2. 熟悉了[事件處理](../getting-started/event-handling.md)
3. 安裝了開發環境（Python >= 3.10）
4. 安裝了 ErisPulse SDK

## 開發類型選擇

根據你的需求選擇合適的開發類型：

| 開發類型 | 適用場景 | 入門指南 |
|---------|---------|---------|
| **模組開發** | 擴充機器人功能、實作業務邏輯、提供命令和訊息處理 | [模組開發入門](modules/getting-started.md) |
| **配接器開發** | 連接新的訊息平台、實作跨平台通訊、提供平台特定功能 | [配接器開發入門](adapters/getting-started.md) |

> 如果你想擴充機器人的功能（如新增命令、處理訊息），選擇**模組開發**。如果你需要讓機器人連接到一個新的平台，選擇**配接器開發**。

## 開發工具

### 項目模板

ErisPulse 提供了示例項目作為參考：

- [模組示例](https://github.com/ErisPulse/ErisPulse/tree/main/examples/example-module) - 模組的完整專案結構（命令 / 配置 / ORM / 依賴注入）
- [Web 能力示例](https://github.com/ErisPulse/ErisPulse/tree/main/examples/example-module-web) - 路由裝飾器 / 中間件 / WebSocket 鈎子 / router.app 逃生艙
- [互動進階示例](https://github.com/ErisPulse/ErisPulse/tree/main/examples/example-module-interactive) - 消息事務與回執 / ORM 聯合唯一與事務 / 請求審批 / 發送鏈
- [運維治理示例](https://github.com/ErisPulse/ErisPulse/tree/main/examples/example-module-ops) - 線程任務歸屬 / 延遲任務 / 內存體檢 / 隱私開關
- [適配器示例](https://github.com/ErisPulse/ErisPulse/tree/main/examples/example-adapter) - 適配器的完整專案結構（另有 [輪詢](https://github.com/ErisPulse/ErisPulse/tree/main/examples/example-adapter-polling) / [Webhook](https://github.com/ErisPulse/ErisPulse/tree/main/examples/example-adapter-webhook) 變體）

### 開發模式

使用熱重載模式進行開發，程式碼修改後自動重載：

```bash
epsdk run main.py --reload
```

### 調試技巧

在 `config/config.toml` 中啟用 DEBUG 或 TRACE 級別日誌：

```toml
[ErisPulse.logger]
# DEBUG: 輸出模組載入、路由註冊等開發調試資訊
# TRACE: 最低級別，輸出事件分發、儲存寫入、懶載入等框架內部詳細流程
level = "DEBUG"
```

## 發布你的模組

完整的發布流程請參考 [發布與模組商店指南](publishing.md)，包括 PyPI 發布步驟、ErisPulse 模組商店提交流程等。

## 相關文件

- [標準規範](../standards/) - 確保相容性的技術標準
- [平台特性指南](../platform-guide/) - 了解各平台配接器的特性