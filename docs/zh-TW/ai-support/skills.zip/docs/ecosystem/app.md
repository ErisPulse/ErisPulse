# ErisPulse-App

> [!TIP]
> **什麼時候需要閱讀這篇**：當你想在手機或電腦上使用圖形介面建立、執行、管理機器人實例——不碰終端、不單獨安裝 Python 環境時閱讀這篇。不需要則跳過。

[ErisPulse-App](https://github.com/ErisPulse/ErisPulse-App) 是 ErisDev 直接維護的 **官方多端客戶端**（Android / Windows / Linux / macOS 均已發布），
提供完全原生的圖形化管理介面：在手機或電腦上建立、執行、管理多個機器人實例，
無需終端，也無需單獨安裝 Python 環境。

> [!IMPORTANT]
> ErisPulse-App 是**獨立安裝的客戶端程式**，不是 `epsdk install` 安裝的模組。
> 它內建了 Python 運行時與 ErisPulse SDK，安裝即用——**手機上也能直接執行**。

## 功能速覽

- **多實例管理**：建立 / 啟動 / 停止 / 刪除多個實例，端口與存取令牌自動分配，支援全新環境或複製既有環境
- **概覽儀表板**：適配器 / 模組 / 在線機器人 / 事件總數統計，CPU / 內存佔用警示變色
- **模組商店**：搜尋與標籤篩選、一鍵安裝 / 升級 / 卸載、指定版本安裝、pip 鏡像源與 Git 套件支援
- **事件流 + 事件建構器**：即時事件檢視，以視覺化方式建構測試事件並提交至適配器
- **監控**：日誌 / 生命週期 / 審計三合一視圖
- **命令管理**：前綴與別名等全域設定、啟停與平台黑白名單
- **機器人總覽 / 配置 / 檔案管理**：透過原生介面直接操作實例
- **後台常駐**：Android 前台服務保活；Windows 最小化至系統托盤，關閉視窗不中斷實例
- **模組動態視窗**：模組註冊的頁面自動出現在側邊導航（與 Dashboard 同分組），點擊即達

## 支援平台

所有平台的安裝包均可從 [GitHub Releases](https://github.com/ErisPulse/ErisPulse-App/releases) 下載，依需求選擇即可：

| 平台 | 安裝包 | 說明 |
|------|--------|------|
| Android | `online-*.apk` / `offline-*.apk` | **手機直接執行**，無需電腦 |
| Windows | `windows-x64-setup.exe` / `windows-x64.zip` | 安裝版 / 免安裝版 |
| Linux | `linux-x64.tar.gz` | 解壓即用 |
| macOS | `macos-arm64.zip` | Apple Silicon（arm64） |

一個 Flutter 程式碼庫涵蓋所有平台。

## 安裝方式（Android / 手機直接運行）

從 [GitHub Releases](https://github.com/ErisPulse/ErisPulse-App/releases) 下載 APK 安裝即可，有兩種構建：

| 構建 | 運行時鏡像 | 適用場景 |
|------|-----------|---------|
| `erispulse-app-online-*.apk` | 首次啟動時下載 | 安裝包更小，適合網路良好 |
| `erispulse-app-offline-*.apk` | 已打包進 APK | 離線自包含，安裝後無需聯網 |

兩種構建安裝步驟相同：

1. 下載並安裝 APK，啟動時允許通知權限（用於保持後台服務存活）
2. 首頁出現初始化橫幅後點擊運行首次初始化（含進度與日誌視圖）
3. 建立一個實例並啟動
4. 在 App 內建的管理介面配置適配器與模型 API Key

> 離線包自包含——安裝後無需網路。如果首次啟動下載慢或不穩定，  
> 可在設定頁將下載源切換為鏡像（ghfast / gh-proxy）。

### 安裝方式（桌面端：Windows / Linux / macOS）

1. 從 [GitHub Releases](https://github.com/ErisPulse/ErisPulse-App/releases) 下載對應平台安裝包  
   （Windows `setup.exe` 或免安裝 `zip`、Linux `tar.gz`、macOS `zip`）
2. 安裝並啟動
3. 在歡迎頁選擇要安裝的 ErisPulse SDK 版本（預設最新）並安裝
4. 建立實例並啟動

---

## 工作原理

```
┌────────────────────────────────────────────────────┐
│  ErisPulse-App (Flutter)                            │
│                                                    │
│  原生 UI ── Dashboard REST / WS API                │
│       │                                            │
│       ├── Android：前台服務 + proot + Ubuntu rootfs│
│       │        + Python + ErisPulse 實例           │
│       └── 桌面端：內建 Python + 直接進程管理         │
└────────────────────────────────────────────────────┘
```

- **Android**：實例運行在前台服務（background isolate）托管的 proot（使用者態 chroot）內，UI 關閉後機器人仍持續運行，崩潰自動重啟
- **桌面端**：實例作為 App 的直接子進程運行；Windows 支援最小化到系統托盤後台常駐（關閉視窗不中斷實例），App 重啟後自動恢復對仍在運行實例的管理，退出時統一停止全部實例
- 所有平台的原生 UI 都透過 `127.0.0.1:<port>/Dashboard/*` 的 REST / WebSocket API 與實例通訊，與 [ErisPulse-Dashboard](dashboard.md) 共用同一套 API

## 與 SDK 的關係

- App 內建 ErisPulse SDK：Android 端打包於 Ubuntu 鏡像中，桌面端從 PyPI 安裝  
  （歡迎頁可選版本，預設為最新）
- App 中的實例與命令列 `epsdk` 創建的實例等價，可使用相同的模組 / 適配器
- 模組開發者可透過 [Dashboard 視窗註冊 API](dashboard.md) 註冊自訂頁面：  
  視窗會自動出現在 App 邊欄導航（分組與 Dashboard 一致），點擊後跳轉至對應頁面進行渲染

---

## 相關連結

- GitHub 倉庫：[https://github.com/ErisPulse/ErisPulse-App](https://github.com/ErisPulse/ErisPulse-App)
- 下載：[GitHub Releases](https://github.com/ErisPulse/ErisPulse-App/releases)
- 討論：[Discussions](https://github.com/ErisPulse/ErisPulse-App/discussions)

---

## 下一步

- **在桌面 / 伺服器上用瀏覽器管理**：[ErisPulse-Dashboard](dashboard.md)（與 App 共用同一套 API 與視窗分組）
- **接入第一個平台**：App 內建管理介面可完成配置，各平台細節見[平台特性總覽](../platform-guide/README.md)
- **習慣命令列**：App 中的實例與 `epsdk` 創建的完全等價，從[快速上手](../quick-start.md)開始