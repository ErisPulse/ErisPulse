# 風格指南

本目錄包含 ErisPulse 項目之工程紀律與寫作規範。

## 文件列表

- [術語表（唯一真相來源）](glossary.md) - Client/HttpClient、storage/env/StorageManager、BaseConfig/AdapterConfig、scope 三維、歸屬權、服務契約/目錄/白名單等易漂移術語的唯一定義
- [註釋風格規範](docstring.md) - 方法註釋和文件字串的格式規範與標籤解析契約
- [工程健壯性規則](engineering.md) - 異常留痕分級、日誌分級、行為參數集中、API 契約、單例回引禁忌、清理與回滾紀律、測試紀律
- [文件與對外寫作規則](docs-writing.md) - 文件行文、版本標註、README 與發布頁的三段式骨架、場景化表達、變更記錄寫作

## 適用對象

- ErisPulse 核心貢獻者
- 模塊和適配器開發者
- 維護 README 與對外頁面的貢獻者
- 需要產生 API 文件的開發者

## 與其他規範的關係

- [技術標準](../standards/) - 適配器的**技術**規範（會話類型、事件轉換、API 形態）；本目錄是**工程與寫作**紀律，兩者互補不重疊
- `CONTRIBUTING.md` - 貢獻流程與 CI 門禁（本目錄規則中的可機檢部分由門禁腳本執行）
- `CHANGELOG.md` 頭部「寫作規範」 - 變更記錄的詳細規範（本文檔只做引用，不重複正文）