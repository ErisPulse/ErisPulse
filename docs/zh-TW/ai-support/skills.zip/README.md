# ErisPulse 文档包（zh-TW）

本压缩包由 CI 从 `docs/zh-TW/` 自动打包：收录全部文档原文（不合并、不改写），另附本 README 作为总索引。

## 使用

1. 解压后把整个目录放进工作区（IDE / 智能体均可），或按需把单个文档投喂给 AI
2. 按下面的索引挑文档：先看「什么时候读」，只加载需要的那几篇，不必全文灌入

## 索引

### 根目录文档

| 文档 | 什么时候读 |
|---|---|
| `README.md` | [模組開發入門](developer-guide/modules/getting-started.md)。 |
| `architecture.md` | 想搞懂框架在背後做了什麼——一條訊息如何流轉、模組按什麼順序初始化、熱重載時發生了什麼，或排查「框架為什麼這樣表現」時讀。只想寫處理器的話，看 [事件處理入門](getting-started/event-handling.md) 就夠；不需要則跳過。 |
| `bug-tracker.md` | 本文檔記錄 ErisPulse SDK 的已知 Bug 及其修復情況，按修復版本時間順序排列。 |
| `quick-start.md` | **1. 安裝**（Python >= 3.10）： |

### advanced/

| 文档 | 什么时候读 |
|---|---|
| `advanced/README.md` | - [作用域（scope）](scope.md) - 三維作用域控制：模組可用性 / 事件准入 / 出站動作限制（含方法級細粒度規則與綁定繼承 merge）。 |
| `advanced/client.md` | **何時需要閱讀這篇**：需要發出站 HTTP / WebSocket 請求時。不需要則跳過，不會影響其他功能的使用。 |
| `advanced/connections.md` | 需要 WebSocket/SSE 連接池、廣播分組、跨模組推送或查看連接時。不需要則跳過，不影響其它功能的使用。 |
| `advanced/conversation.md` | **何時需要閱讀本文**：當需要多輪對話狀態機與檢查點恢復時。若不需要則可跳過，這不會影響其他功能的使用。 |
| `advanced/errors.md` | ErisPulse 所有自定義異常都繼承自 `ErisPulseError`，底層庫異常（aiohttp、aiomysql 等） |
| `advanced/i18n.md` | 需要多語言文案、翻譯註冊或語言檢測時。不需要則跳過，不影響其它功能的使用。 |
| `advanced/interaction.md` | **何時需要閱讀本文**：需要使用 `wait_reply`、多輪對話、定時提醒、會話互斥或鏈路追蹤時。若不需要則可跳過，這不會影響其他功能的使用。 |
| `advanced/lazy-loading.md` | **何時需要閱讀本文**：使用慢載模組或 activate_on 事件驅動激活時。若不需要則可跳過，這不會影響其他功能的使用。 |
| `advanced/lifecycle.md` | 需要訂閱框架生命周期事件（啟動 / 加載 / 狀態變化）時。不需要則跳過，不影響其它功能的使用。 |
| `advanced/message-builder.md` | **什麼時候需要閱讀這篇**：當需要建構複雜或多段消息時。若不需要則可跳過，這不會影響其他功能的使用。 |
| `advanced/module-communication.md` | **什麼時候需要閱讀這篇**：需要跨模組呼叫（RPC）、服務契約、定向事件或冷啟動回放時。不需要則跳過，不會影響其他功能的使用。 |
| `advanced/ownership.md` | **何時需要閱讀本文**：排查資源洩漏、理解卸載清理鏈路或宣告所屬資源時。不需要則跳過，不會影響其他功能的使用。 |
| `advanced/router.md` | **什麼時候需要閱讀這篇**：需要 HTTP / WebSocket / SSE 路由（含連接池廣播）時。不需要則跳過，不影響其他功能的使用。 |
| `advanced/scope.md` | 需要控制模組可用性、事件准入或出站動作限制時。不需要則跳過，不影響其它功能的使用。 |
| `advanced/shadow.md` | **何時需要閱讀本文**：需要進行灰度發布——新版本並行試運行、行為對比與轉正回滾時。若不需要則可跳過，不會影響其他功能的使用。 |
| `advanced/sql-builder.md` | **什麼時候需要閱讀這篇**：需要鏈式 SQL 查詢或自定義儲存後端時。不需要則跳過，不會影響其他功能的使用。 |
| `advanced/startup.md` | 需要手動驅動啟動鏈路、定製啟動順序或排查啟動失敗時。不需要則跳過，不影響其他功能的使用。 |
| `advanced/storage-backends.md` | **什麼時候需要閱讀這篇**：當切換 sqlite / mysql / postgres 或自定義存儲後端時。不需要則跳過，不會影響其他功能的使用。 |
| `advanced/transcript.md` | **什麼時候需要閱讀本文**：需要消息歷史、對話恢復，或調整收件箱保留策略時。不需要則跳過，不會影響其他功能的使用。 |

### api-reference/

| 文档 | 什么时候读 |
|---|---|
| `api-reference/README.md` | 當你在寫模組或適配器時需要查某個核心模組（Storage/Config/Logger/Router 等）、事件系統或適配器管理 API 的用法範例——按下面文件列表跳到對應篇目。不需要則跳過。 |
| `api-reference/adapter-system.md` | **什麼時候需要閱讀這篇**：當你需要管理適配器（獲取實例、啟停、查詢 Bot 的線上狀態）、使用 Send DSL 發送訊息、註冊中間件，或為適配器接入 Bot 狀態上報（meta 事件）時請參閱本文。不需要則可跳過。 |
| `api-reference/auto_api/ErisPulse/CLI/__init__.md` | CLI 模块 |
| `api-reference/auto_api/ErisPulse/CLI/base.md` | CLI 命令基类 |
| `api-reference/auto_api/ErisPulse/CLI/cli.md` | 主 CLI 类 |
| `api-reference/auto_api/ErisPulse/CLI/commands/__init__.md` | 命令模块 |
| `api-reference/auto_api/ErisPulse/CLI/commands/config.md` | Config 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/create.md` | Create 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/doctor.md` | Doctor 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/init.md` | Init 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/install.md` | Install 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/language.md` | Language 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/list.md` | List 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/list_remote.md` | List-Remote 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/run.md` | Run 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/runtime.md` | Stop / Restart 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/self_update.md` | Self-Update 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/types.md` | Types 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/uninstall.md` | Uninstall 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/upgrade.md` | Upgrade 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/version.md` | Version 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/console.md` | CLI 控制台模块 |
| `api-reference/auto_api/ErisPulse/CLI/constants.md` | CLI 本地常量 |
| `api-reference/auto_api/ErisPulse/CLI/hints.md` | ErisPulse CLI 友好提示引擎 |
| `api-reference/auto_api/ErisPulse/CLI/i18n/__init__.md` | ErisPulse CLI 国际化模块 |
| `api-reference/auto_api/ErisPulse/CLI/i18n/locales/__init__.md` | CLI 内置翻译数据加载器 |
| `api-reference/auto_api/ErisPulse/CLI/i18n/locales/en.md` | CLI English translations (en) |
| `api-reference/auto_api/ErisPulse/CLI/i18n/locales/ja.md` | CLI 日本語翻訳 (ja) |
| `api-reference/auto_api/ErisPulse/CLI/i18n/locales/ru.md` | CLI Русский перевод (ru) |
| `api-reference/auto_api/ErisPulse/CLI/i18n/locales/zh_cn.md` | CLI 简体中文翻译 (zh-CN) |
| `api-reference/auto_api/ErisPulse/CLI/i18n/locales/zh_tw.md` | CLI 繁體中文翻譯 (zh-TW) |
| `api-reference/auto_api/ErisPulse/CLI/registry.md` | CLI 命令注册器 |
| `api-reference/auto_api/ErisPulse/CLI/utils/__init__.md` | ErisPulse SDK 工具模块 |
| `api-reference/auto_api/ErisPulse/CLI/utils/config_wizard.md` | ErisPulse CLI 配置向导共享工具 |
| `api-reference/auto_api/ErisPulse/CLI/utils/display.md` | ErisPulse CLI 显示工具 |
| `api-reference/auto_api/ErisPulse/CLI/utils/interactive.md` | CLI 交互式提示统一封装 |
| `api-reference/auto_api/ErisPulse/CLI/utils/package_manager.md` | ErisPulse SDK 包管理器 |
| `api-reference/auto_api/ErisPulse/CLI/utils/runtime_state.md` | 运行实例状态文件（pidfile）工具 |
| `api-reference/auto_api/ErisPulse/CLI/utils/scaffold_text.md` | 脚手架模板多语言文案 |
| `api-reference/auto_api/ErisPulse/Core/Bases/__init__.md` | ErisPulse 基础模块 |
| `api-reference/auto_api/ErisPulse/Core/Bases/adapter.md` | ErisPulse 适配器基础模块 |
| `api-reference/auto_api/ErisPulse/Core/Bases/adapter_patterns.md` | ErisPulse 适配器通信模式基类 |
| `api-reference/auto_api/ErisPulse/Core/Bases/api_dsl.md` | ErisPulse 标准 API 动作 DSL 模块 |
| `api-reference/auto_api/ErisPulse/Core/Bases/client.md` | ErisPulse HTTP 客户端抽象基类 |
| `api-reference/auto_api/ErisPulse/Core/Bases/config_schema.md` | ErisPulse 通用配置 Schema 模块 |
| `api-reference/auto_api/ErisPulse/Core/Bases/converter.md` | OneBot12 事件转换器基类 |
| `api-reference/auto_api/ErisPulse/Core/Bases/errors.md` | ErisPulse 异常体系 |
| `api-reference/auto_api/ErisPulse/Core/Bases/i18n_schema.md` | ErisPulse i18n 键声明 Schema 模块 |
| `api-reference/auto_api/ErisPulse/Core/Bases/kv_builder.md` | ErisPulse KV 查询构建器 |
| `api-reference/auto_api/ErisPulse/Core/Bases/manager.md` | ErisPulse 管理器基类 |
| `api-reference/auto_api/ErisPulse/Core/Bases/model.md` | ErisPulse 数据模型层（ORM）—— 声明式模型与 Active Record CRUD |
| `api-reference/auto_api/ErisPulse/Core/Bases/module.md` | ErisPulse 模块基础模块 |
| `api-reference/auto_api/ErisPulse/Core/Bases/router.md` | ErisPulse 路由抽象基类 |
| `api-reference/auto_api/ErisPulse/Core/Bases/send_builder.md` | SendDSL 批量构建系统 |
| `api-reference/auto_api/ErisPulse/Core/Bases/send_rules.md` | SendDSL 发送规则系统 |
| `api-reference/auto_api/ErisPulse/Core/Bases/sql_base.md` | ErisPulse SQL 存储共享基类 |
| `api-reference/auto_api/ErisPulse/Core/Bases/storage.md` | ErisPulse 存储基类 |
| `api-reference/auto_api/ErisPulse/Core/Bases/websocket.md` | ErisPulse WebSocket 共享基类 |
| `api-reference/auto_api/ErisPulse/Core/Event/__init__.md` | ErisPulse 事件处理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/base.md` | ErisPulse 事件处理基础模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/command.md` | ErisPulse 命令处理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/command_args.md` | ErisPulse 命令参数与选项解析模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/command_flow.md` | 命令多轮流控语法糖（``.got()`` 链） |
| `api-reference/auto_api/ErisPulse/Core/Event/conversation.md` | ErisPulse 多轮对话上下文模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/governance.md` | ErisPulse 命令治理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/interaction.md` | ErisPulse 交互会话管理 |
| `api-reference/auto_api/ErisPulse/Core/Event/message.md` | ErisPulse 消息处理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/message_builder.md` | ErisPulse 消息构建器 |
| `api-reference/auto_api/ErisPulse/Core/Event/meta.md` | ErisPulse 元事件处理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/notice.md` | ErisPulse 通知处理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/overrides.md` | ErisPulse 事件覆写系统（overrides） |
| `api-reference/auto_api/ErisPulse/Core/Event/request.md` | ErisPulse 请求处理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/session_type.md` | ErisPulse 会话类型管理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/throttle.md` | 事件处理器节流（throttle=）与防抖（debounce=，EPRFC-2026-001 方向八） |
| `api-reference/auto_api/ErisPulse/Core/Event/trace.md` | 分发决策链追踪（EPRFC-2026-001 方向五：模块排查的场景三） |
| `api-reference/auto_api/ErisPulse/Core/Event/wrapper.md` | ErisPulse 事件包装类 |
| `api-reference/auto_api/ErisPulse/Core/__init__.md` | ErisPulse 核心模块 |
| `api-reference/auto_api/ErisPulse/Core/adapter.md` | ErisPulse 适配器系统 |
| `api-reference/auto_api/ErisPulse/Core/assets/__init__.md` | ErisPulse 前端资源 |
| `api-reference/auto_api/ErisPulse/Core/client.md` | ErisPulse HTTP/WS 客户端 |
| `api-reference/auto_api/ErisPulse/Core/config.md` | ErisPulse 配置中心 |
| `api-reference/auto_api/ErisPulse/Core/connections.md` | ErisPulse 连接注册表（连接池） |
| `api-reference/auto_api/ErisPulse/Core/constants.md` | ErisPulse 内部常量定义 |
| `api-reference/auto_api/ErisPulse/Core/di.md` | ErisPulse 依赖注入模块 |
| `api-reference/auto_api/ErisPulse/Core/i18n/__init__.md` | ErisPulse 国际化模块 |
| `api-reference/auto_api/ErisPulse/Core/i18n/constants.md` | ErisPulse i18n 常量定义 |
| `api-reference/auto_api/ErisPulse/Core/i18n/locales/__init__.md` | ErisPulse 内置翻译数据包 |
| `api-reference/auto_api/ErisPulse/Core/i18n/locales/en.md` | English translation data (en) |
| `api-reference/auto_api/ErisPulse/Core/i18n/locales/ja.md` | 日本語翻訳データ (ja) |
| `api-reference/auto_api/ErisPulse/Core/i18n/locales/ru.md` | Русский перевод (ru) |
| `api-reference/auto_api/ErisPulse/Core/i18n/locales/zh_cn.md` | 简体中文翻译数据 (zh-CN) |
| `api-reference/auto_api/ErisPulse/Core/i18n/locales/zh_tw.md` | 繁體中文翻譯資料 (zh-TW) |
| `api-reference/auto_api/ErisPulse/Core/lifecycle.md` | ErisPulse 生命周期管理模块 |
| `api-reference/auto_api/ErisPulse/Core/logger.md` | ErisPulse 日志系统 |
| `api-reference/auto_api/ErisPulse/Core/master.md` | 框架主人管理系统 |
| `api-reference/auto_api/ErisPulse/Core/module.md` | ErisPulse 模块系统 |
| `api-reference/auto_api/ErisPulse/Core/ownership.md` | ErisPulse 归属权统一门面 |
| `api-reference/auto_api/ErisPulse/Core/router.md` | ErisPulse 路由系统 |
| `api-reference/auto_api/ErisPulse/Core/scope.md` | ErisPulse 作用域（scope） |
| `api-reference/auto_api/ErisPulse/Core/shadow.md` | ErisPulse 影子模块（方向十一：Shadow Modules & Canary Promote） |
| `api-reference/auto_api/ErisPulse/Core/storage/__init__.md` | ErisPulse 存储管理模块 |
| `api-reference/auto_api/ErisPulse/Core/storage/mysql.md` | ErisPulse MySQL 存储后端（aiomysql 异步原生实现） |
| `api-reference/auto_api/ErisPulse/Core/storage/postgres.md` | ErisPulse PostgreSQL 存储后端（asyncpg 异步原生实现） |
| `api-reference/auto_api/ErisPulse/Core/storage/sqlite.md` | ErisPulse SQLite 存储后端（aiosqlite 异步原生实现） |
| `api-reference/auto_api/ErisPulse/Core/text_match.md` | ErisPulse 统一文本/条目匹配工具 |
| `api-reference/auto_api/ErisPulse/Core/transcript.md` | ErisPulse 会话收件箱（transcript） |
| `api-reference/auto_api/ErisPulse/__init__.md` | ErisPulse SDK 主模块 |
| `api-reference/auto_api/ErisPulse/__main__.md` | ErisPulse SDK 命令行工具 |
| `api-reference/auto_api/ErisPulse/finders/__init__.md` | ErisPulse 发现器模块 |
| `api-reference/auto_api/ErisPulse/finders/adapter.md` | ErisPulse 适配器发现器 |
| `api-reference/auto_api/ErisPulse/finders/bases/finder.md` | ErisPulse 基础发现器 |
| `api-reference/auto_api/ErisPulse/finders/module.md` | ErisPulse 模块发现器 |
| `api-reference/auto_api/ErisPulse/loaders/__init__.md` | ErisPulse 加载器模块 |
| `api-reference/auto_api/ErisPulse/loaders/_reload_utils.md` | 热重载共用工具：字节码缓存清理与卸载前语法预检 |
| `api-reference/auto_api/ErisPulse/loaders/adapter.md` | ErisPulse 适配器加载器 |
| `api-reference/auto_api/ErisPulse/loaders/bases/loader.md` | ErisPulse 基础加载器 |
| `api-reference/auto_api/ErisPulse/loaders/module.md` | ErisPulse 模块加载器 |
| `api-reference/auto_api/ErisPulse/loaders/plugin_folder.md` | ErisPulse 本地插件文件夹加载器 |
| `api-reference/auto_api/ErisPulse/loaders/strategy.md` | ErisPulse 模块加载策略 |
| `api-reference/auto_api/ErisPulse/loaders/strict.md` | ErisPulse 严格模式 |
| `api-reference/auto_api/ErisPulse/runtime/__init__.md` | ErisPulse 运行时配置和管理模块 |
| `api-reference/auto_api/ErisPulse/runtime/config_schema.md` | ErisPulse 通用配置 Schema 模块（向后兼容 shim） |
| `api-reference/auto_api/ErisPulse/runtime/context.md` | ErisPulse 运行时上下文 |
| `api-reference/auto_api/ErisPulse/runtime/diagnostics.md` | ErisPulse 异常诊断模块 |
| `api-reference/auto_api/ErisPulse/runtime/example_config.md` | config.full.example 完整配置参考生成器（runtime / CLI 共用） |
| `api-reference/auto_api/ErisPulse/runtime/exceptions.md` | ErisPulse 全局异常处理系统 |
| `api-reference/auto_api/ErisPulse/runtime/file_watcher.md` | 文件变更监控 |
| `api-reference/auto_api/ErisPulse/runtime/frame_config.md` | ErisPulse 框架配置管理模块 |
| `api-reference/auto_api/ErisPulse/runtime/hints.md` | ErisPulse 友好错误提示引擎 |
| `api-reference/auto_api/ErisPulse/runtime/kernel.md` | 统一编排内核（组合根） |
| `api-reference/auto_api/ErisPulse/runtime/memory.md` | 进程内存追踪工具 |
| `api-reference/auto_api/ErisPulse/runtime/owner_cleanup.md` | 归属清理钩子（owner cleanup hooks） |
| `api-reference/auto_api/ErisPulse/runtime/plugin_reload.md` | ErisPulse 本地插件热重载监控 |
| `api-reference/auto_api/ErisPulse/runtime/proactive_gc.md` | ErisPulse 主动 GC 周期任务 |
| `api-reference/auto_api/ErisPulse/runtime/process_state.md` | 跨进程运行状态契约（SDK 侧） |
| `api-reference/auto_api/ErisPulse/runtime/reload_ops.md` | 热重载操作协调器 |
| `api-reference/auto_api/ErisPulse/runtime/resource_track.md` | 合作式资源登记（tracked resources） |
| `api-reference/auto_api/ErisPulse/runtime/sdk_initializer.md` | ErisPulse SDK 初始化 / 反初始化协调器 |
| `api-reference/auto_api/ErisPulse/runtime/tasks.md` | 后台任务管理工具 |
| `api-reference/auto_api/ErisPulse/runtime/troubleshoot.md` | 模块排查诊断（EPRFC-2026-001 方向五·场景一 / 二） |
| `api-reference/auto_api/ErisPulse/runtime/version.md` | SDK 版本解析与比较 |
| `api-reference/auto_api/ErisPulse/sdk.md` | ErisPulse SDK 主类 |
| `api-reference/auto_api/README.md` | 本文档包含 ErisPulse SDK 的所有 API 参考文档。 |
| `api-reference/core-modules.md` | 當你需要用儲存、設定、日誌、模組管理、路由、HTTP 客戶端等核心能力，記不清具體方法簽名時快速查閱本文。不需要則跳過。 |
| `api-reference/event-system.md` | **什麼時候需要閱讀這篇**：當你需要註冊命令、監聽訊息/通知/請求事件，或使用 `event.reply()` / `wait_reply()` / `confirm()` 等事件互動方法時查閱本文。不需要則跳過。 |

### contributing/

| 文档 | 什么时候读 |
|---|---|
| `contributing/README.md` | 想為 ErisPulse 做點貢獻、但還不確定能做什麼或從哪開始時。只使用機器人、不參與開發則跳過。 |
| `contributing/first-contribution.md` | **何時需要閱讀本文**：準備提交你的第一個 Pull Request 時——從 fork 到合併的每一步都有可以直接複製的命令。如果你已有 PR 經驗，只想查閱倉庫規範，直接看 [CONTRIBUTING.md](../../../CONTRIBUTING.md)。 |

### developer-guide/

| 文档 | 什么时候读 |
|---|---|
| `developer-guide/README.md` | 準備為 ErisPulse 開發擴充——給機器人加功能（模組）或接入新平台（配接器）——時。只想使用機器人則跳過，直接看[快速開始](../quick-start.md)。 |
| `developer-guide/adapters/best-practices.md` | 配接器骨架跑通後建議閱讀（工程化最佳實踐）。不需要則跳過，不影響其它功能的使用。 |
| `developer-guide/adapters/converter.md` | **何時需要閱讀本文**：適配器開發路徑內必讀（事件轉換器）。不需要則跳過，不會影響其他功能的使用。 |
| `developer-guide/adapters/core-concepts.md` | 適配器開發路徑內必讀（BaseAdapter / SendDSL / 生命週期等核心機制的完整說明）。只想起步可先讀 [適配器開發入門](getting-started.md)，遇到「為什麼」層面的疑問再回到本篇查閱。 |
| `developer-guide/adapters/getting-started.md` | **何時需要閱讀這篇**：適配器開發路徑的入門篇（必讀）。從零寫一個適配器、了解適配器的職責邊界與專案結構都在這裡；讀完後再按需進入 [事件轉換器](converter.md) 與 [SendDSL 詳解](send-dsl.md)。 |
| `developer-guide/adapters/send-dsl.md` | 配接器開發路徑內必讀（傳送 DSL）。不需要則跳過，不影響其他功能的使用。 |
| `developer-guide/configuration.md` | ErisPulse 的配置體系是**宣告式**的：開發者使用 dataclass 欄位 + 元數據描述配置項，框架的 `get_config_schema()` 將其轉譯為 JSON Schema，供任何消費方（Dashboard、第三方介面、CLI 導覽器等）渲染。本文是該元數據的**規範定義**——widget 語義、值形態、條件顯示隱藏、相容性義務皆以此為準；各消費方負責具體實現，語義必須與本文一致。 |
| `developer-guide/modules/best-practices.md` | **何時需要閱讀這篇**：寫完第一個模組後建議閱讀（工程化最佳實踐）。不需要則跳過，不會影響其他功能的使用。 |
| `developer-guide/modules/core-concepts.md` | 這篇講清模組從載入到卸載的完整生命週期、宣告式配置與儲存的用法——哪些事框架自動替你做、你只需要寫什麼，看完就有數。 |
| `developer-guide/modules/event-wrapper.md` | 處理器裡的 `event` 參數之所以能直接 `.get_text()` / `.reply()` / `.wait_reply()`，靠的就是 Event 包裝類別。本篇是它的完整方法清單——寫事件處理器時按需查閱，方法簽名與行為都以這裡為準。 |
| `developer-guide/modules/getting-started.md` | 跟著這篇走完，你會得到一個能響應 `/hello` 命令的可執行模組，並了解模組的專案結構、註冊方式與載入 / 卸載鉤子——後續所有模組文件都建立在這套骨架上。 |
| `developer-guide/orm.md` | **什麼時候需要閱讀這篇**：需要數據模型、自動建表或關係映射時。不需要則跳過，不會影響其他功能的使用。 |
| `developer-guide/publishing.md` | **何時需要閱讀此篇**：當你將作品發布到 PyPI / 模組商店時。若不需要則可跳過，不會影響其他功能的使用。 |
| `developer-guide/testing.md` | 為自己的模組編寫自動化測試時。不需要則跳過，不影響其它功能的使用。 |

### ecosystem/

| 文档 | 什么时候读 |
|---|---|
| `ecosystem/README.md` | ErisPulse 框架本身僅提供核心能力（事件系統、模組系統、配置、路由、日誌等），**不內建** GUI、圖片渲染、可視化等「重型」功能。這些能力由社區維護的 **第三方模組** 提供，按需安裝即可。 |
| `ecosystem/apimcp.md` | **什麼時候需要閱讀這篇**：當你想讓 Claude Desktop 等支援 MCP 的 AI 客戶端直接操控你的機器人——發送消息、查看消息、調用模組、管理適配器、觀測事件流——時請閱讀這篇。不需要則可跳過。 |
| `ecosystem/app.md` | **什麼時候需要閱讀這篇**：當你想在手機或電腦上使用圖形介面建立、執行、管理機器人實例——不碰終端、不單獨安裝 Python 環境時閱讀這篇。不需要則跳過。 |
| `ecosystem/cron.md` | 當你的模組需要定時/延時觸發邏輯（定時提醒、週期監控、Cron 表達式調度），且希望任務在框架重啟後不遺失時讀這篇。不需要則跳過。 |
| `ecosystem/dashboard.md` | **什麼時候需要閱讀這篇**：當你想使用網頁可視化管理機器人（啟停模組、編輯設定、查看日誌、監控事件流），或想為自己的模組註冊一個 Dashboard 管理頁面時閱讀這篇。不需要則跳過。 |
| `ecosystem/qvqchat.md` | 當你想給機器人加 AI 智慧代理能力（工具循環、串流對話、MCP、長期記憶），或想把自己模組的服務暴露給智慧代理呼叫時讀這篇。不需要則跳過。 |
| `ecosystem/takumi.md` | 當你需要把 HTML / 節點樹 / Jinja 範本渲染成圖片傳送到聊天平台（統計卡片、排行榜、圖文長文）時讀這篇。不需要則跳過。 |

### getting-started/

| 文档 | 什么时候读 |
|---|---|
| `getting-started/README.md` | 機器人已經用 [5 分鐘快速開始](../quick-start.md) 跑起來了，想系統理解框架的核心概念、把常用能力學全。還沒跑起來先去完成快速開始；只想按需查某個問題則直接跳到對應單篇。 |
| `getting-started/basic-concepts.md` | 一條訊息從使用者發出到機器人回覆，中間經過了哪些元件？配接器和模組各自負責什麼？讀完這篇，撰寫處理器時遇到的設計問題你都能自己回答，而不是只能照抄範例。 |
| `getting-started/common-tasks.md` | 想給機器人加某個具體功能時按節查閱——持久化、定時任務、訊息過濾、權限控制、批次傳送，每一節都是可直接複製的完整範例。想系統學事件處理寫法先看 [事件處理入門](event-handling.md)；不需要則跳過。 |
| `getting-started/event-handling.md` | 想讓機器人響應訊息、命令、通知、請求，或要實現等待回覆 / 多輪對話、排查「命令為什麼沒觸發」時讀。只想了解框架設計，看 [基礎概念](basic-concepts.md) 即可；不需要則跳過。 |
| `getting-started/first-bot.md` | 機器人已經能跑，想寫出第一個 `/hello` 命令處理器、搞懂 `sdk.run` 與命令裝飾器各自在做什麼。如果還沒裝好 ErisPulse、初始化專案，先完成 [5 分鐘快速開始](../quick-start.md) 的「安裝」「初始化專案」「執行專案」三步；不需要則跳過。 |
| `getting-started/ide-completion.md` | **何時需要閱讀本文**：當 IDE 補全無法顯示適配器的平台特定方法（如雲湖的 `Board`）或模組的自訂方法時，只需執行一條 `epsdk types` 命令生成類型存根即可解決；若不需要則可跳過。 |

### platform-guide/

| 文档 | 什么时候读 |
|---|---|
| `platform-guide/README.md` | 此部分由各适配器開發者維護，用於說明該適配器與 OneBot12 標準的差異和擴展功能。請參考以下各平台的詳細文件： |
| `platform-guide/bilibili.md` | BilibiliAdapter 是基於 bilibili-api-python 的 B 站私信適配器，支援 Cookie / 掃碼雙登入與事件驅動的私信收發。 |
| `platform-guide/discord.md` | DiscordAdapter 是基於 Discord Gateway (WebSocket) 和 REST API v10 協議建構的適配器，整合了 Discord Bot 的核心功能，提供統一的事件處理和訊息操作介面。 |
| `platform-guide/email.md` | EmailAdapter 是基於 SMTP/IMAP 協議的郵件適配器，支援郵件發送、接收和處理。 |
| `platform-guide/ideaura.md` | IdeauraAdapter 是基於花楓咖啡館（RockyChat）平台 API 建構的適配器，整合了所有平台功能模組，提供統一的事件處理和訊息操作介面。 |
| `platform-guide/kook.md` | KookAdapter 是基於 Kook（開黑啦）Bot WebSocket 協議建構的適配器，整合了 Kook 所有功能模組，提供統一的事件處理和訊息操作介面。 |
| `platform-guide/maintain-notes.md` | 此文件由各適配器開發者維護，用於說明該適配器與 OneBot12 標準的差異和擴展功能。 |
| `platform-guide/matrix.md` | MatrixAdapter 是基於 [Matrix協議](https://spec.matrix.org/) 建構的適配器，整合了 Matrix 協議的所有核心功能模組，提供統一的事件處理和訊息操作介面。 |
| `platform-guide/minecraft.md` | MinecraftAdapter 是基於 RCON 協議的 Minecraft Java 版伺服器適配器，支援命令執行、訊息傳送與日誌事件監聽。 |
| `platform-guide/onebot11.md` | OneBot11Adapter 是基於 OneBot V11 協議所建構的適配器。 |
| `platform-guide/onebot12.md` | OneBot12Adapter 是基於 OneBot V12 協議所建構的適配器，作為 ErisPulse 框架的基準協議適配器。 |
| `platform-guide/qqbot.md` | QQBotAdapter 是基於 QQ 官方機器人（QQ OpenAPI）協定建構的適配器，整合群聊、私聊、頻道等全場景功能，提供 OneBot12 標準事件、標準 API 動作與請求操作介面。 |
| `platform-guide/sandbox.md` | SandboxAdapter 是 ErisPulse 內建的沙盒適配器，用於本地開發與模組調試——無需真實平台即可模擬訊息的收發。 |
| `platform-guide/snowluma.md` | SnowLumaAdapter 是基於 SnowLuma 後端（NTQQ hook）所建構的適配器，使用 OneBot v11 協議進行通訊。 |
| `platform-guide/telegram.md` | TelegramAdapter 是基於 Telegram Bot API 建構的適配器，支援多種訊息類型和事件處理。 |
| `platform-guide/terminal.md` | TerminalAdapter 是命令行終端適配器——終端即聊天會話，用於本地快速調試模塊邏輯。 |
| `platform-guide/webhook.md` | 本文檔詳細說明 Webhook 適配器的雙向橋接協定、欄位映射與實作特性。 |
| `platform-guide/wechatmp.md` | | 方法 | 說明 | 微信 API | |
| `platform-guide/wecom.md` | WeComAdapter 是基於企業微信自建應用 API 建構的轉接器，透過回呼接收訊息、應用訊息介面主動傳送，並提供通訊錄與訊息卡片能力。 |
| `platform-guide/yunhu.md` | YunhuAdapter 是基於雲湖協議建構的適配器，整合了所有雲湖功能模組，提供統一的事件處理與訊息操作介面。 |
| `platform-guide/yunhu_user.md` | YunhuUserAdapter 是基於雲湖使用者帳戶協定所建構的適配器，透過使用者電郵帳戶登入，使用 WebSocket 接收事件，提供統一的事件處理與訊息操作介面。 |

### showcase/

| 文档 | 什么时候读 |
|---|---|
| `showcase/README.md` | **什麼時候需要看這篇**：當你在幾個機器人框架 / AI 機器人平台之間做選擇，想知道 ErisPulse 適合誰、不適合誰時讀這篇。已經在使用 ErisPulse 則跳過。 |
| `showcase/comparison-agent-platforms.md` | 當你想要的是「群組裡的 AI 助手」，正在 AstrBot / LangBot 這類一體化平台和 ErisPulse 之間選型時讀這篇。要寫非 AI 業務程式碼則看 [對比：NoneBot2](comparison-nonebot.md)。 |
| `showcase/comparison-nonebot.md` | **什麼時候需要閱讀這篇**：當你會在 Python 機器人框架中寫程式碼，並正在 NoneBot2 和 ErisPulse 之間做選擇時閱讀這篇。如果不寫程式碼則可跳過。 |
| `showcase/migrate-from-astrbot.md` | 當你已有一個 AstrBot 機器人，想把它遷到 ErisPulse 時讀這篇。全新搭建請直接看[快速開始](../quick-start.md)。 |

### standards/

| 文档 | 什么时候读 |
|---|---|
| `standards/README.md` | 當你在開發或修改適配器，需要確認事件轉換、API 回應、傳送方法等是否符合 ErisPulse 跨平台標準時，從本目錄找對應規範對照。不確定從哪篇開始時，先讀下方總綱。 |
| `standards/api-action-spec.md` | 當你在適配器中實作 Api DSL 標準動作（get_user_info / delete_message 等），或在模組中跨平台呼叫這些標準動作、需要確認參數與 data 字段時對照本文。不需要則跳過。 |
| `standards/api-response.md` | 當你在轉接器中實作 `call_api` / Send / Request 的回傳值，需要確認回應結構與回傳碼是否符合 ErisPulse 標準，或排查某個 `retcode` 的含義時對照本文。不需要則跳過。 |
| `standards/event-conversion.md` | **什麼時候需要閱讀本文**：當你在適配器中將平台原生事件轉換為 OneBot12 標準事件時——確認必須欄位、訊息段結構、擴展欄位命名（`{platform}_` 前綴）、會話類型推斷時對照本文。不需要則跳過。 |
| `standards/request-action-spec.md` | **什麼時候需要閱讀本文**：當你的適配器需要處理好友請求/群邀請（轉換請求事件、實現 `accept`/`reject`），或模組中要用 `event.approve()` / `event.reject()` 審批請求時對照本文。不需要則跳過。 |
| `standards/send-method-spec.md` | 當你在適配器中實現 Send 類別——方法命名、媒體參數（URL/路徑/bytes）的形態支援、`Raw_ob12` 反向轉換、合併轉發能力時對照本文。不需要則跳過。 |
| `standards/session-types.md` | **何時需要閱讀本文**：當你在適配器中將平台原生會話映射到標準類型（private/group/channel/guild/thread），或在模組中不確定 `Send.To()` 應傳入什麼目標類型、想釐清 `event.reply()` 的自動轉換時對照本文。不需要則跳過。 |
| `standards/standardization-guide.md` | 當你開發新適配器，或要為某個平台新增能力、需要決定「進標準還是走 `{platform}_` 擴充」、命名怎麼起、平台差異怎麼處理時先讀本文。只是查某一領域的具體規範，可直接跳到 §2 標準地圖對應的文件。 |

### styleguide/

| 文档 | 什么时候读 |
|---|---|
| `styleguide/README.md` | 本目錄包含 ErisPulse 項目之工程紀律與寫作規範。 |
| `styleguide/docs-writing.md` | 本文頁規範 ErisPulse 的文件撰寫風格與對外（README/發布頁）撰寫。目標讀者為文件貢獻者與負責維護 README 的人。 |
| `styleguide/docstring.md` | 在建立 EP 核心方法時必須添加方法註解，註解格式如下： |
| `styleguide/engineering.md` | 本頁是 ErisPulse 源碼的健壯性紀律。每條規則給出「為什麼」與本倉庫的真實案例；貢獻程式碼前請過一遍本頁，CI 之外的部分靠審核執行。 |
| `styleguide/glossary.md` | 寫文件 / 改文件時拿不準一個概念該叫什麼，或發現兩篇文件對同一概念說法不一致時。不需要則跳過。 |

### user-guide/

| 文档 | 什么时候读 |
|---|---|
| `user-guide/README.md` | 需要安裝環境、設定 `config.toml`、用 `epsdk` 管理元件，或把機器人部署上線時按篇查閱；不需要則跳過。 |
| `user-guide/cli-reference.md` | 忘記某個 `epsdk` 指令的參數、想把元件管理寫進腳本，或要控制 run / stop / restart 行為時查閱。日常只用 `init` / `install` / `run` 的話，記住一條就夠：`epsdk <指令> --help` 隨時可查參數說明，不需要通讀本文。 |
| `user-guide/configuration.md` | - 連線參數變更後需重啟框架生效；連線池建立瞬時失敗會自動指數退避重試 |
| `user-guide/deployment.md` | 機器人要長期掛著跑時——Docker 部署、systemd / Supervisor 程序守護、反向代理與 SSL、備份與升級都在這裡。本地開發除錯階段不需要則跳過。 |
| `user-guide/installation.md` | **何時需要閱讀本文**：需要選擇一種安裝方式（pip / uv / Docker / ErisPulse-App 客戶端），或遇到安裝失敗需要排查時閱讀。只想快速運行，[5 分鐘快速入門](../quick-start.md) 已涵蓋最簡流程，不需要則跳過。 |

> 由 `python -m scripts.tools gen skills` 生成，请勿手改。
