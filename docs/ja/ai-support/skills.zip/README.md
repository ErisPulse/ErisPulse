# ErisPulse Docs Pack (ja)

Auto-packed by CI from `docs/ja/`: all documents as-is (no merging, no rewriting), plus this README as the index.

## Usage

1. Unzip and put the folder into your workspace (IDE / agent), or feed individual documents to the AI as needed
2. Pick documents via the index below: check "when to read" and load only what you need

## Index

### Root documents

| Document | When to read |
|---|---|
| `README.md` | ErisPulse はイベント駆動型のモジュール式非同期ボットフレームワークです。ビジネスコードは一度だけ書けば、アダプター経由で QQ、Telegram、Kook、云湖 など複数のプラットフォームにデプロイでき、プラグインシステム、ホットリロード、完全な開発者ツールチェーンが最初から使える状態で提供されます。 |
| `architecture.md` | **この記事を読むタイミング**：フレームワークが背後で何をしているのか、1 つのメッセージがどのように流れるのか、モジュールがどのような順序で初期化されるのか、ホットリロード時に何が起こるのか、または「フレームワークがなぜそのように振る舞うのか」を理解したいときに読んでください。ハンドラを書くだけなら [イベント処理の入門](getting-started/event-handling.md) で十分です。必要なければ飛ばしてください。 |
| `bug-tracker.md` | このドキュメントは、ErisPulse SDK の既知のバグとその修正状況を記録したものです。修正されたバージョンの日付順に並べられています。 |
| `quick-start.md` | **1. インストール**（Python >= 3.10）： |

### advanced/

| Document | When to read |
|---|---|
| `advanced/README.md` | このディレクトリには、ErisPulseフレームワークの高度なトピックが収録されています。権限管理、グレーディング、複数回の対話、ストレージバックエンドなど、深い機能をカバーし、それぞれの問題を解決します。 |
| `advanced/client.md` | **この記事を読むタイミング**：出力用の HTTP / WebSocket リクエストが必要な場合。不要であれば読み飛ばしても、他の機能の使用に影響はありません。 |
| `advanced/connections.md` | **この記事を読むタイミング**: WebSocket/SSE 接続プール、ブロードキャストグループ、モジュール間のプッシュ、または接続状態を確認する必要がある場合。それ以外の場合は飛ばしても問題なく、他の機能の使用に影響はありません。 |
| `advanced/conversation.md` | **このドキュメントを読む必要があるのはいつですか**：多輪対話のステートマシンとチェックポイントの復元が必要な場合です。必要ない場合はスキップしても、他の機能の使用には影響しません。 |
| `advanced/errors.md` | ErisPulse のすべてのカスタム例外は `ErisPulseError` を継承しています。低レベルライブラリの例外（aiohttp、aiomysql など） |
| `advanced/i18n.md` | **この記事を読む必要があるのは**：多言語の文案、翻訳の登録、言語の検出が必要な場合です。必要ない場合は、他の機能の使用に影響を与えることなく、この記事は飛ばしてください。 |
| `advanced/interaction.md` | **このドキュメントを読むべきタイミング**：wait_reply、マルチターン対話、タイマーリマインダー、セッション排他、リンクトレースが必要な場合。不要であれば読み飛ばしても、他の機能の利用には影響しません。 |
| `advanced/lazy-loading.md` | **この記事を読む必要があるタイミング**：ラグロードモジュールを使用する場合、または activate_on イベント駆動型のアクティベーションを使用する場合。それ以外の場合はスキップしても、他の機能の使用に影響はありません。 |
| `advanced/lifecycle.md` | **この記事を読むべきタイミング**：フレームワークのライフサイクルイベント（起動 / 加載 / 状態変化）をサブスクライブする必要がある場合。不要な場合はスキップしても、他の機能の使用に影響はありません。 |
| `advanced/message-builder.md` | **この記事を読む必要があるのは**：複雑な / 複数のメッセージセグメントを構築する場合です。必要ない場合は飛ばしても、他の機能の使用に影響はありません。 |
| `advanced/module-communication.md` | **この記事を読むタイミング**：RPCによるモジュール間呼び出し、サービス契約、宛先指定イベント、またはコールドスタート時のイベントリプレイが必要な場合。必要なければ飛ばしても、他の機能の使用に影響はありません。 |
| `advanced/ownership.md` | リソースリークの調査、アンロード時のクリーンアップチェーンの理解、または帰属リソースの宣言を行う際。不要であれば読み飛ばしても、他の機能の利用には影響しません。 |
| `advanced/performance.md` | イベントのスループットやレイテンシの数値に関心がある場合、デプロイ前のキャパシティ評価、バージョンアップグレード前後のパフォーマンスリグレッションを比較したい場合に読んでください。必要がなければ読み飛ばしても、他の機能の利用には影響しません。 |
| `advanced/router.md` | **この記事を読むタイミング**：HTTP / WebSocket / SSE ルーティング（接続プールによるブロードキャストを含む）が必要な場合。不要な場合はスキップしても、他の機能の使用に影響はありません。 |
| `advanced/runtime.md` | **このドキュメントを読むべきタイミング**: `ErisPulse.runtime` パッケージが提供する、直接 import できるランタイムツールを一括で把握したいとき。各機能の詳細な使い方は対応するトピックドキュメントに記載されており、本ページはクイックリファレンス索引 + トピックに属さない一部の機能の使い方説明です。 |
| `advanced/scope.md` | **この記事を読むべきタイミング**：モジュールの可用性、イベントの受信制限、または出力アクションの制限を制御する必要がある場合。不要な場合は飛ばしても、他の機能の使用に影響はありません。 |
| `advanced/shadow.md` | **このドキュメントを読むべきタイミング**：カナリアリリース——新バージョンの並行トライアル実行、動作比較、昇格・ロールバックが必要なとき。不要であればスキップしても、他の機能の利用には影響しません。 |
| `advanced/sql-builder.md` | **このドキュメントを読むタイミング**：チェーン式の SQL クエリやカスタムストレージバックエンドが必要な場合。不要な場合はスキップしても、他の機能の使用に影響はありません。 |
| `advanced/startup.md` | 起動チェーンを手動で駆動したい、起動順序をカスタマイズしたい、または起動失敗を調査する必要がある場合。不要であればスキップしても、他の機能の使用には影響しません。 |
| `advanced/storage-backends.md` | **この記事を読むタイミング**：sqlite / mysql / postgres またはカスタムストレージバックエンドに切り替える場合。必要ない場合は飛ばしても、他の機能の使用に影響はありません。 |
| `advanced/transcript.md` | **このドキュメントを読むべきケース**：メッセージ履歴や会話の復元が必要なとき、または受信トレイの保持ポリシーを調整したいとき。不要であれば読み飛ばしても、他の機能の利用には影響しません。 |

### api-reference/

| Document | When to read |
|---|---|
| `api-reference/README.md` | **このページを読むタイミング**：モジュールやアダプターを作成する際に、Storage/Config/Logger/Router などのコアモジュール、イベントシステム、またはアダプター管理 API の使用例を調べる必要がある場合に、以下のドキュメントリストから該当する項目にジャンプしてください。必要ない場合は飛ばしてください。 |
| `api-reference/adapter-system.md` | **このドキュメントを読むべきケース**：アダプターの管理（インスタンスの取得、起動・停止、Bot のオンライン状態の確認）、Send DSL によるメッセージ送信、ミドルウェアの登録、またはアダプターへの Bot ステータス報告（meta イベント）の実装が必要な場合に本文をご参照ください。該当しない場合はスキップしてください。 |
| `api-reference/auto_api/ErisPulse/CLI/__init__.md` | CLI 模块 |
| `api-reference/auto_api/ErisPulse/CLI/base.md` | CLI 命令基类 |
| `api-reference/auto_api/ErisPulse/CLI/cli.md` | 主 CLI 类 |
| `api-reference/auto_api/ErisPulse/CLI/commands/__init__.md` | 命令模块 |
| `api-reference/auto_api/ErisPulse/CLI/commands/config.md` | Config 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/create.md` | Create 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/doctor.md` | Doctor 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/init.md` | Init 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/install.md` | Install 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/language.md` | Language 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/list.md` | List 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/list_remote.md` | List-Remote 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/run.md` | Run 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/runtime.md` | Stop / Restart 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/self_update.md` | Self-Update 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/types.md` | Types 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/uninstall.md` | Uninstall 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/upgrade.md` | Upgrade 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/commands/version.md` | Version 命令实现 |
| `api-reference/auto_api/ErisPulse/CLI/console.md` | CLI 控制台模块 |
| `api-reference/auto_api/ErisPulse/CLI/constants.md` | CLI 本地常量 |
| `api-reference/auto_api/ErisPulse/CLI/hints.md` | ErisPulse CLI 友好提示引擎 |
| `api-reference/auto_api/ErisPulse/CLI/i18n/__init__.md` | ErisPulse CLI 国际化模块 |
| `api-reference/auto_api/ErisPulse/CLI/i18n/locales/__init__.md` | CLI 内置翻译数据加载器 |
| `api-reference/auto_api/ErisPulse/CLI/i18n/locales/en.md` | CLI English translations (en) |
| `api-reference/auto_api/ErisPulse/CLI/i18n/locales/ja.md` | CLI 日本語翻訳 (ja) |
| `api-reference/auto_api/ErisPulse/CLI/i18n/locales/ru.md` | CLI Русский перевод (ru) |
| `api-reference/auto_api/ErisPulse/CLI/i18n/locales/zh_cn.md` | CLI 简体中文翻译 (zh-CN) |
| `api-reference/auto_api/ErisPulse/CLI/i18n/locales/zh_tw.md` | CLI 繁體中文翻譯 (zh-TW) |
| `api-reference/auto_api/ErisPulse/CLI/registry.md` | CLI 命令注册器 |
| `api-reference/auto_api/ErisPulse/CLI/utils/__init__.md` | ErisPulse SDK 工具模块 |
| `api-reference/auto_api/ErisPulse/CLI/utils/config_wizard.md` | ErisPulse CLI 配置向导共享工具 |
| `api-reference/auto_api/ErisPulse/CLI/utils/display.md` | ErisPulse CLI 显示工具 |
| `api-reference/auto_api/ErisPulse/CLI/utils/interactive.md` | CLI 交互式提示统一封装 |
| `api-reference/auto_api/ErisPulse/CLI/utils/package_manager.md` | ErisPulse SDK 包管理器 |
| `api-reference/auto_api/ErisPulse/CLI/utils/runtime_state.md` | 运行实例状态文件（pidfile）工具 |
| `api-reference/auto_api/ErisPulse/CLI/utils/scaffold_text.md` | 脚手架模板多语言文案 |
| `api-reference/auto_api/ErisPulse/Core/Bases/__init__.md` | ErisPulse 基础模块 |
| `api-reference/auto_api/ErisPulse/Core/Bases/adapter.md` | ErisPulse 适配器基础模块 |
| `api-reference/auto_api/ErisPulse/Core/Bases/adapter_patterns.md` | ErisPulse 适配器通信模式基类 |
| `api-reference/auto_api/ErisPulse/Core/Bases/api_dsl.md` | ErisPulse 标准 API 动作 DSL 模块 |
| `api-reference/auto_api/ErisPulse/Core/Bases/client.md` | ErisPulse HTTP 客户端抽象基类 |
| `api-reference/auto_api/ErisPulse/Core/Bases/config_schema.md` | ErisPulse 通用配置 Schema 模块 |
| `api-reference/auto_api/ErisPulse/Core/Bases/converter.md` | OneBot12 事件转换器基类 |
| `api-reference/auto_api/ErisPulse/Core/Bases/errors.md` | ErisPulse 异常体系 |
| `api-reference/auto_api/ErisPulse/Core/Bases/i18n_schema.md` | ErisPulse i18n 键声明 Schema 模块 |
| `api-reference/auto_api/ErisPulse/Core/Bases/kv_builder.md` | ErisPulse KV 查询构建器 |
| `api-reference/auto_api/ErisPulse/Core/Bases/manager.md` | ErisPulse 管理器基类 |
| `api-reference/auto_api/ErisPulse/Core/Bases/model.md` | ErisPulse 数据模型层（ORM）—— 声明式模型与 Active Record CRUD |
| `api-reference/auto_api/ErisPulse/Core/Bases/module.md` | ErisPulse 模块基础模块 |
| `api-reference/auto_api/ErisPulse/Core/Bases/router.md` | ErisPulse 路由抽象基类 |
| `api-reference/auto_api/ErisPulse/Core/Bases/send_builder.md` | SendDSL 批量构建系统 |
| `api-reference/auto_api/ErisPulse/Core/Bases/send_rules.md` | SendDSL 发送规则系统 |
| `api-reference/auto_api/ErisPulse/Core/Bases/sql_base.md` | ErisPulse SQL 存储共享基类 |
| `api-reference/auto_api/ErisPulse/Core/Bases/storage.md` | ErisPulse 存储基类 |
| `api-reference/auto_api/ErisPulse/Core/Bases/websocket.md` | ErisPulse WebSocket 共享基类 |
| `api-reference/auto_api/ErisPulse/Core/Event/__init__.md` | ErisPulse 事件处理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/base.md` | ErisPulse 事件处理基础模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/command.md` | ErisPulse 命令处理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/command_args.md` | ErisPulse 命令参数与选项解析模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/command_flow.md` | 命令多轮流控语法糖（``.got()`` 链） |
| `api-reference/auto_api/ErisPulse/Core/Event/conversation.md` | ErisPulse 多轮对话上下文模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/governance.md` | ErisPulse 命令治理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/interaction.md` | ErisPulse 交互会话管理 |
| `api-reference/auto_api/ErisPulse/Core/Event/message.md` | ErisPulse 消息处理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/message_builder.md` | ErisPulse 消息构建器 |
| `api-reference/auto_api/ErisPulse/Core/Event/meta.md` | ErisPulse 元事件处理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/notice.md` | ErisPulse 通知处理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/overrides.md` | ErisPulse 事件覆写系统（overrides） |
| `api-reference/auto_api/ErisPulse/Core/Event/request.md` | ErisPulse 请求处理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/session_type.md` | ErisPulse 会话类型管理模块 |
| `api-reference/auto_api/ErisPulse/Core/Event/throttle.md` | 事件处理器节流（throttle=）与防抖（debounce=，EPRFC-2026-001 方向八） |
| `api-reference/auto_api/ErisPulse/Core/Event/trace.md` | 分发决策链追踪（EPRFC-2026-001 方向五：模块排查的场景三） |
| `api-reference/auto_api/ErisPulse/Core/Event/wrapper.md` | ErisPulse 事件包装类 |
| `api-reference/auto_api/ErisPulse/Core/__init__.md` | ErisPulse 核心模块 |
| `api-reference/auto_api/ErisPulse/Core/adapter.md` | ErisPulse 适配器系统 |
| `api-reference/auto_api/ErisPulse/Core/assets/__init__.md` | ErisPulse 前端资源 |
| `api-reference/auto_api/ErisPulse/Core/client.md` | ErisPulse HTTP/WS 客户端 |
| `api-reference/auto_api/ErisPulse/Core/config.md` | ErisPulse 配置中心 |
| `api-reference/auto_api/ErisPulse/Core/connections.md` | ErisPulse 连接注册表（连接池） |
| `api-reference/auto_api/ErisPulse/Core/constants.md` | ErisPulse 内部常量定义 |
| `api-reference/auto_api/ErisPulse/Core/di.md` | ErisPulse 依赖注入模块 |
| `api-reference/auto_api/ErisPulse/Core/i18n/__init__.md` | ErisPulse 国际化模块 |
| `api-reference/auto_api/ErisPulse/Core/i18n/constants.md` | ErisPulse i18n 常量定义 |
| `api-reference/auto_api/ErisPulse/Core/i18n/locales/__init__.md` | ErisPulse 内置翻译数据包 |
| `api-reference/auto_api/ErisPulse/Core/i18n/locales/en.md` | English translation data (en) |
| `api-reference/auto_api/ErisPulse/Core/i18n/locales/ja.md` | 日本語翻訳データ (ja) |
| `api-reference/auto_api/ErisPulse/Core/i18n/locales/ru.md` | Русский перевод (ru) |
| `api-reference/auto_api/ErisPulse/Core/i18n/locales/zh_cn.md` | 简体中文翻译数据 (zh-CN) |
| `api-reference/auto_api/ErisPulse/Core/i18n/locales/zh_tw.md` | 繁體中文翻譯資料 (zh-TW) |
| `api-reference/auto_api/ErisPulse/Core/lifecycle.md` | ErisPulse 生命周期管理模块 |
| `api-reference/auto_api/ErisPulse/Core/logger.md` | ErisPulse 日志系统 |
| `api-reference/auto_api/ErisPulse/Core/master.md` | 框架主人管理系统 |
| `api-reference/auto_api/ErisPulse/Core/module.md` | ErisPulse 模块系统 |
| `api-reference/auto_api/ErisPulse/Core/ownership.md` | ErisPulse 归属权统一门面 |
| `api-reference/auto_api/ErisPulse/Core/router.md` | ErisPulse 路由系统 |
| `api-reference/auto_api/ErisPulse/Core/scope.md` | ErisPulse 作用域（scope） |
| `api-reference/auto_api/ErisPulse/Core/shadow.md` | ErisPulse 影子模块（方向十一：Shadow Modules & Canary Promote） |
| `api-reference/auto_api/ErisPulse/Core/storage/__init__.md` | ErisPulse 存储管理模块 |
| `api-reference/auto_api/ErisPulse/Core/storage/mysql.md` | ErisPulse MySQL 存储后端（aiomysql 异步原生实现） |
| `api-reference/auto_api/ErisPulse/Core/storage/postgres.md` | ErisPulse PostgreSQL 存储后端（asyncpg 异步原生实现） |
| `api-reference/auto_api/ErisPulse/Core/storage/sqlite.md` | ErisPulse SQLite 存储后端（aiosqlite 异步原生实现） |
| `api-reference/auto_api/ErisPulse/Core/text_match.md` | ErisPulse 统一文本/条目匹配工具 |
| `api-reference/auto_api/ErisPulse/Core/transcript.md` | ErisPulse 会话收件箱（transcript） |
| `api-reference/auto_api/ErisPulse/__init__.md` | ErisPulse SDK 主模块 |
| `api-reference/auto_api/ErisPulse/__main__.md` | ErisPulse SDK 命令行工具 |
| `api-reference/auto_api/ErisPulse/finders/__init__.md` | ErisPulse 发现器模块 |
| `api-reference/auto_api/ErisPulse/finders/adapter.md` | ErisPulse 适配器发现器 |
| `api-reference/auto_api/ErisPulse/finders/bases/finder.md` | ErisPulse 基础发现器 |
| `api-reference/auto_api/ErisPulse/finders/module.md` | ErisPulse 模块发现器 |
| `api-reference/auto_api/ErisPulse/loaders/__init__.md` | ErisPulse 加载器模块 |
| `api-reference/auto_api/ErisPulse/loaders/_reload_utils.md` | 热重载共用工具：字节码缓存清理与卸载前语法预检 |
| `api-reference/auto_api/ErisPulse/loaders/adapter.md` | ErisPulse 适配器加载器 |
| `api-reference/auto_api/ErisPulse/loaders/bases/loader.md` | ErisPulse 基础加载器 |
| `api-reference/auto_api/ErisPulse/loaders/module.md` | ErisPulse 模块加载器 |
| `api-reference/auto_api/ErisPulse/loaders/plugin_folder.md` | ErisPulse 本地插件文件夹加载器 |
| `api-reference/auto_api/ErisPulse/loaders/strategy.md` | ErisPulse 模块加载策略 |
| `api-reference/auto_api/ErisPulse/loaders/strict.md` | ErisPulse 严格模式 |
| `api-reference/auto_api/ErisPulse/runtime/__init__.md` | ErisPulse 运行时配置和管理模块 |
| `api-reference/auto_api/ErisPulse/runtime/config_schema.md` | ErisPulse 通用配置 Schema 模块（向后兼容 shim） |
| `api-reference/auto_api/ErisPulse/runtime/context.md` | ErisPulse 运行时上下文 |
| `api-reference/auto_api/ErisPulse/runtime/dev_watch.md` | 开发模式细粒度热重载监控 |
| `api-reference/auto_api/ErisPulse/runtime/diagnostics.md` | ErisPulse 异常诊断模块 |
| `api-reference/auto_api/ErisPulse/runtime/example_config.md` | config.full.example 完整配置参考生成器（runtime / CLI 共用） |
| `api-reference/auto_api/ErisPulse/runtime/exceptions.md` | ErisPulse 全局异常处理系统 |
| `api-reference/auto_api/ErisPulse/runtime/file_watcher.md` | 文件变更监控 |
| `api-reference/auto_api/ErisPulse/runtime/frame_config.md` | ErisPulse 框架配置管理模块 |
| `api-reference/auto_api/ErisPulse/runtime/hints.md` | ErisPulse 友好错误提示引擎 |
| `api-reference/auto_api/ErisPulse/runtime/kernel.md` | 统一编排内核（组合根） |
| `api-reference/auto_api/ErisPulse/runtime/memory.md` | 进程内存追踪工具 |
| `api-reference/auto_api/ErisPulse/runtime/metrics.md` | 进程内指标计数器（轻量注册表） |
| `api-reference/auto_api/ErisPulse/runtime/owner_cleanup.md` | 归属清理钩子（owner cleanup hooks） |
| `api-reference/auto_api/ErisPulse/runtime/plugin_reload.md` | ErisPulse 本地插件热重载监控 |
| `api-reference/auto_api/ErisPulse/runtime/proactive_gc.md` | ErisPulse 主动 GC 周期任务 |
| `api-reference/auto_api/ErisPulse/runtime/process_state.md` | 跨进程运行状态契约（SDK 侧） |
| `api-reference/auto_api/ErisPulse/runtime/reload_ops.md` | 热重载操作协调器 |
| `api-reference/auto_api/ErisPulse/runtime/reload_target.md` | 热重载目标判定 |
| `api-reference/auto_api/ErisPulse/runtime/resource_track.md` | 合作式资源登记（tracked resources） |
| `api-reference/auto_api/ErisPulse/runtime/sdk_initializer.md` | ErisPulse SDK 初始化 / 反初始化协调器 |
| `api-reference/auto_api/ErisPulse/runtime/tasks.md` | 后台任务管理工具 |
| `api-reference/auto_api/ErisPulse/runtime/troubleshoot.md` | 模块排查诊断（EPRFC-2026-001 方向五·场景一 / 二） |
| `api-reference/auto_api/ErisPulse/runtime/version.md` | SDK 版本解析与比较 |
| `api-reference/auto_api/ErisPulse/sdk.md` | ErisPulse SDK 主类 |
| `api-reference/auto_api/README.md` | 本文档包含 ErisPulse SDK 的所有 API 参考文档。 |
| `api-reference/core-modules.md` | ストレージ、設定、ログ、モジュール管理、ルーティング、HTTP クライアントなどのコア機能を使う必要があり、具体的なメソッドシグネチャを思い出せないときに、本書を素早く参照してください。不要な場合はスキップしてください。 |
| `api-reference/event-system.md` | **このドキュメントを読むべきタイミング**：コマンドの登録、メッセージ/通知/リクエストイベントのリッスン、または `event.reply()` / `wait_reply()` / `confirm()` などのイベントインタラクションメソッドを使用する必要がある場合に、本文を参照してください。不要であればスキップしてください。 |

### contributing/

| Document | When to read |
|---|---|
| `contributing/README.md` | **このドキュメントを読むべきタイミング**：ErisPulse に貢献したいが、何ができるか、どこから始めたらよいか分からない場合。開発に関わらず、単にロボットを使用しているだけの場合は読み飛ばしてください。 |
| `contributing/first-contribution.md` | **このドキュメントを読むべきタイミング**：初めての Pull Request を提出する準備をしているとき——fork からマージまでの各ステップに、そのままコピーして使えるコマンドを記載しています。すでに PR の経験があり、リポジトリの規約だけ確認したい場合は、[CONTRIBUTING.md](../../../CONTRIBUTING.md) を直接ご覧ください。 |

### developer-guide/

| Document | When to read |
|---|---|
| `developer-guide/README.md` | **このドキュメントをいつ読むべきか**：ErisPulse 向けの拡張機能——ボットに機能（モジュール）を追加する、または新しいプラットフォーム（アダプター）に接続する——を開発する準備をしている時に読んでください。ボットを利用するだけなら読み飛ばして、[クイックスタート](../quick-start.md)を直接ご覧ください。 |
| `developer-guide/adapters/best-practices.md` | **この記事を読むタイミング**：アダプタの基本構造が動くようになったら読むことを推奨します（工程化のベストプラクティス）。必要なければ飛ばしても、他の機能の使用に影響はありません。 |
| `developer-guide/adapters/converter.md` | **この文書を読むべきタイミング**：アダプター開発パス内では必読（イベントコンバーター）。必要なければスキップしても、他の機能の利用には影響しません。 |
| `developer-guide/adapters/core-concepts.md` | **この記事を読むべきタイミング**：アダプタ開発経路内では必読（BaseAdapter / SendDSL / ライフサイクルなど、コアメカニズムの完全な説明）。開発の立ち上げだけなら [アダプタ開発入門](getting-started.md) を先に読むと良い。"なぜこう書くのか"という疑問が生じた際は、この記事に戻って確認する。 |
| `developer-guide/adapters/getting-started.md` | アダプター開発パスの入口編（必読）。ゼロからアダプターを書く、アダプターの責務境界とプロジェクト構造を理解する、そのすべてがここにあります。読み終えたら、必要に応じて[イベントコンバーター](converter.md)と[SendDSL 詳解](send-dsl.md)へ進んでください。 |
| `developer-guide/adapters/send-dsl.md` | **この記事を読むべきとき**：アダプター開発パスでは必読（送信 DSL）。不要な場合はスキップしても、他の機能の利用には影響しません。 |
| `developer-guide/configuration.md` | ErisPulse の設定体系は**宣言的**です。開発者は dataclass のフィールド + メタデータで設定項目を記述し、フレームワークの `get_config_schema()` がそれを JSON Schema に変換して、あらゆるコンシューマー（Dashboard、サードパーティパネル、CLI ウィザードなど）でのレンダリングに供します。本文書はこのメタデータの**規範的定義**です——widget のセマンティクス、値の形式、条件による表示/非表示、互換性に関する義務は、すべてこれに準拠します。各コンシューマーは具体的な実装を担当し、そのセマンティクスは本文書と一致していなければなりません。 |
| `developer-guide/modules/best-practices.md` | **この記事を読むタイミング**：最初のモジュールを書いた後に読むことを推奨します（エンジニアリングのベストプラクティス）。必要なければ飛ばしても、他の機能の使用に影響はありません。 |
| `developer-guide/modules/core-concepts.md` | このドキュメントでは、モジュールのロードからアンロードまでの完全なライフサイクル、宣言型設定とストレージの使い方を解説します——フレームワークが自動でやってくれることと、自分で書くべきことを整理し、読み終えれば全体像がつかめます。 |
| `developer-guide/modules/event-wrapper.md` | ハンドラー内の `event` パラメーターが `.get_text()` / `.reply()` / `.wait_reply()` を直接呼び出せるのは、Event ラッパークラスのおかげです。本ドキュメントはその完全なメソッド一覧です——イベントハンドラーを作成する際に必要に応じて参照し、メソッドのシグネチャと動作はすべてここに記載の内容を基準としてください。 |
| `developer-guide/modules/getting-started.md` | このドキュメントに沿って進めると、`/hello` コマンドに応答できる実行可能なモジュールが完成し、モジュールのプロジェクト構造、登録方法、ロード/アンロードフックについても理解できます。今後のすべてのモジュールドキュメントは、この骨組みの上に成り立っています。 |
| `developer-guide/orm.md` | **このドキュメントを読むべきとき**: データモデル、自動テーブル作成、リレーションマッピングが必要な場合です。不要であれば読み飛ばしても、他の機能の利用には影響しません。 |
| `developer-guide/publishing.md` | **この記事を読む必要があるのはいつか**：作品を PyPI / モジュールストアに公開する場合。必要ない場合は飛ばしても、他の機能の使用に支障はありません。 |
| `developer-guide/testing.md` | **この記事を読むタイミング**：独自のモジュールに自動テストを書く場合。必要なければスキップし、他の機能の使用に影響はありません。 |

### ecosystem/

| Document | When to read |
|---|---|
| `ecosystem/README.md` | ErisPulse フレームワーク自体はコア機能（イベントシステム、モジュールシステム、設定、ルーティング、ログなど）のみを提供し、GUI、画像レンダリング、可視化などの「ヘビー級」機能は**組み込まれていません**。これらの機能は、コミュニティがメンテナンスする**サードパーティモジュール**によって提供されており、必要に応じてインストールするだけで利用できます。 |
| `ecosystem/apimcp.md` | **このドキュメントが必要な場面**：Claude Desktop などの MCP 対応 AI クライアントに、ボットの直接操作——メッセージの送信、メッセージの確認、モジュールの呼び出し、アダプターの管理、イベントストリームの観測——をさせたいときに読んでください。不要であれば読み飛ばして構いません。 |
| `ecosystem/app.md` | **このドキュメントを読むべきとき**：スマートフォンやパソコン上でグラフィカルインターフェースを使ってボットインスタンスの作成・実行・管理を行いたい場合——ターミナルに触れず、Python 環境も別途インストールせずに済むようにしたいときに読んでください。不要な場合はスキップしてください。 |
| `ecosystem/cron.md` | **このドキュメントを読む必要があるタイミング**: |
| `ecosystem/dashboard.md` | **このドキュメントを読むべきとき**：Web画面でボットを視覚的に管理したい場合（モジュールの有効化・無効化、設定編集、ログ閲覧、イベントストリームの監視など）、または自分のモジュール用のDashboard管理ページを登録したい場合にお読みください。必要ない場合はスキップして構いません。 |
| `ecosystem/qvqchat.md` | **このドキュメントを読む必要があるのは**、ロボットに AI インテリジェントエージェントの機能（ツールループ、ストリーミング対話、MCP、長期記憶）を追加したい場合、または独自のモジュールサービスをインテリジェントエージェントから呼び出せるようにしたい場合です。必要ない場合はこのドキュメントは飛ばしてください。 |
| `ecosystem/takumi.md` | **このドキュメントを読むタイミング**：HTML / ノードツリー / Jinjaテンプレートを画像にレンダリングしてチャットプラットフォームに送信したい場合（統計カード、ランキング、長文の画像）に読む。必要なければスキップしてください。 |

### getting-started/

| Document | When to read |
|---|---|
| `getting-started/README.md` | **この記事を読むタイミング**：ロボットが [5 分鐘のクイックスタート](../quick-start.md) で起動している場合、フレームワークのコアコンセプトと一般的な機能を体系的に理解したい場合に読んでください。まだ起動していない場合は、まずクイックスタートを完了してください。特定の問題を検索したい場合は、対応する個別記事に直接ジャンプしてください。 |
| `getting-started/basic-concepts.md` | ユーザーがメッセージを送信してからボットが返信するまでの間に、どのコンポーネントを経由するのでしょうか？アダプターとモジュールはそれぞれ何を担当しているのでしょうか？このドキュメントを読み終えれば、ハンドラーを書く際に直面する設計上の問いに、サンプルをただ写経するのではなく自分で答えられるようになります。 |
| `getting-started/common-tasks.md` | **この章を読むタイミング**：ロボットに特定の機能を追加したいときは、各節を参照してください。永続化、定期タスク、メッセージフィルタ、権限制御、一括送信など、各節は直接コピーできる完全な例です。イベント処理の書き方を体系的に学びたい場合は [イベント処理入門](event-handling.md) を先にご覧ください。必要なければ飛ばしてください。 |
| `getting-started/event-handling.md` | **この記事を読むべきタイミング**：ロボットにメッセージ、コマンド、通知、リクエストへの反応をさせたい場合、または応答待ち／対話の実装、コマンドがなぜ実行されないかを調査する場合に読む。フレームワークの設計概要だけ知りたい場合は、[基本概念](basic-concepts.md)を参照するだけでよい。必要なければ飛ばしてもよい。 |
| `getting-started/first-bot.md` | **この記事を読むタイミング**：ロボットが動作している状態で、最初の `/hello` コマンドハンドラを実装し、`sdk.run` とコマンドデコレータがそれぞれ何をしているのかを理解したい場合。まだ ErisPulse をインストールしておらず、プロジェクトを初期化していない場合は、まず [5 分間クイックスタート](../quick-start.md) の「インストール」「プロジェクトの初期化」「プロジェクトの実行」の 3 ステップを完了してください。必要ない場合はスキップしてください。 |
| `getting-started/ide-completion.md` | **このドキュメントを読むべきケース**：IDE の補完にアダプターのプラットフォーム固有メソッド（例：云湖の `Board`）やモジュールのカスタムメソッドが表示されない場合は、`epsdk types` コマンドを 1 回実行して型スタブを生成すれば解決します。不要であれば読み飛ばしてください。 |

### platform-guide/

| Document | When to read |
|---|---|
| `platform-guide/README.md` | このセクションは、各アダプターの開発者が保守し、OneBot12 標準との差異と拡張機能を説明するためのものです。以下の各プラットフォームの詳細ドキュメントを参照してください： |
| `platform-guide/bilibili.md` | BilibiliAdapter は bilibili-api-python をベースにした Bilibili ダイレクトメッセージ（DM）アダプターで、Cookie / QRコードによるデュアルログインとイベント駆動型の DM 送受信をサポートします。 |
| `platform-guide/discord.md` | DiscordAdapter は、Discord Gateway (WebSocket) および REST API v10 プロトコルに基づいて構築されたアダプターであり、Discord Bot のコア機能を統合し、一貫したイベント処理およびメッセージ操作のインターフェースを提供します。 |
| `platform-guide/email.md` | EmailAdapter は SMTP/IMAP プロトコルベースのメールアダプターで、メールの送信・受信・処理をサポートします。 |
| `platform-guide/ideaura.md` | IdeauraAdapter は、花楓コーヒー館（RockyChat）プラットフォームの API を基に構築されたアダプターで、すべてのプラットフォーム機能モジュールを統合し、一貫したイベント処理およびメッセージ操作インターフェースを提供します。 |
| `platform-guide/kook.md` | KookAdapterは、Kook（開黒啦）Bot WebSocketプロトコルに基づいて構築されたアダプターであり、Kookのすべての機能モジュールを統合し、一貫したイベント処理とメッセージ操作のインターフェースを提供します。 |
| `platform-guide/maintain-notes.md` | このドキュメントは、各アダプタ開発者が保守しており、OneBot12 標準との差異や拡張機能を説明するために使用されます。 |
| `platform-guide/matrix.md` | MatrixAdapter は [Matrixプロトコル](https://spec.matrix.org/) をベースに構築されたアダプターで、Matrixプロトコルのすべてのコア機能モジュールを統合し、統一されたイベント処理とメッセージ操作インターフェースを提供します。 |
| `platform-guide/minecraft.md` | MinecraftAdapterは、RCONプロトコルに基づくMinecraft Java Editionサーバーアダプターです。コマンドの実行、メッセージの送信、ログイベントの監視が可能です。 |
| `platform-guide/onebot11.md` | OneBot11Adapterは、OneBot V11プロトコルに基づいて構築されたアダプターです。 |
| `platform-guide/onebot12.md` | OneBot12Adapterは、OneBot V12プロトコルに基づいて構築されたアダプタであり、ErisPulseフレームワークのベースラインプロトコルアダプタです。 |
| `platform-guide/oopz.md` | | 項目 | 内容 | |
| `platform-guide/qqbot.md` | QQBotAdapter は、QQ公式ボット（QQ OpenAPI）プロトコルに基づいて構築されたアダプターです。グループチャット、プライベートチャット、チャンネルなど全シナリオの機能を統合し、OneBot12 標準イベント、標準Apiアクション、リクエスト操作インターフェースを提供します。 |
| `platform-guide/sandbox.md` | SandboxAdapter は ErisPulse に組み込まれたサンドボックスアダプターで、ローカル開発とモジュールのデバッグに使用されます——実際のプラットフォームがなくてもメッセージの送受信をシミュレートできます。 |
| `platform-guide/snowluma.md` | SnowLumaAdapter は SnowLuma バックエンド（NTQQ hook）をベースに構築されたアダプターで、OneBot v11 プロトコルを使用して通信します。`ErisPulse-OneBot11Adapter[snowluma]` のオプション拡張としてインストールできます（`pip install "ErisPulse-OneBot11Adapter[snowluma]"`）。 |
| `platform-guide/telegram.md` | TelegramAdapter は Telegram Bot API をベースに構築されたアダプターで、複数のメッセージタイプとイベント処理をサポートしています。 |
| `platform-guide/terminal.md` | TerminalAdapter はコマンドライン端末アダプターです。端末そのものがチャットセッションとなり、モジュールロジックをローカルで素早くデバッグするために使用されます。 |
| `platform-guide/webhook.md` | WebhookAdapter はプロトコルレベルの双方向橋渡しアダプターであり、特定のプラットフォームに紐付いていません。入力側では外部システムからの POST リクエストの JSON を OneBot12 イベントに変換し、出力側ではモジュールの Send から外部システムに POST します。 |
| `platform-guide/wechatmp.md` | レスポンス構造とエラーコードは、[API レスポンス規格](../standards/api-response.md)に従います。 |
| `platform-guide/wecom.md` | WeComAdapter は、企業微信の自建アプリ API を基に構築されたアダプターであり、コールバックによるメッセージ受信、アプリメッセージのインターフェースを介した送信、および連絡先とメッセージカード機能を提供します。 |
| `platform-guide/yunhu.md` | YunhuAdapterは、Yunhuプロトコルに基づいて構築されたアダプターであり、Yunhuのすべての機能モジュールを統合し、一貫したイベント処理とメッセージ操作のインターフェースを提供します。 |
| `platform-guide/yunhu_user.md` | YunhuUserAdapter は、云湖用户账户协议に基づき構築されたアダプタです。ユーザーのメールアドレスアカウントを使用してログインし、WebSocket を介してイベントを受信し、一貫したイベント処理とメッセージ操作のインターフェースを提供します。 |

### showcase/

| Document | When to read |
|---|---|
| `showcase/README.md` | **このドキュメントを読むべきタイミング**：いくつかのボットフレームワーク / AIボットプラットフォームの中から選択を行っており、ErisPulse が誰に向いているのか、誰に向いていないのかを知りたいときにお読みください。すでに ErisPulse を使用している場合は読み飛ばしてください。 |
| `showcase/comparison-agent-platforms.md` | **この記事を読むタイミング**：「グループ内の AI ヘルパー」が目的で、AstrBot / LangBot といった統合プラットフォームと ErisPulse の選定に迷っている場合に読んでください。AI 以外の業務コードを書く場合は [NoneBot2 との比較](comparison-nonebot.md) を参照してください。 |
| `showcase/comparison-nonebot.md` | **この記事を読むべきタイミング**：Python ボットフレームワークでコードを書く予定があり、NoneBot2 と ErisPulse の間で選定を行っているときにお読みください。コードを書かない場合は読み飛ばして構いません。 |
| `showcase/migrate-from-astrbot.md` | **このドキュメントを読むタイミング**：既に AstrBot ロボットをお持ちで、それを ErisPulse に移行したい場合に読んでください。新規構築の場合は、[クイックスタート](../quick-start.md)をご覧ください。 |

### standards/

| Document | When to read |
|---|---|
| `standards/README.md` | **この記事を読むタイミング**：アダプターを開発または修正する際、イベント変換、APIレスポンス、送信メソッドなどが ErisPulse のクロスプラットフォーム標準に準拠しているか確認する必要がある場合、この目次から対応する規格を参照してください。どの記事から読み始めるか迷う場合は、まず下の概要を読んでください。 |
| `standards/api-action-spec.md` | **このドキュメントを読むべきタイミング**：アダプター内で Api DSL の標準アクション（get_user_info / delete_message など）を実装する場合、またはモジュールからこれらの標準アクションをクロスプラットフォームで呼び出す際に、パラメータや data フィールドを確認したいときに本書を参照してください。必要なければ読み飛ばして構いません。 |
| `standards/api-response.md` | **この記事を読むタイミング**：アダプター内で `call_api` / Send / Request の返り値を実装する際に、返却値の構造と返却コードが ErisPulse の標準に準拠しているか確認する必要がある場合、または特定の `retcode` の意味を確認したい場合に、本記事を参照してください。必要がない場合は飛ばしてください。 |
| `standards/event-conversion.md` | **このドキュメントを読むべきタイミング**：アダプタ内でプラットフォームのネイティブイベントを OneBot12 標準イベントに変換する際、必須フィールド、メッセージセグメント構造、拡張フィールド命名規則（`{platform}_` プレフィックス）、会話タイプの推論を確認する必要がある場合。不要であれば飛ばしてください。 |
| `standards/request-action-spec.md` | **このドキュメントを読むタイミング**：アダプタが友人リクエスト/グループ招待（リクエストイベントの変換、`accept`/`reject`の実装、異質なエンドポイントのリクエストタイプコンテキスト保持）を処理する必要がある場合、またはモジュールで `event.approve()` / `event.reject()` を使用してリクエストを承認する場合に本文を参照してください。必要がない場合はスキップしてください。 |
| `standards/send-method-spec.md` | **このドキュメントを読むべきタイミング**：アダプターで Send クラスを実装する際、メソッド命名、メディアパラメータ（URL/パス/bytes）のサポート形態、`Raw_ob12` の逆変換、転送メッセージのマージ機能を本文と照らし合わせてください。不要であれば飛ばしてください。 |
| `standards/session-types.md` | **このドキュメントを読むべきケース**：アダプターでプラットフォームのネイティブセッションを標準タイプ（private/group/channel/guild/thread）にマッピングする場合や、モジュールで `Send.To()` にどのターゲットタイプを渡せばよいかわからない場合、`event.reply()` の自動変換を把握したい場合に本ドキュメントを参照してください。不要な場合はスキップしてください。 |
| `standards/standardization-guide.md` | **この文書をいつ読むべきか**：新しいアダプターを開発する場合や、あるプラットフォーム向けに新しい機能を追加して「標準に取り込むか `{platform}_` 拡張とするか」の判断、命名の付け方、プラットフォーム差異の処理方法を決める必要があるときは、まず本文をお読みください。特定分野の具体的な仕様を調べたいだけであれば、§2 標準マップの該当ドキュメントへ直接ジャンプできます。 |

### styleguide/

| Document | When to read |
|---|---|
| `styleguide/README.md` | このディレクトリには、ErisPulse プロジェクトのエンジニアリング規律と書式規則が含まれています。 |
| `styleguide/docs-writing.md` | このページは、ErisPulse のドキュメントの執筆スタイルと外部向け（README/リリースページ）の執筆を規定しています。対象読者は、ドキュメントへの貢献者および README の維持管理者です。 |
| `styleguide/docstring.md` | EPコアメソッドを作成する際には、メソッドのコメントを必ず追加する必要があります。コメントの形式は以下の通りです： |
| `styleguide/engineering.md` | このページは、ErisPulse ソースコードにおける堅牢性に関する規律です。各ルールには「なぜ」が記述されており、本リポジトリの実際の例も示されています。コードを貢献する前に、このページを確認してください。CI 以外の部分はレビューによって実行されます。 |
| `styleguide/glossary.md` | **この文書をいつ読むべきか**：ドキュメントを書く / 修正する際に、ある概念を何と呼ぶべきか確信が持てないとき、または 2 つのドキュメントが同じ概念について食い違う記述をしていることに気づいたとき。該当しなければ読み飛ばして構いません。 |

### user-guide/

| Document | When to read |
|---|---|
| `user-guide/README.md` | **このドキュメントを読むタイミング**：環境のインストール、`config.toml` の設定、`epsdk` を使ってコンポーネントを管理する、またはロボットを本番環境にデプロイする必要がある場合に参照してください。必要ない場合は飛ばしてください。 |
| `user-guide/cli-reference.md` | **このドキュメントを参照すべきとき**：`epsdk` コマンドの引数を忘れたとき、コンポーネント管理をスクリプトに組み込みたいとき、run / stop / restart の挙動を制御したいときに参照してください。日常的に `init` / `install` / `run` しか使わない場合は、次の一点だけ覚えていれば十分です：`epsdk <コマンド> --help` でいつでも引数の説明を確認できるので、本文を通読する必要はありません。 |
| `user-guide/configuration.md` | - 接続パラメータを変更した後はフレームワークを再起動して有効にする必要がある；接続プールの作成が瞬時失敗すると指数関数的に再試行する |
| `user-guide/deployment.md` | **この記事を読むべきタイミング**：ロボットを長期間稼働させる場合——Docker 部署、systemd / Supervisor プロセス監視、リバースプロキシと SSL、バックアップとアップグレードはすべてここにあります。ローカル開発やデバッグ段階では必要ありません。 |
| `user-guide/installation.md` | **このページを読むべきタイミング**：インストール方法（pip / uv / Docker / ErisPulse-App クライアント）を選ぶ必要があるときや、インストールに失敗してトラブルシューティングが必要なときに読んでください。とにかく最速で動かしたいだけなら、[5分クイックスタート](../quick-start.md) に最短の手順がまとめられているため、不要であればスキップしてください。 |

> Generated by `python -m scripts.tools gen skills`; do not edit by hand.
