# ErisPulse への貢献

> [!TIP]
> **このドキュメントを読むべきタイミング**：ErisPulse に貢献したいが、何ができるか、どこから始めたらよいか分からない場合。開発に関わらず、単にロボットを使用しているだけの場合は読み飛ばしてください。

> **初めて貢献するあなたへ**
> オープンソースプロジェクトは、決して1、2人のコア開発者の「大きな動き」だけで成り立っているわけではありません。多くの場合、無数の小さな変更が積み重なっているのです。一つの誤字、翻訳の修正、小さなバグの修正が、ErisPulse を少しずつ前進させています。だから、自分の貢献が「十分な量」かどうかを測る必要はありません。PR を提出する意思があるだけで、すでにこのプロジェクトの一部です。

## あなたが参加できる方法

貢献は、コアコードの記述だけではありません。以下のようなことが、ErisPulse をより良くする助けになります。

- **ドキュメントの整備** —— 拼写ミスの修正、分かりにくい記述の整理、自分が経験した問題の追加。最も簡単な方法で、いつでも始められます。
- **翻訳の補完** —— フレームワークは 5 種類の言語（zh-CN / en / zh-TW / ja / ru）をサポートしており、翻訳が漏れている箇所や不正確な部分があれば、ぜひ補ってください。
- **バグの修正** —— [Issues](https://github.com/ErisPulse/ErisPulse/issues) で、自分が理解している問題を選び、再現して修正します。
- **サンプルの作成** —— 自分の使用経験を整理してサンプルコードを作成し、後の人たちの参考にしてもらいましょう。
- **モジュール / アダプターの開発** —— フレームワークに新しいプラットフォームや機能を接続します。難易度は高めですが、達成感も大きいです。

> どこから始めたらいいか分からない場合は、[Discussions](https://github.com/ErisPulse/ErisPulse/discussions) で声をかけてください。メンテナが適切な方向を提案します。

## 初めての PR の提出

PR を提出したことがない場合は、[初めての貢献実践](first-contribution.md) を先に読んでおくことをお勧めします。この記事では、リポジトリの fork から PR のマージまでの一連の流れが詳しく説明されており、問題が発生した場合は Issue や Discussions に質問してください。

## 開発環境

完全な開発規約はルートディレクトリの [CONTRIBUTING.md](../../../CONTRIBUTING.md) を参照してください。クイックスタート:

```bash
git clone -b Develop/v2 https://github.com/ErisPulse/ErisPulse.git
cd ErisPulse
uv sync                       # 開発環境の同期
uv run pytest -m unit         # ユニットテストの実行
uv run ruff check .           # コードチェック
```

## 提交流程

簡単に言うと：リポジトリを fork する → `Develop/v2` をベースにブランチを作成する → 変更を加えてテストを通過させる → `Develop/v2` に PR を作成する。

いくつか注意点があります：

- PR は **`Develop/v2`** ブランチに送ってください。`main` や `Pre-Release/v2` に直接変更を加えないでください。
- 提出前に `pytest` / `ruff` / `basedpyright` がすべて通過していることを確認してください（型チェックの `reportAny` / `Unknown*` 警告は「型がまだ徐々に整備中」のため、マージを妨げることはありません）。
- 機能を変更した場合は `CHANGELOG.md` に記録してください。
- 公共 API にメソッドを追加した場合は、ドキュメントのコメントを追加してください（[規格はこちら](../styleguide/docstring.md)）。

## 貢献モジュールまたはアダプタ

新しいモジュールまたはアダプタを作成する場合は、まず [Issues](https://github.com/ErisPulse/ErisPulse/issues) で「新アダプタまたはモジュール」テンプレートを使用して、あなたのアイデアを簡単に説明してください。完全に記述する必要はありません。意図を説明するだけで十分です。メンテナが開発の方向性を整理し、開発基準に沿ったアドバイスを提供します。これにより、開発をスムーズに行うことができます。

脚手架ツールを使用すると、迅速にプロジェクトを開始できます：

```bash
epsdk create    # module または adapter を選択し、完全なプロジェクト構造を生成
```

その後、[モジュール開発の入門](../developer-guide/modules/getting-started.md)または[アダプタ開発の入門](../developer-guide/adapters/getting-started.md)を参照してください。開発が完了したら、[PyPI とモジュールストアへの公開](../developer-guide/publishing.md)も可能です。

> モジュールとアダプタは通常、独立したリポジトリとして管理されます。メインリポジトリに統合する必要はありません。`examples/` にあるサンプルプロジェクトを参考にしてください。

## ヘルプの入手

- [GitHub Issues](https://github.com/ErisPulse/ErisPulse/issues) —— 問題の報告、要望の提出
- [GitHub Discussions](https://github.com/ErisPulse/ErisPulse/discussions) —— 議論、質問の提出
- メール：`erisdev@88.com`